/**
 * Pokemon Auto Chess Live Data Calculator - Injected Overlay
 * Draggable floating panel with live data extraction
 * 
 * @author Galliano Games
 * @version 2.16.6
 */

(function() {
  'use strict';

  // Prevent double injection
  if (window.__PACCalculatorInjected) return;
  window.__PACCalculatorInjected = true;

  // OPTIMIZATION: Console logging gating
  const DEBUG_MODE = false; // Set to true only for development

  if (DEBUG_MODE) console.log('🎮 PAC Calculator: Injecting overlay...');

  // ═══════════════════════════════════════════════════════════════════════════
  // POKEMON DATABASE (1060 pokemon with rarities)
  // ═══════════════════════════════════════════════════════════════════════════

const POKEMON_DATA = {"DITTO":"special","SUBSTITUTE":"special","EGG":"special","ELECTRIKE":"rare","MANECTRIC":"rare","MEGAMANECTRIC":"rare","SHUPPET":"epic","BANETTE":"epic","MEGABANETTE":"epic","RIOLU":"rare","LUCARIO":"rare","CRABRAWLER":"rare","CRABOMINABLE":"rare","CUTIEFLY":"rare","RIBOMBEE":"rare","NICKIT":"rare","THIEVUL":"rare","SWABLU":"epic","ALTARIA":"epic","MEGAALTARIA":"epic","SCYTHER":"unique","SCIZOR":"unique","KLEAVOR":"unique","BOUNSWEET":"epic","STEENEE":"epic","TSAREENA":"epic","BUNEARY":"uncommon","LOPUNNY":"uncommon","MEGALOPUNNY":"uncommon","ONIX":"epic","STEELIX":"epic","MEGASTEELIX":"epic","NUMEL":"epic","CAMERUPT":"epic","MEGACAMERUPT":"epic","MEDITITE":"epic","MEDICHAM":"epic","ELEKID":"epic","ELECTABUZZ":"epic","ELECTIVIRE":"epic","GIBLE":"epic","GABITE":"epic","GARCHOMP":"epic","ROGGENROLA":"epic","BOLDORE":"epic","GIGALITH":"epic","BELDUM":"epic","METANG":"epic","METAGROSS":"epic","TYMPOLE":"hatch","PALPITOAD":"hatch","SEISMITOAD":"hatch","BAGON":"uncommon","SHELGON":"uncommon","SALAMENCE":"uncommon","RALTS":"epic","KIRLIA":"epic","GARDEVOIR":"epic","GALLADE":"epic","FUECOCO":"epic","CROCALOR":"epic","SKELEDIRGE":"epic","BUDEW":"epic","ROSELIA":"epic","ROSERADE":"epic","SLAKOTH":"epic","VIGOROTH":"epic","SLAKING":"epic","HONEDGE":"rare","DOUBLADE":"rare","AEGISLASH":"rare","AEGISLASHBLADE":"rare","OSHAWOTT":"epic","DEWOTT":"epic","SAMUROTT":"epic","LARVITAR":"rare","PUPITAR":"rare","TYRANITAR":"rare","JANGMOO":"epic","HAKAMOO":"epic","KOMMOO":"epic","GASTLY":"ultra","HAUNTER":"ultra","GENGAR":"ultra","ABRA":"rare","KADABRA":"rare","ALAKAZAM":"rare","LITWICK":"common","LAMPENT":"common","CHANDELURE":"common","PORYGON":"ultra","PORYGON2":"ultra","PORYGONZ":"ultra","SEWADDLE":"uncommon","SWADLOON":"uncommon","LEAVANNY":"uncommon","TURTWIG":"rare","GROTLE":"rare","TORTERRA":"rare","DEINO":"rare","ZWEILOUS":"rare","HYDREIGON":"rare","POLIWAG":"common","POLIWHIRL":"common","POLITOED":"common","POLIWRATH":"common","MAGBY":"rare","MAGMAR":"rare","MAGMORTAR":"rare","SOLOSIS":"ultra","DUOSION":"ultra","REUNICLUS":"ultra","SHINX":"ultra","LUXIO":"ultra","LUXRAY":"ultra","CUBONE":"epic","MAROWAK":"epic","ALOLANMAROWAK":"epic","AXEW":"hatch","FRAXURE":"hatch","HAXORUS":"hatch","DRATINI":"rare","DRAGONAIR":"rare","DRAGONITE":"rare","GOOMY":"epic","SLIGOO":"epic","GOODRA":"epic","HISUISLIGGOO":"epic","HISUIGOODRA":"epic","LOTAD":"rare","LOMBRE":"rare","LUDICOLO":"rare","TOGEPI":"rare","TOGETIC":"rare","TOGEKISS":"rare","RHYHORN":"ultra","RHYDON":"ultra","RHYPERIOR":"ultra","ARON":"common","LAIRON":"common","AGGRON":"common","WHISMUR":"rare","LOUDRED":"rare","EXPLOUD":"rare","SWINUB":"common","PILOSWINE":"common","MAMOSWINE":"common","SNOVER":"epic","ABOMASNOW":"epic","MEGAABOMASNOW":"epic","SNORUNT":"epic","GLALIE":"epic","FROSLASS":"epic","VANILLITE":"rare","VANILLISH":"rare","VANILLUXE":"rare","TRAPINCH":"rare","VIBRAVA":"rare","FLYGON":"rare","PICHU":"common","PIKACHU":"common","RAICHU":"common","ALOLANRAICHU":"common","BULBASAUR":"rare","IVYSAUR":"rare","VENUSAUR":"rare","IGGLYBUFF":"uncommon","JIGGLYPUFF":"uncommon","WIGGLYTUFF":"uncommon","DUSKULL":"uncommon","DUSCLOPS":"uncommon","DUSKNOIR":"uncommon","MAGNEMITE":"uncommon","MAGNETON":"uncommon","MAGNEZONE":"uncommon","HORSEA":"uncommon","SEADRA":"uncommon","KINGDRA":"uncommon","FLABEBE":"uncommon","FLOETTE":"uncommon","FLORGES":"uncommon","CHIKORITA":"special","BAYLEEF":"special","MEGANIUM":"special","VENIPEDE":"ultra","WHIRLIPEDE":"ultra","SCOLIPEDE":"ultra","SPHEAL":"uncommon","SEALEO":"uncommon","WALREIN":"uncommon","NIDORANF":"uncommon","NIDORINA":"uncommon","NIDOQUEEN":"uncommon","NIDORANM":"uncommon","NIDORINO":"uncommon","NIDOKING":"uncommon","MACHOP":"uncommon","MACHOKE":"uncommon","MACHAMP":"uncommon","PIPLUP":"uncommon","PRINPLUP":"uncommon","EMPOLEON":"uncommon","CHIMCHAR":"common","MONFERNO":"common","INFERNAPE":"common","MUDKIP":"common","MARSHTOMP":"common","SWAMPERT":"common","TORCHIC":"rare","COMBUSKEN":"rare","BLAZIKEN":"rare","TREECKO":"uncommon","GROVYLE":"uncommon","SCEPTILE":"uncommon","CYNDAQUIL":"uncommon","QUILAVA":"uncommon","TYPHLOSION":"uncommon","HISUIANTYPHLOSION":"uncommon","SLOWPOKE":"uncommon","SLOWBRO":"uncommon","SLOWKING":"uncommon","GALARIANSLOWPOKE":"uncommon","GALARIANSLOWBRO":"uncommon","GALARIANSLOWKING":"uncommon","PSYDUCK":"uncommon","GOLDUCK":"uncommon","SQUIRTLE":"common","WARTORTLE":"common","BLASTOISE":"common","BELLSPROUT":"special","WEEPINBELL":"special","VICTREEBEL":"special","GEODUDE":"common","GRAVELER":"common","GOLEM":"common","TOTODILE":"rare","CROCONAW":"rare","FERALIGATR":"rare","AZURILL":"common","MARILL":"common","AZUMARILL":"common","ZUBAT":"common","GOLBAT":"common","CROBAT":"common","MAREEP":"common","FLAFFY":"common","AMPHAROS":"common","CLEFFA":"uncommon","CLEFAIRY":"uncommon","CLEFABLE":"uncommon","CATERPIE":"common","METAPOD":"common","BUTTERFREE":"common","WEEDLE":"common","KAKUNA":"common","BEEDRILL":"common","PIDGEY":"common","PIDGEOTTO":"common","PIDGEOT":"common","HOPPIP":"special","SKIPLOOM":"special","JUMPLUFF":"special","SEEDOT":"common","NUZLEAF":"common","SHIFTRY":"common","SPRIGATITO":"common","FLORAGATO":"common","MEOWSCARADA":"common","CHARMANDER":"common","CHARMELEON":"common","CHARIZARD":"common","MAGIKARP":"special","GYARADOS":"special","PIKACHUSURFER":"special","RATTATA":"common","RATICATE":"common","ALOLANRATTATA":"common","ALOLANRATICATE":"common","SPEAROW":"common","FEAROW":"common","MELOETTA":"legendary","PIROUETTEMELOETTA":"legendary","LUGIA":"legendary","SHADOWLUGIA":"legendary","GIRATINA":"legendary","ORIGINGIRATINA":"legendary","ZAPDOS":"legendary","GALARIANZAPDOS":"legendary","ZERAORA":"unique","STANTLER":"unique","WYRDEER":"unique","MILTANK":"unique","YVELTAL":"legendary","MOLTRES":"legendary","GALARIANMOLTRES":"legendary","PINSIR":"unique","ARTICUNO":"legendary","GALARIANARTICUNO":"legendary","DIALGA":"legendary","PALKIA":"legendary","MELTAN":"special","MELMETAL":"legendary","SUICUNE":"legendary","RAIKOU":"legendary","ENTEI":"legendary","REGICE":"legendary","SEVIPER":"unique","LUNATONE":"unique","SOLROCK":"unique","REGIROCK":"legendary","TAUROS":"unique","HERACROSS":"unique","ZANGOOSE":"unique","REGISTEEL":"legendary","REGIGIGAS":"legendary","KYOGRE":"legendary","GROUDON":"legendary","RAYQUAZA":"legendary","EEVEE":"special","VAPOREON":"special","JOLTEON":"special","FLAREON":"special","ESPEON":"special","UMBREON":"special","LEAFEON":"special","SYLVEON":"special","GLACEON":"special","VOLCANION":"legendary","DARKRAI":"legendary","LARVESTA":"epic","VOLCARONA":"epic","CHATOT":"unique","FARFETCHD":"unique","GALARIANFARFETCHD":"unique","KECLEON":"unique","CASTFORM":"unique","CASTFORMSUN":"unique","CASTFORMRAIN":"unique","CASTFORMHAIL":"unique","LANDORUS":"legendary","THUNDURUS":"legendary","TORNADUS":"legendary","ENAMORUS":"legendary","KELDEO":"legendary","TERRAKION":"legendary","VIRIZION":"legendary","COBALION":"legendary","MAWILE":"unique","PHIONE":"special","MANAPHY":"legendary","ROTOM":"unique","ROTOMHEAT":"unique","ROTOMWASH":"unique","ROTOMFROST":"unique","ROTOMFAN":"unique","ROTOMMOW":"unique","ROTOMDRONE":"unique","SPIRITOMB":"unique","ABSOL":"unique","DELIBIRD":"unique","IRONBUNDLE":"unique","LAPRAS":"unique","LATIAS":"unique","LATIOS":"unique","UXIE":"unique","MESPRIT":"unique","AZELF":"unique","MEW":"legendary","MEWTWO":"legendary","MARSHADOW":"legendary","KYUREM":"legendary","RESHIRAM":"legendary","ZEKROM":"legendary","CELEBI":"legendary","VICTINI":"legendary","JIRACHI":"legendary","ARCEUS":"legendary","DEOXYS":"legendary","DEOXYSDEFENSE":"legendary","DEOXYSATTACK":"legendary","DEOXYSSPEED":"legendary","SHAYMIN":"legendary","SHAYMINSKY":"legendary","CRESSELIA":"legendary","HEATRAN":"legendary","HOOH":"legendary","ROARINGMOON":"legendary","TORKOAL":"unique","HEATMOR":"unique","CRYOGONAL":"unique","DRAMPA":"unique","PRIMALGROUDON":"legendary","PRIMALKYOGRE":"legendary","MEGARAYQUAZA":"legendary","ODDISH":"special","GLOOM":"special","VILEPLUME":"special","BELLOSSOM":"special","AMAURA":"epic","AURORUS":"epic","CARBINK":"epic","DIANCIE":"epic","SUNKERN":"rare","SUNFLORA":"rare","MANKEY":"epic","PRIMEAPE":"epic","ANNIHILAPE":"epic","ANORITH":"uncommon","ARMALDO":"uncommon","WYNAUT":"rare","WOBBUFFET":"rare","MUNNA":"rare","MUSHARNA":"rare","ARCHEN":"uncommon","ARCHEOPS":"uncommon","GLIGAR":"epic","GLISCOR":"epic","SHIELDON":"rare","BASTIODON":"rare","MIENFOO":"rare","MIENSHAO":"rare","LILEEP":"rare","CRADILY":"rare","CRANIDOS":"uncommon","RAMPARDOS":"uncommon","KABUTO":"rare","KABUTOPS":"rare","OMANYTE":"uncommon","OMASTAR":"uncommon","CLAMPERL":"epic","GOREBYSS":"epic","HUNTAIL":"epic","RELICANTH":"unique","TYRUNT":"rare","TYRANTRUM":"rare","AERODACTYL":"unique","GENESECT":"legendary","HATENNA":"uncommon","HATTREM":"uncommon","HATTERENE":"uncommon","FENNEKIN":"common","BRAIXEN":"common","DELPHOX":"common","REGIELEKI":"legendary","REGIDRAGO":"legendary","GUZZLORD":"legendary","ETERNATUS":"legendary","NINCADA":"epic","NINJASK":"epic","SHEDINJA":"epic","HAPPINY":"ultra","CHANSEY":"ultra","BLISSEY":"ultra","TAPUKOKO":"unique","TAPULELE":"unique","XERNEAS":"legendary","TAPUFINI":"unique","TAPUBULU":"unique","STAKATAKA":"legendary","BLACEPHALON":"legendary","HOUNDOUR":"epic","HOUNDOOM":"epic","MEGAHOUNDOOM":"epic","CACNEA":"rare","CACTURNE":"rare","PUMPKABOO":"epic","GOURGEIST":"epic","NATU":"rare","XATU":"rare","NOIBAT":"uncommon","NOIVERN":"uncommon","SHELLDER":"uncommon","CLOYSTER":"uncommon","BUIZEL":"epic","FLOATZEL":"epic","PONYTA":"epic","RAPIDASH":"epic","GALARIANPONYTA":"epic","GALARIANRAPIDASH":"epic","MAKUHITA":"rare","HARIYAMA":"rare","SENTRET":"rare","FURRET":"rare","JOLTIK":"rare","GALVANTULA":"rare","PARAS":"rare","PARASECT":"rare","CORPHISH":"uncommon","CRAWDAUNT":"uncommon","MEOWTH":"rare","PERSIAN":"rare","ALOLANMEOWTH":"rare","ALOLANPERSIAN":"rare","HOOTHOOT":"uncommon","NOCTOWL":"uncommon","MUNCHLAX":"epic","SNORLAX":"epic","POIPOLE":"unique","NAGANADEL":"legendary","GROWLITHE":"uncommon","ARCANINE":"uncommon","HISUIGROWLITHE":"uncommon","HISUIARCANINE":"uncommon","SMOOCHUM":"uncommon","JYNX":"uncommon","MIMEJR":"uncommon","MRMIME":"uncommon","SALANDIT":"rare","SALAZZLE":"rare","VENONAT":"uncommon","VENOMOTH":"uncommon","VOLTORB":"uncommon","ELECTRODE":"uncommon","HISUIVOLTORB":"uncommon","HISUIELECTRODE":"uncommon","SLUGMA":"rare","MAGCARGO":"rare","SNEASEL":"epic","WEAVILE":"epic","HISUISNEASEL":"epic","SNEASLER":"epic","SEEL":"uncommon","DEWGONG":"uncommon","CROAGUNK":"rare","TOXICROAK":"rare","CHINCHOU":"uncommon","LANTURN":"uncommon","POOCHYENA":"rare","MIGHTYENA":"rare","BRONZOR":"rare","BRONZONG":"rare","DRIFLOON":"rare","DRIFBLIM":"rare","SHROOMISH":"uncommon","BRELOOM":"uncommon","TENTACOOL":"uncommon","TENTACRUEL":"uncommon","SNUBULL":"epic","GRANBULL":"epic","TYPENULL":"legendary","SILVALLY":"legendary","APPLIN":"unique","DIPPLIN":"unique","APPLETUN":"unique","FLAPPLE":"unique","HYDRAPPLE":"unique","STARYU":"rare","STARMIE":"rare","VULPIX":"rare","NINETALES":"rare","ALOLANVULPIX":"rare","ALOLANNINETALES":"rare","SNOM":"rare","FROSMOTH":"rare","WAILMER":"epic","WAILORD":"epic","DREEPY":"hatch","DRAKLOAK":"hatch","DRAGAPULT":"hatch","SNIVY":"hatch","SERVINE":"hatch","SERPERIOR":"hatch","STARLY":"common","STARAVIA":"common","STARAPTOR":"common","SCORBUNNY":"hatch","RABOOT":"hatch","CINDERACE":"hatch","ALOLANGEODUDE":"common","ALOLANGRAVELER":"common","ALOLANGOLEM":"common","POPPLIO":"hatch","BRIONNE":"hatch","PRIMARINA":"hatch","GOTHITA":"hatch","GOTHORITA":"hatch","GOTHITELLE":"hatch","SANDSHREW":"uncommon","SANDSLASH":"uncommon","ALOLANSANDSHREW":"uncommon","ALOLANSANDSLASH":"uncommon","NOSEPASS":"uncommon","PROBOPASS":"uncommon","WOOBAT":"uncommon","SWOOBAT":"uncommon","PINECO":"uncommon","FORRETRESS":"uncommon","UNOWNA":"special","UNOWNB":"special","UNOWNC":"special","UNOWND":"special","UNOWNE":"special","UNOWNF":"special","UNOWNG":"special","UNOWNH":"special","UNOWNI":"special","UNOWNJ":"special","UNOWNK":"special","UNOWNL":"special","UNOWNM":"special","UNOWNN":"special","UNOWNO":"special","UNOWNP":"special","UNOWNQ":"special","UNOWNR":"special","UNOWNS":"special","UNOWNT":"special","UNOWNU":"special","UNOWNV":"special","UNOWNW":"special","UNOWNX":"special","UNOWNY":"special","UNOWNZ":"special","UNOWNQUESTION":"special","UNOWNEXCLAMATION":"special","DIGLETT":"uncommon","DUGTRIO":"uncommon","WIGLETT":"uncommon","WUGTRIO":"uncommon","ALOLANDIGLETT":"uncommon","ALOLANDUGTRIO":"uncommon","ROWLET":"hatch","DARTIX":"hatch","DECIDUEYE":"hatch","ZORUA":"uncommon","ZOROARK":"uncommon","HISUIZORUA":"uncommon","HISUIZOROARK":"uncommon","GRIMER":"uncommon","MUK":"uncommon","ALOLANGRIMER":"uncommon","ALOLANMUK":"uncommon","EKANS":"uncommon","ARBOK":"uncommon","CARVANHA":"rare","SHARPEDO":"rare","FROAKIE":"hatch","FROGADIER":"hatch","GRENINJA":"hatch","CHINGLING":"unique","CHIMECHO":"unique","TYROGUE":"unique","HITMONTOP":"unique","HITMONLEE":"unique","HITMONCHAN":"unique","MIMIKYU":"unique","MIMIKYUBUSTED":"unique","BONSLEY":"epic","SUDOWOODO":"epic","COMBEE":"epic","VESPIQUEEN":"epic","SHUCKLE":"unique","TEPIG":"hatch","PIGNITE":"hatch","EMBOAR":"hatch","WURMPLE":"epic","SILCOON":"epic","BEAUTIFLY":"epic","CASCOON":"epic","DUSTOX":"epic","TINKATINK":"epic","TINKATUFF":"epic","TINKATON":"epic","MARACTUS":"unique","PLUSLE":"unique","MINUN":"unique","SPECTRIER":"legendary","KARTANA":"legendary","DHELMISE":"unique","TROPIUS":"unique","CARNIVINE":"unique","SABLEYE":"unique","MEGASABLEYE":"unique","KOFFING":"uncommon","WEEZING":"uncommon","GALARIANWEEZING":"uncommon","CLAUNCHER":"rare","CLAWITZER":"rare","YANMA":"rare","YANMEGA":"rare","HELIOPTILE":"epic","HELIOLISK":"epic","EXEGGCUTE":"epic","EXEGGUTOR":"epic","ALOLANEXEGGUTOR":"epic","BIDOOF":"uncommon","BIBAREL":"uncommon","SPINDA":"unique","BALTOY":"epic","CLAYDOL":"epic","PURRLOIN":"uncommon","LIEPARD":"uncommon","PANCHAM":"rare","PANGORO":"rare","BARBOACH":"epic","WHISCASH":"epic","SCRAGGY":"uncommon","SCRAFTY":"uncommon","FINNEON":"rare","LUMINEON":"rare","STUNKY":"epic","SKUNTANK":"epic","ILLUMISE":"unique","VOLBEAT":"unique","NECROZMA":"legendary","ULTRANECROZMA":"legendary","CHERUBI":"epic","CHERRIM":"epic","CHERRIMSUNLIGHT":"epic","MISDREAVUS":"epic","MISMAGIUS":"epic","DODUO":"epic","DODRIO":"epic","KRICKETOT":"rare","KRICKETUNE":"rare","HIPPOPOTAS":"epic","HIPPODOWN":"epic","WINGULL":"epic","PELIPPER":"epic","MURKROW":"epic","HONCHKROW":"epic","ZIGZAGOON":"rare","LINOONE":"rare","GALARIANZIGZAGOON":"rare","GALARIANLINOONE":"rare","OBSTAGOON":"rare","PHANTUMP":"rare","TREVENANT":"rare","QWILFISH":"unique","HISUIANQWILFISH":"unique","OVERQWIL":"unique","XURKITREE":"legendary","NIHILEGO":"legendary","TANDEMAUS":"unique","MAUSHOLDTHREE":"unique","MAUSHOLDFOUR":"unique","MORPEKO":"unique","MORPEKOHANGRY":"unique","MINIOR":"unique","MINIORKERNELBLUE":"unique","MINIORKERNELRED":"unique","MINIORKERNELORANGE":"unique","MINIORKERNELGREEN":"unique","HOOPA":"unique","HOOPAUNBOUND":"unique","GIMMIGHOUL":"unique","GHOLDENGO":"unique","SOBBLE":"ultra","DRIZZILE":"ultra","INTELEON":"ultra","COMFEY":"unique","LILLIPUP":"common","HERDIER":"common","STOUTLAND":"common","PHEROMOSA":"legendary","DRACOVISH":"unique","DRACOZOLT":"unique","ARCTOZOLT":"unique","ARCTOVISH":"unique","BRUXISH":"unique","CORSOLA":"epic","GALARCORSOLA":"epic","CURSOLA":"epic","SMEARGLE":"unique","TOXEL":"rare","TOXTRICITY":"rare","CYCLIZAR":"unique","PAWNIARD":"ultra","BISHARP":"ultra","KINGAMBIT":"ultra","FEEBAS":"special","MILOTIC":"special","DEWPIDER":"uncommon","ARAQUANID":"uncommon","LICKITUNG":"uncommon","LICKILICKY":"uncommon","KANGASKHAN":"unique","TEDDIURSA":"ultra","URSARING":"ultra","URSALUNA":"ultra","URSALUNABLOODMOON":"ultra","AIPOM":"uncommon","AMBIPOM":"uncommon","DEERLINGSPRING":"rare","DEERLINGSUMMER":"rare","DEERLINGAUTUMN":"rare","DEERLINGWINTER":"rare","SAWSBUCKSPRING":"rare","SAWSBUCKSUMMER":"rare","SAWSBUCKAUTUMN":"rare","SAWSBUCKWINTER":"rare","PATRAT":"rare","WATCHOG":"rare","TAILLOW":"rare","SWELLOW":"rare","SPINARAK":"uncommon","ARIADOS":"uncommon","ROCKRUFF":"epic","LYCANROCDUSK":"epic","LYCANROCNIGHT":"epic","LYCANROCDAY":"epic","DRUDDIGON":"unique","COSMOG":"unique","COSMOEM":"unique","SOLGALEO":"legendary","LUNALA":"legendary","MAGEARNA":"legendary","IMPIDIMP":"uncommon","MORGREM":"uncommon","GRIMMSNARL":"uncommon","DROWZEE":"epic","HYPNO":"epic","WATTREL":"epic","KILOWATTREL":"epic","BURMYPLANT":"rare","BURMYSANDY":"rare","BURMYTRASH":"rare","WORMADAMPLANT":"rare","WORMADAMSANDY":"rare","WORMADAMTRASH":"rare","MOTHIM":"rare","WOOPER":"rare","QUAGSIRE":"rare","PALDEAWOOPER":"rare","CLODSIRE":"rare","TANGELA":"uncommon","TANGROWTH":"uncommon","PHANPY":"rare","DONPHAN":"rare","SPOINK":"rare","GRUMPIG":"rare","SINISTEA":"uncommon","POLTEAGEIST":"uncommon","FERROSEED":"epic","FERROTHORN":"epic","GOLETT":"rare","GOLURK":"rare","TRUBBISH":"epic","GARBODOR":"epic","GRUBBIN":"hatch","CHARJABUG":"hatch","VIKAVOLT":"hatch","SHELLOSWESTSEA":"epic","GASTRODONWESTSEA":"epic","SHELLOSEASTSEA":"epic","GASTRODONEASTSEA":"epic","RUFFLET":"uncommon","BRAVIARY":"uncommon","KLEFKI":"unique","HAWLUCHA":"unique","STONJOURNER":"unique","CRAMORANT":"unique","ARROKUDA":"special","DURANT":"unique","WISHIWASHI":"special","WISHIWASHISCHOOL":"special","PAWMI":"rare","PAWMO":"rare","PAWMOT":"rare","PYUKUMUKU":"unique","GOLDEEN":"rare","SEAKING":"rare","LUVDISC":"unique","AUDINO":"unique","PETILIL":"uncommon","LILLIGANT":"uncommon","HISUIANLILLIGANT":"uncommon","MANTYKE":"unique","MANTINE":"unique","REMORAID":"special","OCTILLERY":"special","SIGILYPH":"unique","FRIGIBAX":"ultra","ARCTIBAX":"ultra","BAXCALIBUR":"ultra","SANDILE":"hatch","KROKOROK":"hatch","KROOKODILE":"hatch","BINACLE":"rare","BARBARACLE":"rare","SKARMORY":"unique","OGERPONTEAL":"legendary","OGERPONTEALMASK":"legendary","OGERPONWELLSPRING":"legendary","OGERPONWELLSPRINGMASK":"legendary","OGERPONHEARTHFLAME":"legendary","OGERPONHEARTHFLAMEMASK":"legendary","OGERPONCORNERSTONE":"legendary","OGERPONCORNERSTONEMASK":"legendary","IRONHANDS":"unique","ROOKIDEE":"rare","CORVISQUIRE":"rare","CORVIKNIGHT":"rare","TURTONATOR":"unique","SANDYGAST":"uncommon","PALOSSAND":"uncommon","SKORUPI":"epic","DRAPION":"epic","DARUMAKA":"epic","DARMANITAN":"epic","DARMANITANZEN":"epic","KRABBY":"uncommon","KINGLER":"uncommon","ZYGARDE10":"legendary","ZYGARDE50":"legendary","ZYGARDE100":"legendary","SIZZLIPEDE":"uncommon","CENTISKORCH":"uncommon","STUFFUL":"epic","BEWEAR":"epic","GLIMMET":"rare","GLIMMORA":"rare","FLETCHLING":"ultra","FLETCHINDER":"ultra","TALONFLAME":"ultra","VULLABY":"rare","MANDIBUZZ":"rare","INKAY":"epic","MALAMAR":"epic","TIMBURR":"ultra","GURDURR":"ultra","CONKELDURR":"ultra","PILLARWOOD":"special","PILLARIRON":"special","PILLARCONCRETE":"special","ELGYEM":"rare","BEHEEYEM":"rare","LITTEN":"epic","TORRACAT":"epic","INCINEROAR":"epic","SKRELP":"uncommon","DRAGALGE":"uncommon","CUBCHOO":"epic","BEARTIC":"epic","NACLI":"uncommon","NACLSTACK":"uncommon","GARGANACL":"uncommon","CAPSAKID":"uncommon","SCOVILLAIN":"uncommon","SWIRLIX":"rare","SLURPUFF":"rare","GULPIN":"epic","SWALOT":"epic","FIDOUGH":"rare","DACHSBUN":"rare","MILCERY":"unique","ALCREMIEVANILLA":"unique","ALCREMIERUBY":"unique","ALCREMIEMATCHA":"unique","ALCREMIEMINT":"unique","ALCREMIELEMON":"unique","ALCREMIESALTED":"unique","ALCREMIERUBYSWIRL":"unique","ALCREMIECARAMELSWIRL":"unique","ALCREMIERAINBOWSWIRL":"unique","PECHARUNT":"legendary","VELUZA":"unique","DURALUDON":"unique","ARCHALUDON":"unique","FOMANTIS":"rare","LURANTIS":"rare","CHARCADET":"unique","ARMAROUGE":"unique","CERULEDGE":"unique","TYNAMO":"common","EELEKTRIK":"common","EELEKTROSS":"common","PIDOVE":"common","TRANQUILL":"common","UNFEZANT":"common","ZACIAN":"legendary","ZACIANCROWNED":"legendary","IRONVALIANT":"legendary","GROOKEY":"ultra","THWACKEY":"ultra","RILLABOOM":"ultra","KUBFU":"unique","URSHIFURAPID":"legendary","URSHIFUSINGLE":"legendary","SCREAMTAIL":"unique","INDEEDEEFEMALE":"unique","INDEEDEEMALE":"unique","COTTONEE":"uncommon","WHIMSICOTT":"uncommon","GIRAFARIG":"epic","FARIGIRAF":"epic","SKITTY":"uncommon","DELCATTY":"uncommon","GLAMEOW":"uncommon","PURUGLY":"uncommon","MINCCINO":"uncommon","CINCCINO":"uncommon","ESPURR":"uncommon","MEOWSTICMALE":"uncommon","MEOWSTICFEMALE":"uncommon","OKIDOGI":"legendary","MUNKIDORI":"legendary","FEZANDIPITI":"legendary","SURSKIT":"rare","MASQUERAIN":"rare","GOSSIFLEUR":"uncommon","ELDEGOSS":"uncommon","FURFROU":"unique","VAROOM":"uncommon","REVAVROOM":"uncommon","CELESTEELA":"legendary","LEDYBA":"uncommon","LEDIAN":"uncommon","EMOLGA":"unique","DRILBUR":"rare","EXCADRILL":"rare","TOGEDEMARU":"unique","DEDENNE":"unique","FALINKSBRASS":"unique","FALINKSTROOPER":"special","SILICOBRA":"rare","SANDACONDA":"rare","DUNSPARCE":"unique","DUDUNSPARCE":"unique","SMOLIV":"common","DOLLIV":"common","ARBOLIVA":"common","CHESPIN":"common","QUILLADIN":"common","CHESNAUGHT":"common","NYMBLE":"rare","LOKIX":"rare","BLIPBUG":"common","DOTTLER":"common","ORBEETLE":"common","PACHIRISU":"unique","BUZZWOLE":"legendary","YAMASK":"rare","COFAGRIGUS":"rare","GALARIANYAMASK":"rare","RUNERIGUS":"rare","CHEWTLE":"rare","DREDNAW":"rare","GREAVARD":"uncommon","HOUNDSTONE":"uncommon","CLOBBOPUS":"uncommon","GRAPPLOCT":"uncommon","CHIYU":"legendary","WIMPOD":"epic","GOLISOPOD":"epic","BASCULINRED":"unique","BASCULINBLUE":"unique","BASCULINWHITE":"unique","BASCULEGIONMALE":"unique","BASCULEGIONFEMALE":"unique","KLINK":"common","KLANG":"common","KLINKLANG":"common","FLUTTERMANE":"unique","WALKINGWAKE":"legendary","ORTHWORM":"unique","IRONTHORNS":"unique","TADBULB":"rare","BELLIBOLT":"rare","PINCURCHIN":"unique"};
  // Rarity display names and colors
  const RARITY_INFO = {
    common: { label: 'Common', color: '#9e9e9e' },
    uncommon: { label: 'Uncommon', color: '#4caf50' },
    rare: { label: 'Rare', color: '#2196f3' },
    epic: { label: 'Epic', color: '#9c27b0' },
    ultra: { label: 'Ultra', color: '#ff9800' },
    legendary: { label: 'Legendary', color: '#ffd700' },
    unique: { label: 'Unique', color: '#00bcd4' },
    hatch: { label: 'Hatch', color: '#ff69b4' },
    special: { label: 'Special', color: '#607d8b' }
  };

  // Standard pool rarities (ones that appear in shops)
  const POOL_RARITIES = ['common', 'uncommon', 'rare', 'epic', 'ultra'];

  // ═══════════════════════════════════════════════════════════════════════════
  // EVOLUTION CHAINS MODULE (v2.5.0)
  // ═══════════════════════════════════════════════════════════════════════════

/**
 * Evolution Chains Data Module
 * Auto-generated from evolution_chains.csv
 * Provides evolution family tracking for PAC Calculator v2.5.0
 */

// Main data structure: base form -> array of evolution stages
const EVOLUTION_CHAINS = {
  "ABRA": [
    { maxStars: 3 },
    { stage: 0, name: "ABRA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KADABRA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ALAKAZAM", rarity: "unknown", cost: 9 },
  ],
  "AIPOM": [
    { maxStars: 2 },
    { stage: 0, name: "AIPOM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "AMBIPOM", rarity: "unknown", cost: 3 },
  ],
  "AMAURA": [
    { maxStars: 2 },
    { stage: 0, name: "AMAURA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "AURORUS", rarity: "unknown", cost: 3 },
  ],
  "ANORITH": [
    { maxStars: 2 },
    { stage: 0, name: "ANORITH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARMALDO", rarity: "unknown", cost: 3 },
  ],
  "ARCHEN": [
    { maxStars: 2 },
    { stage: 0, name: "ARCHEN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARCHEOPS", rarity: "unknown", cost: 3 },
  ],
  "ARON": [
    { maxStars: 3 },
    { stage: 0, name: "ARON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LAIRON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "AGGRON", rarity: "unknown", cost: 9 },
  ],
  "AZURILL": [
    { maxStars: 3 },
    { stage: 0, name: "AZURILL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MARILL", rarity: "unknown", cost: 3 },
    { stage: 2, name: "AZUMARILL", rarity: "unknown", cost: 9 },
  ],
  "BAGON": [
    { maxStars: 3 },
    { stage: 0, name: "BAGON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SHELGON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SALAMENCE", rarity: "unknown", cost: 9 },
  ],
  "BALTOY": [
    { maxStars: 2 },
    { stage: 0, name: "BALTOY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CLAYDOL", rarity: "unknown", cost: 3 },
  ],
  "BARBOACH": [
    { maxStars: 2 },
    { stage: 0, name: "BARBOACH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WHISCASH", rarity: "unknown", cost: 3 },
  ],
  "BELDUM": [
    { maxStars: 3 },
    { stage: 0, name: "BELDUM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "METANG", rarity: "unknown", cost: 3 },
    { stage: 2, name: "METAGROSS", rarity: "unknown", cost: 9 },
  ],
  "BIDOOF": [
    { maxStars: 2 },
    { stage: 0, name: "BIDOOF", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BIBAREL", rarity: "unknown", cost: 3 },
  ],
  "BINACLE": [
    { maxStars: 2 },
    { stage: 0, name: "BINACLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BARBARACLE", rarity: "unknown", cost: 3 },
  ],
  "BLIPBUG": [
    { maxStars: 3 },
    { stage: 0, name: "BLIPBUG", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DOTTLER", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ORBEETLE", rarity: "unknown", cost: 9 },
  ],
  "BONSLEY": [
    { maxStars: 2 },
    { stage: 0, name: "BONSLEY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SUDOWOODO", rarity: "unknown", cost: 3 },
  ],
  "BOUNSWEET": [
    { maxStars: 3 },
    { stage: 0, name: "BOUNSWEET", rarity: "unknown", cost: 1 },
    { stage: 1, name: "STEENEE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TSAREENA", rarity: "unknown", cost: 9 },
  ],
  "BRONZOR": [
    { maxStars: 2 },
    { stage: 0, name: "BRONZOR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BRONZONG", rarity: "unknown", cost: 3 },
  ],
  "BUDEW": [
    { maxStars: 3 },
    { stage: 0, name: "BUDEW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ROSELIA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ROSERADE", rarity: "unknown", cost: 9 },
  ],
  "BUIZEL": [
    { maxStars: 2 },
    { stage: 0, name: "BUIZEL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FLOATZEL", rarity: "unknown", cost: 3 },
  ],
  "BULBASAUR": [
    { maxStars: 3 },
    { stage: 0, name: "BULBASAUR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "IVYSAUR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "VENUSAUR", rarity: "unknown", cost: 9 },
  ],
  "BUNEARY": [
    { maxStars: 2 },
    { stage: 0, name: "BUNEARY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LOPUNNY", rarity: "unknown", cost: 3 },
  ],
  "CACNEA": [
    { maxStars: 2 },
    { stage: 0, name: "CACNEA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CACTURNE", rarity: "unknown", cost: 3 },
  ],
  "CAPSAKID": [
    { maxStars: 2 },
    { stage: 0, name: "CAPSAKID", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SCOVILLAIN", rarity: "unknown", cost: 3 },
  ],
  "CARBINK": [
    { maxStars: 1 },
    { stage: 0, name: "CARBINK", rarity: "unknown", cost: 1 },
  ],
  "CARVANHA": [
    { maxStars: 2 },
    { stage: 0, name: "CARVANHA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SHARPEDO", rarity: "unknown", cost: 3 },
  ],
  "CATERPIE": [
    { maxStars: 3 },
    { stage: 0, name: "CATERPIE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "METAPOD", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BUTTERFREE", rarity: "unknown", cost: 9 },
  ],
  "CHARMANDER": [
    { maxStars: 3 },
    { stage: 0, name: "CHARMANDER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CHARMELEON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CHARIZARD", rarity: "unknown", cost: 9 },
  ],
  "CHERUBI": [
    { maxStars: 2 },
    { stage: 0, name: "CHERUBI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CHERRIM", rarity: "unknown", cost: 3 },
  ],
  "CHESPIN": [
    { maxStars: 3 },
    { stage: 0, name: "CHESPIN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "QUILLADIN", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CHESNAUGHT", rarity: "unknown", cost: 9 },
  ],
  "CHEWTLE": [
    { maxStars: 2 },
    { stage: 0, name: "CHEWTLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DREDNAW", rarity: "unknown", cost: 3 },
  ],
  "CHIMCHAR": [
    { maxStars: 3 },
    { stage: 0, name: "CHIMCHAR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MONFERNO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "INFERNAPE", rarity: "unknown", cost: 9 },
  ],
  "CHINCHOU": [
    { maxStars: 2 },
    { stage: 0, name: "CHINCHOU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LANTURN", rarity: "unknown", cost: 3 },
  ],
  "CLAMPERL": [
    { maxStars: 3 },
    { stage: 0, name: "CLAMPERL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HUNTAIL", rarity: "unknown", cost: 3 },
    { stage: 1, name: "GOREBYSS", rarity: "unknown", cost: 3 },
  ],
  "CLAUNCHER": [
    { maxStars: 2 },
    { stage: 0, name: "CLAUNCHER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CLAWITZER", rarity: "unknown", cost: 3 },
  ],
  "CLEFFA": [
    { maxStars: 3 },
    { stage: 0, name: "CLEFFA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CLEFAIRY", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CLEFABLE", rarity: "unknown", cost: 9 },
  ],
  "CLOBBOPUS": [
    { maxStars: 2 },
    { stage: 0, name: "CLOBBOPUS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GRAPPLOCT", rarity: "unknown", cost: 3 },
  ],
  "COMBEE": [
    { maxStars: 2 },
    { stage: 0, name: "COMBEE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VESPIQUEEN", rarity: "unknown", cost: 3 },
  ],
  "CONKELDURR": [
    { maxStars: 1 },
    { stage: 0, name: "CONKELDURR", rarity: "unknown", cost: 1 },
  ],
  "CORPHISH": [
    { maxStars: 2 },
    { stage: 0, name: "CORPHISH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CRAWDAUNT", rarity: "unknown", cost: 3 },
  ],
  "CORSOLA": [
    { maxStars: 1 },
    { stage: 0, name: "CORSOLA", rarity: "unknown", cost: 1 },
  ],
  "COTTONEE": [
    { maxStars: 2 },
    { stage: 0, name: "COTTONEE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WHIMSICOTT", rarity: "unknown", cost: 3 },
  ],
  "CRABRAWLER": [
    { maxStars: 2 },
    { stage: 0, name: "CRABRAWLER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CRABOMINABLE", rarity: "unknown", cost: 3 },
  ],
  "CRANIDOS": [
    { maxStars: 2 },
    { stage: 0, name: "CRANIDOS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "RAMPARDOS", rarity: "unknown", cost: 3 },
  ],
  "CROAGUNK": [
    { maxStars: 2 },
    { stage: 0, name: "CROAGUNK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TOXICROAK", rarity: "unknown", cost: 3 },
  ],
  "CUBCHOO": [
    { maxStars: 2 },
    { stage: 0, name: "CUBCHOO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BEARTIC", rarity: "unknown", cost: 3 },
  ],
  "CUBONE": [
    { maxStars: 2 },
    { stage: 0, name: "CUBONE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MAROWAK", rarity: "unknown", cost: 3 },
  ],
  "CURSOLA": [
    { maxStars: 1 },
    { stage: 0, name: "CURSOLA", rarity: "unknown", cost: 1 },
  ],
  "CUTIEFLY": [
    { maxStars: 2 },
    { stage: 0, name: "CUTIEFLY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "RIBOMBEE", rarity: "unknown", cost: 3 },
  ],
  "CYNDAQUIL": [
    { maxStars: 3 },
    { stage: 0, name: "CYNDAQUIL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "QUILAVA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TYPHLOSION", rarity: "unknown", cost: 9 },
  ],
  "DARUMAKA": [
    { maxStars: 2 },
    { stage: 0, name: "DARUMAKA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DARMANITAN", rarity: "unknown", cost: 3 },
  ],
  "DEINO": [
    { maxStars: 3 },
    { stage: 0, name: "DEINO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ZWEILOUS", rarity: "unknown", cost: 3 },
    { stage: 2, name: "HYDREIGON", rarity: "unknown", cost: 9 },
  ],
  "DEWPIDER": [
    { maxStars: 2 },
    { stage: 0, name: "DEWPIDER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARAQUANID", rarity: "unknown", cost: 3 },
  ],
  "DIANCIE": [
    { maxStars: 1 },
    { stage: 0, name: "DIANCIE", rarity: "unknown", cost: 1 },
  ],
  "DIGLETT": [
    { maxStars: 2 },
    { stage: 0, name: "DIGLETT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DUGTRIO", rarity: "unknown", cost: 3 },
  ],
  "DODUO": [
    { maxStars: 2 },
    { stage: 0, name: "DODUO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DODRIO", rarity: "unknown", cost: 3 },
  ],
  "DRATINI": [
    { maxStars: 3 },
    { stage: 0, name: "DRATINI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DRAGONAIR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "DRAGONITE", rarity: "unknown", cost: 9 },
  ],
  "DRIFLOON": [
    { maxStars: 2 },
    { stage: 0, name: "DRIFLOON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DRIFBLIM", rarity: "unknown", cost: 3 },
  ],
  "DRILBUR": [
    { maxStars: 2 },
    { stage: 0, name: "DRILBUR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "EXCADRILL", rarity: "unknown", cost: 3 },
  ],
  "DROWZEE": [
    { maxStars: 2 },
    { stage: 0, name: "DROWZEE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HYPNO", rarity: "unknown", cost: 3 },
  ],
  "EKANS": [
    { maxStars: 2 },
    { stage: 0, name: "EKANS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARBOK", rarity: "unknown", cost: 3 },
  ],
  "ELECTRIKE": [
    { maxStars: 2 },
    { stage: 0, name: "ELECTRIKE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MANECTRIC", rarity: "unknown", cost: 3 },
  ],
  "ELEKID": [
    { maxStars: 3 },
    { stage: 0, name: "ELEKID", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ELECTABUZZ", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ELECTIVIRE", rarity: "unknown", cost: 9 },
  ],
  "ELGYEM": [
    { maxStars: 2 },
    { stage: 0, name: "ELGYEM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BEHEEYEM", rarity: "unknown", cost: 3 },
  ],
  "ESPURR": [
    { maxStars: 2 },
    { stage: 0, name: "ESPURR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MEOWSTICMALE", rarity: "unknown", cost: 3 },
  ],
  "EXEGGCUTE": [
    { maxStars: 2 },
    { stage: 0, name: "EXEGGCUTE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "EXEGGUTOR", rarity: "unknown", cost: 3 },
  ],
  "FENNEKIN": [
    { maxStars: 3 },
    { stage: 0, name: "FENNEKIN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BRAIXEN", rarity: "unknown", cost: 3 },
    { stage: 2, name: "DELPHOX", rarity: "unknown", cost: 9 },
  ],
  "FERROSEED": [
    { maxStars: 2 },
    { stage: 0, name: "FERROSEED", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FERROTHORN", rarity: "unknown", cost: 3 },
  ],
  "FIDOUGH": [
    { maxStars: 2 },
    { stage: 0, name: "FIDOUGH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DACHSBUN", rarity: "unknown", cost: 3 },
  ],
  "FINNEON": [
    { maxStars: 2 },
    { stage: 0, name: "FINNEON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LUMINEON", rarity: "unknown", cost: 3 },
  ],
  "FLABEBE": [
    { maxStars: 3 },
    { stage: 0, name: "FLABEBE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FLOETTE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "FLORGES", rarity: "unknown", cost: 9 },
  ],
  "FLETCHLING": [
    { maxStars: 3 },
    { stage: 0, name: "FLETCHLING", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FLETCHINDER", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TALONFLAME", rarity: "unknown", cost: 9 },
  ],
  "FOMANTIS": [
    { maxStars: 2 },
    { stage: 0, name: "FOMANTIS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LURANTIS", rarity: "unknown", cost: 3 },
  ],
  "FRIGIBAX": [
    { maxStars: 3 },
    { stage: 0, name: "FRIGIBAX", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARCTIBAX", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BAXCALIBUR", rarity: "unknown", cost: 9 },
  ],
  "FUECOCO": [
    { maxStars: 3 },
    { stage: 0, name: "FUECOCO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CROCALOR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SKELEDIRGE", rarity: "unknown", cost: 9 },
  ],
  "GALARCORSOLA": [
    { maxStars: 2 },
    { stage: 0, name: "GALARCORSOLA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CURSOLA", rarity: "unknown", cost: 3 },
  ],
  "GASTLY": [
    { maxStars: 3 },
    { stage: 0, name: "GASTLY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HAUNTER", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GENGAR", rarity: "unknown", cost: 9 },
  ],
  "GEODUDE": [
    { maxStars: 3 },
    { stage: 0, name: "GEODUDE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GRAVELER", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GOLEM", rarity: "unknown", cost: 9 },
  ],
  "GIBLE": [
    { maxStars: 3 },
    { stage: 0, name: "GIBLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GABITE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GARCHOMP", rarity: "unknown", cost: 9 },
  ],
  "GIRAFARIG": [
    { maxStars: 2 },
    { stage: 0, name: "GIRAFARIG", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FARIGIRAF", rarity: "unknown", cost: 3 },
  ],
  "GLAMEOW": [
    { maxStars: 2 },
    { stage: 0, name: "GLAMEOW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PURUGLY", rarity: "unknown", cost: 3 },
  ],
  "GLIGAR": [
    { maxStars: 2 },
    { stage: 0, name: "GLIGAR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GLISCOR", rarity: "unknown", cost: 3 },
  ],
  "GLIMMET": [
    { maxStars: 2 },
    { stage: 0, name: "GLIMMET", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GLIMMORA", rarity: "unknown", cost: 3 },
  ],
  "GOLDEEN": [
    { maxStars: 2 },
    { stage: 0, name: "GOLDEEN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SEAKING", rarity: "unknown", cost: 3 },
  ],
  "GOLETT": [
    { maxStars: 2 },
    { stage: 0, name: "GOLETT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GOLURK", rarity: "unknown", cost: 3 },
  ],
  "GOOMY": [
    { maxStars: 3 },
    { stage: 0, name: "GOOMY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SLIGOO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GOODRA", rarity: "unknown", cost: 9 },
  ],
  "GOSSIFLEUR": [
    { maxStars: 2 },
    { stage: 0, name: "GOSSIFLEUR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ELDEGOSS", rarity: "unknown", cost: 3 },
  ],
  "GREAVARD": [
    { maxStars: 2 },
    { stage: 0, name: "GREAVARD", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HOUNDSTONE", rarity: "unknown", cost: 3 },
  ],
  "GRIMER": [
    { maxStars: 2 },
    { stage: 0, name: "GRIMER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MUK", rarity: "unknown", cost: 3 },
  ],
  "GROOKEY": [
    { maxStars: 3 },
    { stage: 0, name: "GROOKEY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "THWACKEY", rarity: "unknown", cost: 3 },
    { stage: 2, name: "RILLABOOM", rarity: "unknown", cost: 9 },
  ],
  "GROWLITHE": [
    { maxStars: 2 },
    { stage: 0, name: "GROWLITHE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARCANINE", rarity: "unknown", cost: 3 },
  ],
  "GULPIN": [
    { maxStars: 2 },
    { stage: 0, name: "GULPIN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SWALOT", rarity: "unknown", cost: 3 },
  ],
  "GURDURR": [
    { maxStars: 1 },
    { stage: 0, name: "GURDURR", rarity: "unknown", cost: 1 },
  ],
  "HAPPINY": [
    { maxStars: 3 },
    { stage: 0, name: "HAPPINY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CHANSEY", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BLISSEY", rarity: "unknown", cost: 9 },
  ],
  "HATENNA": [
    { maxStars: 3 },
    { stage: 0, name: "HATENNA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HATTREM", rarity: "unknown", cost: 3 },
    { stage: 2, name: "HATTERENE", rarity: "unknown", cost: 9 },
  ],
  "HELIOPTILE": [
    { maxStars: 2 },
    { stage: 0, name: "HELIOPTILE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HELIOLISK", rarity: "unknown", cost: 3 },
  ],
  "HIPPOPOTAS": [
    { maxStars: 2 },
    { stage: 0, name: "HIPPOPOTAS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HIPPODOWN", rarity: "unknown", cost: 3 },
  ],
  "HONEDGE": [
    { maxStars: 3 },
    { stage: 0, name: "HONEDGE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DOUBLADE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "AEGISLASH", rarity: "unknown", cost: 9 },
  ],
  "HOOTHOOT": [
    { maxStars: 2 },
    { stage: 0, name: "HOOTHOOT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NOCTOWL", rarity: "unknown", cost: 3 },
  ],
  "HORSEA": [
    { maxStars: 3 },
    { stage: 0, name: "HORSEA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SEADRA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "KINGDRA", rarity: "unknown", cost: 9 },
  ],
  "HOUNDOUR": [
    { maxStars: 2 },
    { stage: 0, name: "HOUNDOUR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HOUNDOOM", rarity: "unknown", cost: 3 },
  ],
  "IGGLYBUFF": [
    { maxStars: 3 },
    { stage: 0, name: "IGGLYBUFF", rarity: "unknown", cost: 1 },
    { stage: 1, name: "JIGGLYPUFF", rarity: "unknown", cost: 3 },
    { stage: 2, name: "WIGGLYTUFF", rarity: "unknown", cost: 9 },
  ],
  "IMPIDIMP": [
    { maxStars: 3 },
    { stage: 0, name: "IMPIDIMP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MORGREM", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GRIMMSNARL", rarity: "unknown", cost: 9 },
  ],
  "INKAY": [
    { maxStars: 2 },
    { stage: 0, name: "INKAY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MALAMAR", rarity: "unknown", cost: 3 },
  ],
  "JANGMOO": [
    { maxStars: 3 },
    { stage: 0, name: "JANGMOO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HAKAMOO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "KOMMOO", rarity: "unknown", cost: 9 },
  ],
  "JOLTIK": [
    { maxStars: 2 },
    { stage: 0, name: "JOLTIK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GALVANTULA", rarity: "unknown", cost: 3 },
  ],
  "KABUTO": [
    { maxStars: 2 },
    { stage: 0, name: "KABUTO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KABUTOPS", rarity: "unknown", cost: 3 },
  ],
  "KLINK": [
    { maxStars: 3 },
    { stage: 0, name: "KLINK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KLANG", rarity: "unknown", cost: 3 },
    { stage: 2, name: "KLINKLANG", rarity: "unknown", cost: 9 },
  ],
  "KOFFING": [
    { maxStars: 2 },
    { stage: 0, name: "KOFFING", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WEEZING", rarity: "unknown", cost: 3 },
  ],
  "KRABBY": [
    { maxStars: 2 },
    { stage: 0, name: "KRABBY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KINGLER", rarity: "unknown", cost: 3 },
  ],
  "KRICKETOT": [
    { maxStars: 2 },
    { stage: 0, name: "KRICKETOT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KRICKETUNE", rarity: "unknown", cost: 3 },
  ],
  "LARVESTA": [
    { maxStars: 2 },
    { stage: 0, name: "LARVESTA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VOLCARONA", rarity: "unknown", cost: 3 },
  ],
  "LARVITAR": [
    { maxStars: 3 },
    { stage: 0, name: "LARVITAR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PUPITAR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TYRANITAR", rarity: "unknown", cost: 9 },
  ],
  "LEDYBA": [
    { maxStars: 2 },
    { stage: 0, name: "LEDYBA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LEDIAN", rarity: "unknown", cost: 3 },
  ],
  "LICKITUNG": [
    { maxStars: 2 },
    { stage: 0, name: "LICKITUNG", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LICKILICKY", rarity: "unknown", cost: 3 },
  ],
  "LILEEP": [
    { maxStars: 2 },
    { stage: 0, name: "LILEEP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CRADILY", rarity: "unknown", cost: 3 },
  ],
  "LILLIPUP": [
    { maxStars: 3 },
    { stage: 0, name: "LILLIPUP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HERDIER", rarity: "unknown", cost: 3 },
    { stage: 2, name: "STOUTLAND", rarity: "unknown", cost: 9 },
  ],
  "LITTEN": [
    { maxStars: 3 },
    { stage: 0, name: "LITTEN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TORRACAT", rarity: "unknown", cost: 3 },
    { stage: 2, name: "INCINEROAR", rarity: "unknown", cost: 9 },
  ],
  "LITWICK": [
    { maxStars: 3 },
    { stage: 0, name: "LITWICK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LAMPENT", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CHANDELURE", rarity: "unknown", cost: 9 },
  ],
  "LOTAD": [
    { maxStars: 3 },
    { stage: 0, name: "LOTAD", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LOMBRE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "LUDICOLO", rarity: "unknown", cost: 9 },
  ],
  "MACHOP": [
    { maxStars: 3 },
    { stage: 0, name: "MACHOP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MACHOKE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "MACHAMP", rarity: "unknown", cost: 9 },
  ],
  "MAGBY": [
    { maxStars: 3 },
    { stage: 0, name: "MAGBY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MAGMAR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "MAGMORTAR", rarity: "unknown", cost: 9 },
  ],
  "MAGNEMITE": [
    { maxStars: 3 },
    { stage: 0, name: "MAGNEMITE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MAGNETON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "MAGNEZONE", rarity: "unknown", cost: 9 },
  ],
  "MAKUHITA": [
    { maxStars: 2 },
    { stage: 0, name: "MAKUHITA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HARIYAMA", rarity: "unknown", cost: 3 },
  ],
  "MANKEY": [
    { maxStars: 3 },
    { stage: 0, name: "MANKEY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PRIMEAPE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ANNIHILAPE", rarity: "unknown", cost: 9 },
  ],
  "MAREEP": [
    { maxStars: 3 },
    { stage: 0, name: "MAREEP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FLAFFY", rarity: "unknown", cost: 3 },
    { stage: 2, name: "AMPHAROS", rarity: "unknown", cost: 9 },
  ],
  "MEDITITE": [
    { maxStars: 2 },
    { stage: 0, name: "MEDITITE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MEDICHAM", rarity: "unknown", cost: 3 },
  ],
  "MEOWTH": [
    { maxStars: 2 },
    { stage: 0, name: "MEOWTH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PERSIAN", rarity: "unknown", cost: 3 },
  ],
  "MIENFOO": [
    { maxStars: 2 },
    { stage: 0, name: "MIENFOO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MIENSHAO", rarity: "unknown", cost: 3 },
  ],
  "MIMEJR": [
    { maxStars: 2 },
    { stage: 0, name: "MIMEJR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MRMIME", rarity: "unknown", cost: 3 },
  ],
  "MINCCINO": [
    { maxStars: 2 },
    { stage: 0, name: "MINCCINO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CINCCINO", rarity: "unknown", cost: 3 },
  ],
  "MISDREAVUS": [
    { maxStars: 2 },
    { stage: 0, name: "MISDREAVUS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MISMAGIUS", rarity: "unknown", cost: 3 },
  ],
  "MUDKIP": [
    { maxStars: 3 },
    { stage: 0, name: "MUDKIP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MARSHTOMP", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SWAMPERT", rarity: "unknown", cost: 9 },
  ],
  "MUNCHLAX": [
    { maxStars: 2 },
    { stage: 0, name: "MUNCHLAX", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SNORLAX", rarity: "unknown", cost: 3 },
  ],
  "MUNNA": [
    { maxStars: 2 },
    { stage: 0, name: "MUNNA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MUSHARNA", rarity: "unknown", cost: 3 },
  ],
  "MURKROW": [
    { maxStars: 2 },
    { stage: 0, name: "MURKROW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "HONCHKROW", rarity: "unknown", cost: 3 },
  ],
  "NACLI": [
    { maxStars: 3 },
    { stage: 0, name: "NACLI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NACLSTACK", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GARGANACL", rarity: "unknown", cost: 9 },
  ],
  "NATU": [
    { maxStars: 2 },
    { stage: 0, name: "NATU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "XATU", rarity: "unknown", cost: 3 },
  ],
  "NICKIT": [
    { maxStars: 2 },
    { stage: 0, name: "NICKIT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "THIEVUL", rarity: "unknown", cost: 3 },
  ],
  "NIDORANF": [
    { maxStars: 3 },
    { stage: 0, name: "NIDORANF", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NIDORINA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "NIDOQUEEN", rarity: "unknown", cost: 9 },
  ],
  "NIDORANM": [
    { maxStars: 3 },
    { stage: 0, name: "NIDORANM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NIDORINO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "NIDOKING", rarity: "unknown", cost: 9 },
  ],
  "NINCADA": [
    { maxStars: 3 },
    { stage: 0, name: "NINCADA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NINJASK", rarity: "unknown", cost: 3 },
    { stage: 1, name: "SHEDINJA", rarity: "unknown", cost: 3 },
  ],
  "NINETALES": [
    { maxStars: 1 },
    { stage: 0, name: "NINETALES", rarity: "unknown", cost: 1 },
  ],
  "NOIBAT": [
    { maxStars: 2 },
    { stage: 0, name: "NOIBAT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NOIVERN", rarity: "unknown", cost: 3 },
  ],
  "NOSEPASS": [
    { maxStars: 2 },
    { stage: 0, name: "NOSEPASS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PROBOPASS", rarity: "unknown", cost: 3 },
  ],
  "NUMEL": [
    { maxStars: 2 },
    { stage: 0, name: "NUMEL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CAMERUPT", rarity: "unknown", cost: 3 },
  ],
  "NYMBLE": [
    { maxStars: 2 },
    { stage: 0, name: "NYMBLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LOKIX", rarity: "unknown", cost: 3 },
  ],
  "OMANYTE": [
    { maxStars: 2 },
    { stage: 0, name: "OMANYTE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "OMASTAR", rarity: "unknown", cost: 3 },
  ],
  "ONIX": [
    { maxStars: 2 },
    { stage: 0, name: "ONIX", rarity: "unknown", cost: 1 },
    { stage: 1, name: "STEELIX", rarity: "unknown", cost: 3 },
  ],
  "OSHAWOTT": [
    { maxStars: 3 },
    { stage: 0, name: "OSHAWOTT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DEWOTT", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SAMUROTT", rarity: "unknown", cost: 9 },
  ],
  "PALDEAWOOPER": [
    { maxStars: 2 },
    { stage: 0, name: "PALDEAWOOPER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CLODSIRE", rarity: "unknown", cost: 3 },
  ],
  "PANCHAM": [
    { maxStars: 2 },
    { stage: 0, name: "PANCHAM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PANGORO", rarity: "unknown", cost: 3 },
  ],
  "PARAS": [
    { maxStars: 2 },
    { stage: 0, name: "PARAS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PARASECT", rarity: "unknown", cost: 3 },
  ],
  "PATRAT": [
    { maxStars: 2 },
    { stage: 0, name: "PATRAT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WATCHOG", rarity: "unknown", cost: 3 },
  ],
  "PAWMI": [
    { maxStars: 3 },
    { stage: 0, name: "PAWMI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PAWMO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "PAWMOT", rarity: "unknown", cost: 9 },
  ],
  "PAWNIARD": [
    { maxStars: 3 },
    { stage: 0, name: "PAWNIARD", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BISHARP", rarity: "unknown", cost: 3 },
    { stage: 2, name: "KINGAMBIT", rarity: "unknown", cost: 9 },
  ],
  "PETILIL": [
    { maxStars: 2 },
    { stage: 0, name: "PETILIL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LILLIGANT", rarity: "unknown", cost: 3 },
  ],
  "PHANPY": [
    { maxStars: 2 },
    { stage: 0, name: "PHANPY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DONPHAN", rarity: "unknown", cost: 3 },
  ],
  "PHANTUMP": [
    { maxStars: 2 },
    { stage: 0, name: "PHANTUMP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TREVENANT", rarity: "unknown", cost: 3 },
  ],
  "PICHU": [
    { maxStars: 3 },
    { stage: 0, name: "PICHU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PIKACHU", rarity: "unknown", cost: 3 },
    { stage: 2, name: "RAICHU", rarity: "unknown", cost: 9 },
  ],
  "PIDGEY": [
    { maxStars: 3 },
    { stage: 0, name: "PIDGEY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PIDGEOTTO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "PIDGEOT", rarity: "unknown", cost: 9 },
  ],
  "PIDOVE": [
    { maxStars: 3 },
    { stage: 0, name: "PIDOVE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TRANQUILL", rarity: "unknown", cost: 3 },
    { stage: 2, name: "UNFEZANT", rarity: "unknown", cost: 9 },
  ],
  "PINECO": [
    { maxStars: 2 },
    { stage: 0, name: "PINECO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FORRETRESS", rarity: "unknown", cost: 3 },
  ],
  "PIPLUP": [
    { maxStars: 3 },
    { stage: 0, name: "PIPLUP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PRINPLUP", rarity: "unknown", cost: 3 },
    { stage: 2, name: "EMPOLEON", rarity: "unknown", cost: 9 },
  ],
  "POLIWAG": [
    { maxStars: 4 },
    { stage: 0, name: "POLIWAG", rarity: "unknown", cost: 1 },
    { stage: 1, name: "POLIWHIRL", rarity: "unknown", cost: 3 },
    { stage: 2, name: "POLIWRATH", rarity: "unknown", cost: 9 },
    { stage: 2, name: "POLITOED", rarity: "unknown", cost: 9 },
  ],
  "PONYTA": [
    { maxStars: 2 },
    { stage: 0, name: "PONYTA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "RAPIDASH", rarity: "unknown", cost: 3 },
  ],
  "POOCHYENA": [
    { maxStars: 2 },
    { stage: 0, name: "POOCHYENA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MIGHTYENA", rarity: "unknown", cost: 3 },
  ],
  "PORYGON": [
    { maxStars: 3 },
    { stage: 0, name: "PORYGON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PORYGON2", rarity: "unknown", cost: 3 },
    { stage: 2, name: "PORYGONZ", rarity: "unknown", cost: 9 },
  ],
  "PSYDUCK": [
    { maxStars: 2 },
    { stage: 0, name: "PSYDUCK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GOLDUCK", rarity: "unknown", cost: 3 },
  ],
  "PUMPKABOO": [
    { maxStars: 2 },
    { stage: 0, name: "PUMPKABOO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GOURGEIST", rarity: "unknown", cost: 3 },
  ],
  "PURRLOIN": [
    { maxStars: 2 },
    { stage: 0, name: "PURRLOIN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LIEPARD", rarity: "unknown", cost: 3 },
  ],
  "RALTS": [
    { maxStars: 4 },
    { stage: 0, name: "RALTS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KIRLIA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GARDEVOIR", rarity: "unknown", cost: 9 },
    { stage: 2, name: "GALLADE", rarity: "unknown", cost: 9 },
  ],
  "RATTATA": [
    { maxStars: 2 },
    { stage: 0, name: "RATTATA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "RATICATE", rarity: "unknown", cost: 3 },
  ],
  "RHYHORN": [
    { maxStars: 3 },
    { stage: 0, name: "RHYHORN", rarity: "unknown", cost: 1 },
    { stage: 1, name: "RHYDON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "RHYPERIOR", rarity: "unknown", cost: 9 },
  ],
  "RIOLU": [
    { maxStars: 2 },
    { stage: 0, name: "RIOLU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LUCARIO", rarity: "unknown", cost: 3 },
  ],
  "ROCKRUFF": [
    { maxStars: 2 },
    { stage: 0, name: "ROCKRUFF", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LYCANROCDAY", rarity: "unknown", cost: 3 },
  ],
  "ROGGENROLA": [
    { maxStars: 3 },
    { stage: 0, name: "ROGGENROLA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BOLDORE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "GIGALITH", rarity: "unknown", cost: 9 },
  ],
  "ROOKIDEE": [
    { maxStars: 3 },
    { stage: 0, name: "ROOKIDEE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CORVISQUIRE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CORVIKNIGHT", rarity: "unknown", cost: 9 },
  ],
  "RUFFLET": [
    { maxStars: 2 },
    { stage: 0, name: "RUFFLET", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BRAVIARY", rarity: "unknown", cost: 3 },
  ],
  "SALANDIT": [
    { maxStars: 2 },
    { stage: 0, name: "SALANDIT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SALAZZLE", rarity: "unknown", cost: 3 },
  ],
  "SANDSHREW": [
    { maxStars: 2 },
    { stage: 0, name: "SANDSHREW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SANDSLASH", rarity: "unknown", cost: 3 },
  ],
  "SANDSLASH": [
    { maxStars: 1 },
    { stage: 0, name: "SANDSLASH", rarity: "unknown", cost: 1 },
  ],
  "SCRAGGY": [
    { maxStars: 2 },
    { stage: 0, name: "SCRAGGY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SCRAFTY", rarity: "unknown", cost: 3 },
  ],
  "SEEDOT": [
    { maxStars: 3 },
    { stage: 0, name: "SEEDOT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NUZLEAF", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SHIFTRY", rarity: "unknown", cost: 9 },
  ],
  "SEEL": [
    { maxStars: 2 },
    { stage: 0, name: "SEEL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DEWGONG", rarity: "unknown", cost: 3 },
  ],
  "SENTRET": [
    { maxStars: 2 },
    { stage: 0, name: "SENTRET", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FURRET", rarity: "unknown", cost: 3 },
  ],
  "SEWADDLE": [
    { maxStars: 3 },
    { stage: 0, name: "SEWADDLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SWADLOON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "LEAVANNY", rarity: "unknown", cost: 9 },
  ],
  "SHELLDER": [
    { maxStars: 2 },
    { stage: 0, name: "SHELLDER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CLOYSTER", rarity: "unknown", cost: 3 },
  ],
  "SHIELDON": [
    { maxStars: 2 },
    { stage: 0, name: "SHIELDON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BASTIODON", rarity: "unknown", cost: 3 },
  ],
  "SHINX": [
    { maxStars: 3 },
    { stage: 0, name: "SHINX", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LUXIO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "LUXRAY", rarity: "unknown", cost: 9 },
  ],
  "SHROOMISH": [
    { maxStars: 2 },
    { stage: 0, name: "SHROOMISH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BRELOOM", rarity: "unknown", cost: 3 },
  ],
  "SHUPPET": [
    { maxStars: 2 },
    { stage: 0, name: "SHUPPET", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BANETTE", rarity: "unknown", cost: 3 },
  ],
  "SILICOBRA": [
    { maxStars: 2 },
    { stage: 0, name: "SILICOBRA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SANDACONDA", rarity: "unknown", cost: 3 },
  ],
  "SINISTEA": [
    { maxStars: 2 },
    { stage: 0, name: "SINISTEA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "POLTEAGEIST", rarity: "unknown", cost: 3 },
  ],
  "SIZZLIPEDE": [
    { maxStars: 2 },
    { stage: 0, name: "SIZZLIPEDE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CENTISKORCH", rarity: "unknown", cost: 3 },
  ],
  "SKITTY": [
    { maxStars: 2 },
    { stage: 0, name: "SKITTY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DELCATTY", rarity: "unknown", cost: 3 },
  ],
  "SKORUPI": [
    { maxStars: 2 },
    { stage: 0, name: "SKORUPI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DRAPION", rarity: "unknown", cost: 3 },
  ],
  "SKRELP": [
    { maxStars: 2 },
    { stage: 0, name: "SKRELP", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DRAGALGE", rarity: "unknown", cost: 3 },
  ],
  "SLAKOTH": [
    { maxStars: 3 },
    { stage: 0, name: "SLAKOTH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VIGOROTH", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SLAKING", rarity: "unknown", cost: 9 },
  ],
  "SLOWPOKE": [
    { maxStars: 3 },
    { stage: 0, name: "SLOWPOKE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SLOWBRO", rarity: "unknown", cost: 3 },
    { stage: 1, name: "SLOWKING", rarity: "unknown", cost: 3 },
  ],
  "SLUGMA": [
    { maxStars: 2 },
    { stage: 0, name: "SLUGMA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MAGCARGO", rarity: "unknown", cost: 3 },
  ],
  "SMOLIV": [
    { maxStars: 3 },
    { stage: 0, name: "SMOLIV", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DOLLIV", rarity: "unknown", cost: 3 },
    { stage: 2, name: "ARBOLIVA", rarity: "unknown", cost: 9 },
  ],
  "SMOOCHUM": [
    { maxStars: 2 },
    { stage: 0, name: "SMOOCHUM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "JYNX", rarity: "unknown", cost: 3 },
  ],
  "SNEASEL": [
    { maxStars: 2 },
    { stage: 0, name: "SNEASEL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WEAVILE", rarity: "unknown", cost: 3 },
  ],
  "SNOM": [
    { maxStars: 2 },
    { stage: 0, name: "SNOM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FROSMOTH", rarity: "unknown", cost: 3 },
  ],
  "SNORUNT": [
    { maxStars: 3 },
    { stage: 0, name: "SNORUNT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GLALIE", rarity: "unknown", cost: 3 },
    { stage: 1, name: "FROSLASS", rarity: "unknown", cost: 3 },
  ],
  "SNOVER": [
    { maxStars: 2 },
    { stage: 0, name: "SNOVER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ABOMASNOW", rarity: "unknown", cost: 3 },
  ],
  "SNUBULL": [
    { maxStars: 2 },
    { stage: 0, name: "SNUBULL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GRANBULL", rarity: "unknown", cost: 3 },
  ],
  "SOBBLE": [
    { maxStars: 3 },
    { stage: 0, name: "SOBBLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DRIZZILE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "INTELEON", rarity: "unknown", cost: 9 },
  ],
  "SOLOSIS": [
    { maxStars: 3 },
    { stage: 0, name: "SOLOSIS", rarity: "unknown", cost: 1 },
    { stage: 1, name: "DUOSION", rarity: "unknown", cost: 3 },
    { stage: 2, name: "REUNICLUS", rarity: "unknown", cost: 9 },
  ],
  "SPEAROW": [
    { maxStars: 2 },
    { stage: 0, name: "SPEAROW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FEAROW", rarity: "unknown", cost: 3 },
  ],
  "SPHEAL": [
    { maxStars: 3 },
    { stage: 0, name: "SPHEAL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SEALEO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "WALREIN", rarity: "unknown", cost: 9 },
  ],
  "SPINARAK": [
    { maxStars: 2 },
    { stage: 0, name: "SPINARAK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ARIADOS", rarity: "unknown", cost: 3 },
  ],
  "SPOINK": [
    { maxStars: 2 },
    { stage: 0, name: "SPOINK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GRUMPIG", rarity: "unknown", cost: 3 },
  ],
  "SPRIGATITO": [
    { maxStars: 3 },
    { stage: 0, name: "SPRIGATITO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "FLORAGATO", rarity: "unknown", cost: 3 },
    { stage: 2, name: "MEOWSCARADA", rarity: "unknown", cost: 9 },
  ],
  "SQUIRTLE": [
    { maxStars: 3 },
    { stage: 0, name: "SQUIRTLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WARTORTLE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BLASTOISE", rarity: "unknown", cost: 9 },
  ],
  "STARLY": [
    { maxStars: 3 },
    { stage: 0, name: "STARLY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "STARAVIA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "STARAPTOR", rarity: "unknown", cost: 9 },
  ],
  "STARYU": [
    { maxStars: 2 },
    { stage: 0, name: "STARYU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "STARMIE", rarity: "unknown", cost: 3 },
  ],
  "STUFFUL": [
    { maxStars: 2 },
    { stage: 0, name: "STUFFUL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BEWEAR", rarity: "unknown", cost: 3 },
  ],
  "STUNKY": [
    { maxStars: 2 },
    { stage: 0, name: "STUNKY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SKUNTANK", rarity: "unknown", cost: 3 },
  ],
  "SURSKIT": [
    { maxStars: 2 },
    { stage: 0, name: "SURSKIT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MASQUERAIN", rarity: "unknown", cost: 3 },
  ],
  "SWABLU": [
    { maxStars: 2 },
    { stage: 0, name: "SWABLU", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ALTARIA", rarity: "unknown", cost: 3 },
  ],
  "SWINUB": [
    { maxStars: 3 },
    { stage: 0, name: "SWINUB", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PILOSWINE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "MAMOSWINE", rarity: "unknown", cost: 9 },
  ],
  "TADBULB": [
    { maxStars: 2 },
    { stage: 0, name: "TADBULB", rarity: "unknown", cost: 1 },
    { stage: 1, name: "BELLIBOLT", rarity: "unknown", cost: 3 },
  ],
  "TAILLOW": [
    { maxStars: 2 },
    { stage: 0, name: "TAILLOW", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SWELLOW", rarity: "unknown", cost: 3 },
  ],
  "TANGELA": [
    { maxStars: 2 },
    { stage: 0, name: "TANGELA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TANGROWTH", rarity: "unknown", cost: 3 },
  ],
  "TEDDIURSA": [
    { maxStars: 3 },
    { stage: 0, name: "TEDDIURSA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "URSARING", rarity: "unknown", cost: 3 },
    { stage: 2, name: "URSALUNA", rarity: "unknown", cost: 9 },
  ],
  "TENTACOOL": [
    { maxStars: 2 },
    { stage: 0, name: "TENTACOOL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TENTACRUEL", rarity: "unknown", cost: 3 },
  ],
  "TIMBURR": [
    { maxStars: 3 },
    { stage: 0, name: "TIMBURR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GURDURR", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CONKELDURR", rarity: "unknown", cost: 9 },
  ],
  "TINKATINK": [
    { maxStars: 3 },
    { stage: 0, name: "TINKATINK", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TINKATUFF", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TINKATON", rarity: "unknown", cost: 9 },
  ],
  "TOGEPI": [
    { maxStars: 3 },
    { stage: 0, name: "TOGEPI", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TOGETIC", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TOGEKISS", rarity: "unknown", cost: 9 },
  ],
  "TORCHIC": [
    { maxStars: 3 },
    { stage: 0, name: "TORCHIC", rarity: "unknown", cost: 1 },
    { stage: 1, name: "COMBUSKEN", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BLAZIKEN", rarity: "unknown", cost: 9 },
  ],
  "TOTODILE": [
    { maxStars: 3 },
    { stage: 0, name: "TOTODILE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "CROCONAW", rarity: "unknown", cost: 3 },
    { stage: 2, name: "FERALIGATR", rarity: "unknown", cost: 9 },
  ],
  "TOXEL": [
    { maxStars: 2 },
    { stage: 0, name: "TOXEL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TOXTRICITY", rarity: "unknown", cost: 3 },
  ],
  "TRAPINCH": [
    { maxStars: 3 },
    { stage: 0, name: "TRAPINCH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VIBRAVA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "FLYGON", rarity: "unknown", cost: 9 },
  ],
  "TREECKO": [
    { maxStars: 3 },
    { stage: 0, name: "TREECKO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GROVYLE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SCEPTILE", rarity: "unknown", cost: 9 },
  ],
  "TRUBBISH": [
    { maxStars: 2 },
    { stage: 0, name: "TRUBBISH", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GARBODOR", rarity: "unknown", cost: 3 },
  ],
  "TURTWIG": [
    { maxStars: 3 },
    { stage: 0, name: "TURTWIG", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GROTLE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "TORTERRA", rarity: "unknown", cost: 9 },
  ],
  "TYNAMO": [
    { maxStars: 3 },
    { stage: 0, name: "TYNAMO", rarity: "unknown", cost: 1 },
    { stage: 1, name: "EELEKTRIK", rarity: "unknown", cost: 3 },
    { stage: 2, name: "EELEKTROSS", rarity: "unknown", cost: 9 },
  ],
  "TYRUNT": [
    { maxStars: 2 },
    { stage: 0, name: "TYRUNT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "TYRANTRUM", rarity: "unknown", cost: 3 },
  ],
  "VANILLITE": [
    { maxStars: 3 },
    { stage: 0, name: "VANILLITE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VANILLISH", rarity: "unknown", cost: 3 },
    { stage: 2, name: "VANILLUXE", rarity: "unknown", cost: 9 },
  ],
  "VAROOM": [
    { maxStars: 2 },
    { stage: 0, name: "VAROOM", rarity: "unknown", cost: 1 },
    { stage: 1, name: "REVAVROOM", rarity: "unknown", cost: 3 },
  ],
  "VENIPEDE": [
    { maxStars: 3 },
    { stage: 0, name: "VENIPEDE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WHIRLIPEDE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "SCOLIPEDE", rarity: "unknown", cost: 9 },
  ],
  "VENONAT": [
    { maxStars: 2 },
    { stage: 0, name: "VENONAT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "VENOMOTH", rarity: "unknown", cost: 3 },
  ],
  "VOLTORB": [
    { maxStars: 2 },
    { stage: 0, name: "VOLTORB", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ELECTRODE", rarity: "unknown", cost: 3 },
  ],
  "VULLABY": [
    { maxStars: 2 },
    { stage: 0, name: "VULLABY", rarity: "unknown", cost: 1 },
    { stage: 1, name: "MANDIBUZZ", rarity: "unknown", cost: 3 },
  ],
  "VULPIX": [
    { maxStars: 2 },
    { stage: 0, name: "VULPIX", rarity: "unknown", cost: 1 },
    { stage: 1, name: "NINETALES", rarity: "unknown", cost: 3 },
  ],
  "WAILMER": [
    { maxStars: 2 },
    { stage: 0, name: "WAILMER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WAILORD", rarity: "unknown", cost: 3 },
  ],
  "WATTREL": [
    { maxStars: 2 },
    { stage: 0, name: "WATTREL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KILOWATTREL", rarity: "unknown", cost: 3 },
  ],
  "WEEDLE": [
    { maxStars: 3 },
    { stage: 0, name: "WEEDLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "KAKUNA", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BEEDRILL", rarity: "unknown", cost: 9 },
  ],
  "WEEZING": [
    { maxStars: 2 },
    { stage: 0, name: "KOFFING", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WEEZING", rarity: "unknown", cost: 3 },
  ],
  "WHISMUR": [
    { maxStars: 3 },
    { stage: 0, name: "WHISMUR", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LOUDRED", rarity: "unknown", cost: 3 },
    { stage: 2, name: "EXPLOUD", rarity: "unknown", cost: 9 },
  ],
  "WIGLETT": [
    { maxStars: 2 },
    { stage: 0, name: "WIGLETT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WUGTRIO", rarity: "unknown", cost: 3 },
  ],
  "WIMPOD": [
    { maxStars: 2 },
    { stage: 0, name: "WIMPOD", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GOLISOPOD", rarity: "unknown", cost: 3 },
  ],
  "WINGULL": [
    { maxStars: 2 },
    { stage: 0, name: "WINGULL", rarity: "unknown", cost: 1 },
    { stage: 1, name: "PELIPPER", rarity: "unknown", cost: 3 },
  ],
  "WOOBAT": [
    { maxStars: 2 },
    { stage: 0, name: "WOOBAT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SWOOBAT", rarity: "unknown", cost: 3 },
  ],
  "WOOPER": [
    { maxStars: 2 },
    { stage: 0, name: "WOOPER", rarity: "unknown", cost: 1 },
    { stage: 1, name: "QUAGSIRE", rarity: "unknown", cost: 3 },
  ],
  "WURMPLE": [
    { maxStars: 5 },
    { stage: 0, name: "WURMPLE", rarity: "unknown", cost: 1 },
    { stage: 1, name: "SILCOON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "BEAUTIFLY", rarity: "unknown", cost: 9 },
    { stage: 1, name: "CASCOON", rarity: "unknown", cost: 3 },
    { stage: 2, name: "DUSTOX", rarity: "unknown", cost: 9 },
  ],
  "WYNAUT": [
    { maxStars: 2 },
    { stage: 0, name: "WYNAUT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "WOBBUFFET", rarity: "unknown", cost: 3 },
  ],
  "YANMA": [
    { maxStars: 2 },
    { stage: 0, name: "YANMA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "YANMEGA", rarity: "unknown", cost: 3 },
  ],
  "ZIGZAGOON": [
    { maxStars: 3 },
    { stage: 0, name: "ZIGZAGOON", rarity: "unknown", cost: 1 },
    { stage: 1, name: "LINOONE", rarity: "unknown", cost: 3 },
    { stage: 2, name: "OBSTAGOON", rarity: "unknown", cost: 9 },
  ],
  "ZORUA": [
    { maxStars: 2 },
    { stage: 0, name: "ZORUA", rarity: "unknown", cost: 1 },
    { stage: 1, name: "ZOROARK", rarity: "unknown", cost: 3 },
  ],
  "ZUBAT": [
    { maxStars: 3 },
    { stage: 0, name: "ZUBAT", rarity: "unknown", cost: 1 },
    { stage: 1, name: "GOLBAT", rarity: "unknown", cost: 3 },
    { stage: 2, name: "CROBAT", rarity: "unknown", cost: 9 },
  ],
};

// Map of all pokemon names to their base forms
const POKEMON_TO_BASE = {
  "ABOMASNOW": "SNOVER",
  "ABRA": "ABRA",
  "AEGISLASH": "HONEDGE",
  "AGGRON": "ARON",
  "AIPOM": "AIPOM",
  "ALAKAZAM": "ABRA",
  "ALTARIA": "SWABLU",
  "AMAURA": "AMAURA",
  "AMBIPOM": "AIPOM",
  "AMPHAROS": "MAREEP",
  "ANNIHILAPE": "MANKEY",
  "ANORITH": "ANORITH",
  "ARAQUANID": "DEWPIDER",
  "ARBOK": "EKANS",
  "ARBOLIVA": "SMOLIV",
  "ARCANINE": "GROWLITHE",
  "ARCHEN": "ARCHEN",
  "ARCHEOPS": "ARCHEN",
  "ARCTIBAX": "FRIGIBAX",
  "ARIADOS": "SPINARAK",
  "ARMALDO": "ANORITH",
  "ARON": "ARON",
  "AURORUS": "AMAURA",
  "AZUMARILL": "AZURILL",
  "AZURILL": "AZURILL",
  "BAGON": "BAGON",
  "BALTOY": "BALTOY",
  "BANETTE": "SHUPPET",
  "BARBARACLE": "BINACLE",
  "BARBOACH": "BARBOACH",
  "BASTIODON": "SHIELDON",
  "BAXCALIBUR": "FRIGIBAX",
  "BEARTIC": "CUBCHOO",
  "BEAUTIFLY": "WURMPLE",
  "BEEDRILL": "WEEDLE",
  "BEHEEYEM": "ELGYEM",
  "BELDUM": "BELDUM",
  "BELLIBOLT": "TADBULB",
  "BEWEAR": "STUFFUL",
  "BIBAREL": "BIDOOF",
  "BIDOOF": "BIDOOF",
  "BINACLE": "BINACLE",
  "BISHARP": "PAWNIARD",
  "BLASTOISE": "SQUIRTLE",
  "BLAZIKEN": "TORCHIC",
  "BLIPBUG": "BLIPBUG",
  "BLISSEY": "HAPPINY",
  "BOLDORE": "ROGGENROLA",
  "BONSLEY": "BONSLEY",
  "BOUNSWEET": "BOUNSWEET",
  "BRAIXEN": "FENNEKIN",
  "BRAVIARY": "RUFFLET",
  "BRELOOM": "SHROOMISH",
  "BRONZONG": "BRONZOR",
  "BRONZOR": "BRONZOR",
  "BUDEW": "BUDEW",
  "BUIZEL": "BUIZEL",
  "BULBASAUR": "BULBASAUR",
  "BUNEARY": "BUNEARY",
  "BUTTERFREE": "CATERPIE",
  "CACNEA": "CACNEA",
  "CACTURNE": "CACNEA",
  "CAMERUPT": "NUMEL",
  "CAPSAKID": "CAPSAKID",
  "CARBINK": "CARBINK",
  "CARVANHA": "CARVANHA",
  "CASCOON": "WURMPLE",
  "CATERPIE": "CATERPIE",
  "CENTISKORCH": "SIZZLIPEDE",
  "CHANDELURE": "LITWICK",
  "CHANSEY": "HAPPINY",
  "CHARIZARD": "CHARMANDER",
  "CHARMANDER": "CHARMANDER",
  "CHARMELEON": "CHARMANDER",
  "CHERRIM": "CHERUBI",
  "CHERUBI": "CHERUBI",
  "CHESNAUGHT": "CHESPIN",
  "CHESPIN": "CHESPIN",
  "CHEWTLE": "CHEWTLE",
  "CHIMCHAR": "CHIMCHAR",
  "CHINCHOU": "CHINCHOU",
  "CINCCINO": "MINCCINO",
  "CLAMPERL": "CLAMPERL",
  "CLAUNCHER": "CLAUNCHER",
  "CLAWITZER": "CLAUNCHER",
  "CLAYDOL": "BALTOY",
  "CLEFABLE": "CLEFFA",
  "CLEFAIRY": "CLEFFA",
  "CLEFFA": "CLEFFA",
  "CLOBBOPUS": "CLOBBOPUS",
  "CLODSIRE": "PALDEAWOOPER",
  "CLOYSTER": "SHELLDER",
  "COMBEE": "COMBEE",
  "COMBUSKEN": "TORCHIC",
  "CONKELDURR": "TIMBURR",
  "CORPHISH": "CORPHISH",
  "CORSOLA": "CORSOLA",
  "CORVIKNIGHT": "ROOKIDEE",
  "CORVISQUIRE": "ROOKIDEE",
  "COTTONEE": "COTTONEE",
  "CRABOMINABLE": "CRABRAWLER",
  "CRABRAWLER": "CRABRAWLER",
  "CRADILY": "LILEEP",
  "CRANIDOS": "CRANIDOS",
  "CRAWDAUNT": "CORPHISH",
  "CROAGUNK": "CROAGUNK",
  "CROBAT": "ZUBAT",
  "CROCALOR": "FUECOCO",
  "CROCONAW": "TOTODILE",
  "CUBCHOO": "CUBCHOO",
  "CUBONE": "CUBONE",
  "CURSOLA": "GALARCORSOLA",
  "CUTIEFLY": "CUTIEFLY",
  "CYNDAQUIL": "CYNDAQUIL",
  "DACHSBUN": "FIDOUGH",
  "DARMANITAN": "DARUMAKA",
  "DARUMAKA": "DARUMAKA",
  "DEINO": "DEINO",
  "DELCATTY": "SKITTY",
  "DELPHOX": "FENNEKIN",
  "DEWGONG": "SEEL",
  "DEWOTT": "OSHAWOTT",
  "DEWPIDER": "DEWPIDER",
  "DIANCIE": "DIANCIE",
  "DIGLETT": "DIGLETT",
  "DODRIO": "DODUO",
  "DODUO": "DODUO",
  "DOLLIV": "SMOLIV",
  "DONPHAN": "PHANPY",
  "DOTTLER": "BLIPBUG",
  "DOUBLADE": "HONEDGE",
  "DRAGALGE": "SKRELP",
  "DRAGONAIR": "DRATINI",
  "DRAGONITE": "DRATINI",
  "DRAPION": "SKORUPI",
  "DRATINI": "DRATINI",
  "DREDNAW": "CHEWTLE",
  "DRIFBLIM": "DRIFLOON",
  "DRIFLOON": "DRIFLOON",
  "DRILBUR": "DRILBUR",
  "DRIZZILE": "SOBBLE",
  "DROWZEE": "DROWZEE",
  "DUGTRIO": "DIGLETT",
  "DUOSION": "SOLOSIS",
  "DUSTOX": "WURMPLE",
  "EELEKTRIK": "TYNAMO",
  "EELEKTROSS": "TYNAMO",
  "EKANS": "EKANS",
  "ELDEGOSS": "GOSSIFLEUR",
  "ELECTABUZZ": "ELEKID",
  "ELECTIVIRE": "ELEKID",
  "ELECTRIKE": "ELECTRIKE",
  "ELECTRODE": "VOLTORB",
  "ELEKID": "ELEKID",
  "ELGYEM": "ELGYEM",
  "EMPOLEON": "PIPLUP",
  "ESPURR": "ESPURR",
  "EXCADRILL": "DRILBUR",
  "EXEGGCUTE": "EXEGGCUTE",
  "EXEGGUTOR": "EXEGGCUTE",
  "EXPLOUD": "WHISMUR",
  "FARIGIRAF": "GIRAFARIG",
  "FEAROW": "SPEAROW",
  "FENNEKIN": "FENNEKIN",
  "FERALIGATR": "TOTODILE",
  "FERROSEED": "FERROSEED",
  "FERROTHORN": "FERROSEED",
  "FIDOUGH": "FIDOUGH",
  "FINNEON": "FINNEON",
  "FLABEBE": "FLABEBE",
  "FLAFFY": "MAREEP",
  "FLETCHINDER": "FLETCHLING",
  "FLETCHLING": "FLETCHLING",
  "FLOATZEL": "BUIZEL",
  "FLOETTE": "FLABEBE",
  "FLORAGATO": "SPRIGATITO",
  "FLORGES": "FLABEBE",
  "FLYGON": "TRAPINCH",
  "FOMANTIS": "FOMANTIS",
  "FORRETRESS": "PINECO",
  "FRIGIBAX": "FRIGIBAX",
  "FROSLASS": "SNORUNT",
  "FROSMOTH": "SNOM",
  "FUECOCO": "FUECOCO",
  "FURRET": "SENTRET",
  "GABITE": "GIBLE",
  "GALARCORSOLA": "GALARCORSOLA",
  "GALLADE": "RALTS",
  "GALVANTULA": "JOLTIK",
  "GARBODOR": "TRUBBISH",
  "GARCHOMP": "GIBLE",
  "GARDEVOIR": "RALTS",
  "GARGANACL": "NACLI",
  "GASTLY": "GASTLY",
  "GENGAR": "GASTLY",
  "GEODUDE": "GEODUDE",
  "GIBLE": "GIBLE",
  "GIGALITH": "ROGGENROLA",
  "GIRAFARIG": "GIRAFARIG",
  "GLALIE": "SNORUNT",
  "GLAMEOW": "GLAMEOW",
  "GLIGAR": "GLIGAR",
  "GLIMMET": "GLIMMET",
  "GLIMMORA": "GLIMMET",
  "GLISCOR": "GLIGAR",
  "GOLBAT": "ZUBAT",
  "GOLDEEN": "GOLDEEN",
  "GOLDUCK": "PSYDUCK",
  "GOLEM": "GEODUDE",
  "GOLETT": "GOLETT",
  "GOLISOPOD": "WIMPOD",
  "GOLURK": "GOLETT",
  "GOODRA": "GOOMY",
  "GOOMY": "GOOMY",
  "GOREBYSS": "CLAMPERL",
  "GOSSIFLEUR": "GOSSIFLEUR",
  "GOURGEIST": "PUMPKABOO",
  "GRANBULL": "SNUBULL",
  "GRAPPLOCT": "CLOBBOPUS",
  "GRAVELER": "GEODUDE",
  "GREAVARD": "GREAVARD",
  "GRIMER": "GRIMER",
  "GRIMMSNARL": "IMPIDIMP",
  "GROOKEY": "GROOKEY",
  "GROTLE": "TURTWIG",
  "GROVYLE": "TREECKO",
  "GROWLITHE": "GROWLITHE",
  "GRUMPIG": "SPOINK",
  "GULPIN": "GULPIN",
  "GURDURR": "TIMBURR",
  "HAKAMOO": "JANGMOO",
  "HAPPINY": "HAPPINY",
  "HARIYAMA": "MAKUHITA",
  "HATENNA": "HATENNA",
  "HATTERENE": "HATENNA",
  "HATTREM": "HATENNA",
  "HAUNTER": "GASTLY",
  "HELIOLISK": "HELIOPTILE",
  "HELIOPTILE": "HELIOPTILE",
  "HERDIER": "LILLIPUP",
  "HIPPODOWN": "HIPPOPOTAS",
  "HIPPOPOTAS": "HIPPOPOTAS",
  "HONCHKROW": "MURKROW",
  "HONEDGE": "HONEDGE",
  "HOOTHOOT": "HOOTHOOT",
  "HORSEA": "HORSEA",
  "HOUNDOOM": "HOUNDOUR",
  "HOUNDOUR": "HOUNDOUR",
  "HOUNDSTONE": "GREAVARD",
  "HUNTAIL": "CLAMPERL",
  "HYDREIGON": "DEINO",
  "HYPNO": "DROWZEE",
  "IGGLYBUFF": "IGGLYBUFF",
  "IMPIDIMP": "IMPIDIMP",
  "INCINEROAR": "LITTEN",
  "INFERNAPE": "CHIMCHAR",
  "INKAY": "INKAY",
  "INTELEON": "SOBBLE",
  "IVYSAUR": "BULBASAUR",
  "JANGMOO": "JANGMOO",
  "JIGGLYPUFF": "IGGLYBUFF",
  "JOLTIK": "JOLTIK",
  "JYNX": "SMOOCHUM",
  "KABUTO": "KABUTO",
  "KABUTOPS": "KABUTO",
  "KADABRA": "ABRA",
  "KAKUNA": "WEEDLE",
  "KILOWATTREL": "WATTREL",
  "KINGAMBIT": "PAWNIARD",
  "KINGDRA": "HORSEA",
  "KINGLER": "KRABBY",
  "KIRLIA": "RALTS",
  "KLANG": "KLINK",
  "KLINK": "KLINK",
  "KLINKLANG": "KLINK",
  "KOFFING": "WEEZING",
  "KOMMOO": "JANGMOO",
  "KRABBY": "KRABBY",
  "KRICKETOT": "KRICKETOT",
  "KRICKETUNE": "KRICKETOT",
  "LAIRON": "ARON",
  "LAMPENT": "LITWICK",
  "LANTURN": "CHINCHOU",
  "LARVESTA": "LARVESTA",
  "LARVITAR": "LARVITAR",
  "LEAVANNY": "SEWADDLE",
  "LEDIAN": "LEDYBA",
  "LEDYBA": "LEDYBA",
  "LICKILICKY": "LICKITUNG",
  "LICKITUNG": "LICKITUNG",
  "LIEPARD": "PURRLOIN",
  "LILEEP": "LILEEP",
  "LILLIGANT": "PETILIL",
  "LILLIPUP": "LILLIPUP",
  "LINOONE": "ZIGZAGOON",
  "LITTEN": "LITTEN",
  "LITWICK": "LITWICK",
  "LOKIX": "NYMBLE",
  "LOMBRE": "LOTAD",
  "LOPUNNY": "BUNEARY",
  "LOTAD": "LOTAD",
  "LOUDRED": "WHISMUR",
  "LUCARIO": "RIOLU",
  "LUDICOLO": "LOTAD",
  "LUMINEON": "FINNEON",
  "LURANTIS": "FOMANTIS",
  "LUXIO": "SHINX",
  "LUXRAY": "SHINX",
  "LYCANROCDAY": "ROCKRUFF",
  "MACHAMP": "MACHOP",
  "MACHOKE": "MACHOP",
  "MACHOP": "MACHOP",
  "MAGBY": "MAGBY",
  "MAGCARGO": "SLUGMA",
  "MAGMAR": "MAGBY",
  "MAGMORTAR": "MAGBY",
  "MAGNEMITE": "MAGNEMITE",
  "MAGNETON": "MAGNEMITE",
  "MAGNEZONE": "MAGNEMITE",
  "MAKUHITA": "MAKUHITA",
  "MALAMAR": "INKAY",
  "MAMOSWINE": "SWINUB",
  "MANDIBUZZ": "VULLABY",
  "MANECTRIC": "ELECTRIKE",
  "MANKEY": "MANKEY",
  "MAREEP": "MAREEP",
  "MARILL": "AZURILL",
  "MAROWAK": "CUBONE",
  "MARSHTOMP": "MUDKIP",
  "MASQUERAIN": "SURSKIT",
  "MEDICHAM": "MEDITITE",
  "MEDITITE": "MEDITITE",
  "MEOWSCARADA": "SPRIGATITO",
  "MEOWSTICMALE": "ESPURR",
  "MEOWTH": "MEOWTH",
  "METAGROSS": "BELDUM",
  "METANG": "BELDUM",
  "METAPOD": "CATERPIE",
  "MIENFOO": "MIENFOO",
  "MIENSHAO": "MIENFOO",
  "MIGHTYENA": "POOCHYENA",
  "MIMEJR": "MIMEJR",
  "MINCCINO": "MINCCINO",
  "MISDREAVUS": "MISDREAVUS",
  "MISMAGIUS": "MISDREAVUS",
  "MONFERNO": "CHIMCHAR",
  "MORGREM": "IMPIDIMP",
  "MRMIME": "MIMEJR",
  "MUDKIP": "MUDKIP",
  "MUK": "GRIMER",
  "MUNCHLAX": "MUNCHLAX",
  "MUNNA": "MUNNA",
  "MURKROW": "MURKROW",
  "MUSHARNA": "MUNNA",
  "NACLI": "NACLI",
  "NACLSTACK": "NACLI",
  "NATU": "NATU",
  "NICKIT": "NICKIT",
  "NIDOKING": "NIDORANM",
  "NIDOQUEEN": "NIDORANF",
  "NIDORANF": "NIDORANF",
  "NIDORANM": "NIDORANM",
  "NIDORINA": "NIDORANF",
  "NIDORINO": "NIDORANM",
  "NINCADA": "NINCADA",
  "NINETALES": "VULPIX",
  "NINJASK": "NINCADA",
  "NOCTOWL": "HOOTHOOT",
  "NOIBAT": "NOIBAT",
  "NOIVERN": "NOIBAT",
  "NOSEPASS": "NOSEPASS",
  "NUMEL": "NUMEL",
  "NUZLEAF": "SEEDOT",
  "NYMBLE": "NYMBLE",
  "OBSTAGOON": "ZIGZAGOON",
  "OMANYTE": "OMANYTE",
  "OMASTAR": "OMANYTE",
  "ONIX": "ONIX",
  "ORBEETLE": "BLIPBUG",
  "OSHAWOTT": "OSHAWOTT",
  "PALDEAWOOPER": "PALDEAWOOPER",
  "PANCHAM": "PANCHAM",
  "PANGORO": "PANCHAM",
  "PARAS": "PARAS",
  "PARASECT": "PARAS",
  "PATRAT": "PATRAT",
  "PAWMI": "PAWMI",
  "PAWMO": "PAWMI",
  "PAWMOT": "PAWMI",
  "PAWNIARD": "PAWNIARD",
  "PELIPPER": "WINGULL",
  "PERSIAN": "MEOWTH",
  "PETILIL": "PETILIL",
  "PHANPY": "PHANPY",
  "PHANTUMP": "PHANTUMP",
  "PICHU": "PICHU",
  "PIDGEOT": "PIDGEY",
  "PIDGEOTTO": "PIDGEY",
  "PIDGEY": "PIDGEY",
  "PIDOVE": "PIDOVE",
  "PIKACHU": "PICHU",
  "PILOSWINE": "SWINUB",
  "PINECO": "PINECO",
  "PIPLUP": "PIPLUP",
  "POLITOED": "POLIWAG",
  "POLIWAG": "POLIWAG",
  "POLIWHIRL": "POLIWAG",
  "POLIWRATH": "POLIWAG",
  "POLTEAGEIST": "SINISTEA",
  "PONYTA": "PONYTA",
  "POOCHYENA": "POOCHYENA",
  "PORYGON": "PORYGON",
  "PORYGON2": "PORYGON",
  "PORYGONZ": "PORYGON",
  "PRIMEAPE": "MANKEY",
  "PRINPLUP": "PIPLUP",
  "PROBOPASS": "NOSEPASS",
  "PSYDUCK": "PSYDUCK",
  "PUMPKABOO": "PUMPKABOO",
  "PUPITAR": "LARVITAR",
  "PURRLOIN": "PURRLOIN",
  "PURUGLY": "GLAMEOW",
  "QUAGSIRE": "WOOPER",
  "QUILAVA": "CYNDAQUIL",
  "QUILLADIN": "CHESPIN",
  "RAICHU": "PICHU",
  "RALTS": "RALTS",
  "RAMPARDOS": "CRANIDOS",
  "RAPIDASH": "PONYTA",
  "RATICATE": "RATTATA",
  "RATTATA": "RATTATA",
  "REUNICLUS": "SOLOSIS",
  "REVAVROOM": "VAROOM",
  "RHYDON": "RHYHORN",
  "RHYHORN": "RHYHORN",
  "RHYPERIOR": "RHYHORN",
  "RIBOMBEE": "CUTIEFLY",
  "RILLABOOM": "GROOKEY",
  "RIOLU": "RIOLU",
  "ROCKRUFF": "ROCKRUFF",
  "ROGGENROLA": "ROGGENROLA",
  "ROOKIDEE": "ROOKIDEE",
  "ROSELIA": "BUDEW",
  "ROSERADE": "BUDEW",
  "RUFFLET": "RUFFLET",
  "SALAMENCE": "BAGON",
  "SALANDIT": "SALANDIT",
  "SALAZZLE": "SALANDIT",
  "SAMUROTT": "OSHAWOTT",
  "SANDACONDA": "SILICOBRA",
  "SANDSHREW": "SANDSHREW",
  "SANDSLASH": "SANDSLASH",
  "SCEPTILE": "TREECKO",
  "SCOLIPEDE": "VENIPEDE",
  "SCOVILLAIN": "CAPSAKID",
  "SCRAFTY": "SCRAGGY",
  "SCRAGGY": "SCRAGGY",
  "SEADRA": "HORSEA",
  "SEAKING": "GOLDEEN",
  "SEALEO": "SPHEAL",
  "SEEDOT": "SEEDOT",
  "SEEL": "SEEL",
  "SENTRET": "SENTRET",
  "SEWADDLE": "SEWADDLE",
  "SHARPEDO": "CARVANHA",
  "SHEDINJA": "NINCADA",
  "SHELGON": "BAGON",
  "SHELLDER": "SHELLDER",
  "SHIELDON": "SHIELDON",
  "SHIFTRY": "SEEDOT",
  "SHINX": "SHINX",
  "SHROOMISH": "SHROOMISH",
  "SHUPPET": "SHUPPET",
  "SILCOON": "WURMPLE",
  "SILICOBRA": "SILICOBRA",
  "SINISTEA": "SINISTEA",
  "SIZZLIPEDE": "SIZZLIPEDE",
  "SKELEDIRGE": "FUECOCO",
  "SKITTY": "SKITTY",
  "SKORUPI": "SKORUPI",
  "SKRELP": "SKRELP",
  "SKUNTANK": "STUNKY",
  "SLAKING": "SLAKOTH",
  "SLAKOTH": "SLAKOTH",
  "SLIGOO": "GOOMY",
  "SLOWBRO": "SLOWPOKE",
  "SLOWKING": "SLOWPOKE",
  "SLOWPOKE": "SLOWPOKE",
  "SLUGMA": "SLUGMA",
  "SMOLIV": "SMOLIV",
  "SMOOCHUM": "SMOOCHUM",
  "SNEASEL": "SNEASEL",
  "SNOM": "SNOM",
  "SNORLAX": "MUNCHLAX",
  "SNORUNT": "SNORUNT",
  "SNOVER": "SNOVER",
  "SNUBULL": "SNUBULL",
  "SOBBLE": "SOBBLE",
  "SOLOSIS": "SOLOSIS",
  "SPEAROW": "SPEAROW",
  "SPHEAL": "SPHEAL",
  "SPINARAK": "SPINARAK",
  "SPOINK": "SPOINK",
  "SPRIGATITO": "SPRIGATITO",
  "SQUIRTLE": "SQUIRTLE",
  "STARAPTOR": "STARLY",
  "STARAVIA": "STARLY",
  "STARLY": "STARLY",
  "STARMIE": "STARYU",
  "STARYU": "STARYU",
  "STEELIX": "ONIX",
  "STEENEE": "BOUNSWEET",
  "STOUTLAND": "LILLIPUP",
  "STUFFUL": "STUFFUL",
  "STUNKY": "STUNKY",
  "SUDOWOODO": "BONSLEY",
  "SURSKIT": "SURSKIT",
  "SWABLU": "SWABLU",
  "SWADLOON": "SEWADDLE",
  "SWALOT": "GULPIN",
  "SWAMPERT": "MUDKIP",
  "SWELLOW": "TAILLOW",
  "SWINUB": "SWINUB",
  "SWOOBAT": "WOOBAT",
  "TADBULB": "TADBULB",
  "TAILLOW": "TAILLOW",
  "TALONFLAME": "FLETCHLING",
  "TANGELA": "TANGELA",
  "TANGROWTH": "TANGELA",
  "TEDDIURSA": "TEDDIURSA",
  "TENTACOOL": "TENTACOOL",
  "TENTACRUEL": "TENTACOOL",
  "THIEVUL": "NICKIT",
  "THWACKEY": "GROOKEY",
  "TIMBURR": "TIMBURR",
  "TINKATINK": "TINKATINK",
  "TINKATON": "TINKATINK",
  "TINKATUFF": "TINKATINK",
  "TOGEKISS": "TOGEPI",
  "TOGEPI": "TOGEPI",
  "TOGETIC": "TOGEPI",
  "TORCHIC": "TORCHIC",
  "TORRACAT": "LITTEN",
  "TORTERRA": "TURTWIG",
  "TOTODILE": "TOTODILE",
  "TOXEL": "TOXEL",
  "TOXICROAK": "CROAGUNK",
  "TOXTRICITY": "TOXEL",
  "TRANQUILL": "PIDOVE",
  "TRAPINCH": "TRAPINCH",
  "TREECKO": "TREECKO",
  "TREVENANT": "PHANTUMP",
  "TRUBBISH": "TRUBBISH",
  "TSAREENA": "BOUNSWEET",
  "TURTWIG": "TURTWIG",
  "TYNAMO": "TYNAMO",
  "TYPHLOSION": "CYNDAQUIL",
  "TYRANITAR": "LARVITAR",
  "TYRANTRUM": "TYRUNT",
  "TYRUNT": "TYRUNT",
  "UNFEZANT": "PIDOVE",
  "URSALUNA": "TEDDIURSA",
  "URSARING": "TEDDIURSA",
  "VANILLISH": "VANILLITE",
  "VANILLITE": "VANILLITE",
  "VANILLUXE": "VANILLITE",
  "VAROOM": "VAROOM",
  "VENIPEDE": "VENIPEDE",
  "VENOMOTH": "VENONAT",
  "VENONAT": "VENONAT",
  "VENUSAUR": "BULBASAUR",
  "VESPIQUEEN": "COMBEE",
  "VIBRAVA": "TRAPINCH",
  "VIGOROTH": "SLAKOTH",
  "VOLCARONA": "LARVESTA",
  "VOLTORB": "VOLTORB",
  "VULLABY": "VULLABY",
  "VULPIX": "VULPIX",
  "WAILMER": "WAILMER",
  "WAILORD": "WAILMER",
  "WALREIN": "SPHEAL",
  "WARTORTLE": "SQUIRTLE",
  "WATCHOG": "PATRAT",
  "WATTREL": "WATTREL",
  "WEAVILE": "SNEASEL",
  "WEEDLE": "WEEDLE",
  "WEEZING": "WEEZING",
  "WHIMSICOTT": "COTTONEE",
  "WHIRLIPEDE": "VENIPEDE",
  "WHISCASH": "BARBOACH",
  "WHISMUR": "WHISMUR",
  "WIGGLYTUFF": "IGGLYBUFF",
  "WIGLETT": "WIGLETT",
  "WIMPOD": "WIMPOD",
  "WINGULL": "WINGULL",
  "WOBBUFFET": "WYNAUT",
  "WOOBAT": "WOOBAT",
  "WOOPER": "WOOPER",
  "WUGTRIO": "WIGLETT",
  "WURMPLE": "WURMPLE",
  "WYNAUT": "WYNAUT",
  "XATU": "NATU",
  "YANMA": "YANMA",
  "YANMEGA": "YANMA",
  "ZIGZAGOON": "ZIGZAGOON",
  "ZOROARK": "ZORUA",
  "ZORUA": "ZORUA",
  "ZUBAT": "ZUBAT",
  "ZWEILOUS": "DEINO",
};

/**
 * Get the base form for any pokemon in an evolution family
 * @param {string} pokemonName - Any pokemon name (base or evolved)
 * @returns {string} - The base form name
 */
function getBaseForm(pokemonName) {
  const name = pokemonName.toUpperCase();
  return POKEMON_TO_BASE[name] || name;
}

/**
 * Get all forms in an evolution family
 * @param {string} pokemonName - Any pokemon name (base or evolved)
 * @returns {Array<string>} - Array of all pokemon names in family
 */
function getEvolutionFamily(pokemonName) {
  const base = getBaseForm(pokemonName);
  const chain = EVOLUTION_CHAINS[base];
  if (!chain) return [pokemonName];
  return chain.filter(entry => entry.name).map(entry => entry.name);
}

/**
 * Get the evolution cost multiplier for a specific pokemon
 * @param {string} pokemonName - Pokemon name
 * @returns {number} - Cost multiplier (1, 3, 9, or 27)
 */
function getEvolutionCost(pokemonName) {
  const base = getBaseForm(pokemonName);
  const chain = EVOLUTION_CHAINS[base];
  if (!chain) return 1;
  
  const name = pokemonName.toUpperCase();
  const entry = chain.find(e => e.name === name);
  return entry ? entry.cost : 1;
}

/**
 * Get full evolution data for a specific pokemon
 * @param {string} pokemonName - Pokemon name
 * @returns {Object|null} - Evolution data object or null
 */
function getEvolutionData(pokemonName) {
  const base = getBaseForm(pokemonName);
  const chain = EVOLUTION_CHAINS[base];
  if (!chain) return null;
  
  const name = pokemonName.toUpperCase();
  return chain.find(e => e.name === name) || null;
}

/**
 * Get the complete evolution chain for a pokemon
 * @param {string} pokemonName - Pokemon name
 * @returns {Array<Object>} - Array of evolution data objects
 */
function getEvolutionChain(pokemonName) {
  const base = getBaseForm(pokemonName);
  return EVOLUTION_CHAINS[base] || [];
}

/**
 * Check if a pokemon is a base form
 * @param {string} pokemonName - Pokemon name
 * @returns {boolean} - True if base form
 */
function isBaseForm(pokemonName) {
  const name = pokemonName.toUpperCase();
  return POKEMON_TO_BASE[name] === name;
}

// Export functions for use in extension
if (typeof module !== "undefined" && module.exports) {
  // Node.js export
  module.exports = {
    EVOLUTION_CHAINS,
    POKEMON_TO_BASE,
    getBaseForm,
    getEvolutionFamily,
    getEvolutionCost,
    getEvolutionData,
    getEvolutionChain,
    isBaseForm
  };
}


  // ═══════════════════════════════════════════════════════════════════════════
  // GAME DATA CONSTANTS
  // ═══════════════════════════════════════════════════════════════════════════

  const POOL_COPIES = {
    common:   { twoStar: 18, threeStar: 27 },
    uncommon: { twoStar: 13, threeStar: 22 },
    rare:     { twoStar: 9, threeStar: 18 },
    epic:     { twoStar: 7, threeStar: 14 },
    ultra:    { twoStar: 5, threeStar: 10 }
  };

  const BASE_GAME_POOLS = {
    common:   { twoStar: 0, threeStar: 17 },
    uncommon: { twoStar: 1, threeStar: 15 },
    rare:     { twoStar: 0, threeStar: 14 },
    epic:     { twoStar: 0, threeStar: 14 },
    ultra:    { twoStar: 0, threeStar: 12 }
  };

  const SHOP_ODDS = {
    1: { common: 100, uncommon: 0,  rare: 0,  epic: 0,  ultra: 0 },
    2: { common: 100, uncommon: 0,  rare: 0,  epic: 0,  ultra: 0 },
    3: { common: 70,  uncommon: 30, rare: 0,  epic: 0,  ultra: 0 },
    4: { common: 50,  uncommon: 40, rare: 10, epic: 0,  ultra: 0 },
    5: { common: 36,  uncommon: 42, rare: 20, epic: 2,  ultra: 0 },
    6: { common: 25,  uncommon: 40, rare: 30, epic: 5,  ultra: 0 },
    7: { common: 16,  uncommon: 33, rare: 35, epic: 15, ultra: 1 },
    8: { common: 11,  uncommon: 27, rare: 35, epic: 22, ultra: 5 },
    9: { common: 5,   uncommon: 20, rare: 35, epic: 30, ultra: 10 }
  };

  const BASE_WILD_COUNTS = {
    common:   { twoStar: 2, threeStar: 0 },
    uncommon: { twoStar: 4, threeStar: 0 },
    rare:     { twoStar: 4, threeStar: 0 },
    epic:     { twoStar: 2, threeStar: 1 },
    ultra:    { twoStar: 0, threeStar: 1 }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // STATE
  // ═══════════════════════════════════════════════════════════════════════════

  let extractionInterval = null;
  let isMinimized = false;
  let lastPoolData = null;
  let currentPollSpeed = 500;
  let liveTrackingActive = false;

  // OPTIMIZATION: Dirty check variables for DOM rendering
  let lastCurrentHash = '';
  let lastTeamFingerprint = '';

  const state = {
    level: 7,
    targetRarity: 'rare',
    targetEvo: 'threeStar',
    refreshes: 10,
    copiesTaken: 0,
    evolutionGoal: 'firstEvo',
    copiesOwned: 0,
    dittoEnabled: true,  // Always enabled in PAC
    targetIsWild: false,
    pveRoundEnabled: false,
    wildUnitsOwned: 0,
    wildUnitsTaken: 0,
    // Evolution family tracking (v2.5.0)
    targetPokemon: '',           // Base form being tracked
    targetPokemonDisplayName: '', // What user searched (may be evolved form)
    evolutionFamily: [],          // Cached family array
    round5Enabled: false,
    round5AddPicks: 8,
    round8Enabled: false,
    round8AddPicks: 8,
    round11Enabled: false,
    round11AddPicks: 8,
    portalRegionals: {
      common: { twoStar: 0, threeStar: 0 },
      uncommon: { twoStar: 0, threeStar: 0 },
      rare: { twoStar: 0, threeStar: 0 },
      epic: { twoStar: 0, threeStar: 0 },
      ultra: { twoStar: 0, threeStar: 0 }
    },
    wildAddPicks: { uncommon: 0, rare: 0, epic: 0 },
    wildRegionals: {
      common: { twoStar: 0, threeStar: 0 },
      uncommon: { twoStar: 0, threeStar: 0 },
      rare: { twoStar: 0, threeStar: 0 },
      epic: { twoStar: 0, threeStar: 0 },
      ultra: { twoStar: 0, threeStar: 0 }
    },
    // Live extraction
    autoScout: true,
    targetPokemon: '', // Name to track
    targetPokemonRarity: null, // Store the rarity for validation
    confidencePercent: 75, // Adjustable confidence threshold
    playerName: '', // Player's in-game name for flash alerts
    // Team tracking (v2.8.0)
    teamTargets: [], // Array of {id, pokemon, rarity, evo, isWild, enabled, copiesTaken}
    teamPanelExpanded: false,
    currentPanelExpanded: false
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // ROOM EXTRACTION (via page context injection)
  // ═══════════════════════════════════════════════════════════════════════════

  function injectExtractor() {
    // Inject as external file to bypass CSP
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('content/extractor.js');
    script.onload = function() {
      if (DEBUG_MODE) console.log('🎮 PAC Calculator: Extractor loaded');
      this.remove();
    };
    script.onerror = function() {
      console.error('🎮 PAC Calculator: Failed to load extractor');
    };
    (document.head || document.documentElement).appendChild(script);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PROBABILITY CALCULATIONS
  // ═══════════════════════════════════════════════════════════════════════════

  function calculateWildCounts() {
    const counts = {};
    Object.keys(BASE_WILD_COUNTS).forEach(rarity => {
      let twoStarCount = BASE_WILD_COUNTS[rarity].twoStar;
      let threeStarCount = BASE_WILD_COUNTS[rarity].threeStar;
      if (rarity === 'uncommon' && state.round5Enabled) twoStarCount += state.wildAddPicks.uncommon;
      if (rarity === 'rare' && state.round8Enabled) twoStarCount += state.wildAddPicks.rare;
      if (rarity === 'epic' && state.round11Enabled) twoStarCount += state.wildAddPicks.epic;
      twoStarCount += state.wildRegionals[rarity].twoStar;
      threeStarCount += state.wildRegionals[rarity].threeStar;
      counts[rarity] = { twoStar: twoStarCount, threeStar: threeStarCount, total: twoStarCount + threeStarCount };
    });
    return counts;
  }

  function calculateTotalPool() {
    const pools = {};
    Object.keys(BASE_GAME_POOLS).forEach(rarity => {
      let twoStarSpecies = BASE_GAME_POOLS[rarity].twoStar;
      let threeStarSpecies = BASE_GAME_POOLS[rarity].threeStar;
      if (rarity === 'uncommon' && state.round5Enabled) twoStarSpecies += state.round5AddPicks;
      if (rarity === 'rare' && state.round8Enabled) twoStarSpecies += state.round8AddPicks;
      if (rarity === 'epic' && state.round11Enabled) twoStarSpecies += state.round11AddPicks;
      twoStarSpecies += state.portalRegionals[rarity].twoStar;
      threeStarSpecies += state.portalRegionals[rarity].threeStar;
      const twoStarCopies = twoStarSpecies * POOL_COPIES[rarity].twoStar;
      const threeStarCopies = threeStarSpecies * POOL_COPIES[rarity].threeStar;
      pools[rarity] = {
        twoStarTotal: twoStarCopies,
        threeStarTotal: threeStarCopies,
        total: twoStarCopies + threeStarCopies,
        twoStarSpecies,
        threeStarSpecies
      };
    });
    return pools;
  }

  function calculate() {
    const totalPool = calculateTotalPool();
    const totalWildCounts = calculateWildCounts();
    const pool = totalPool[state.targetRarity];
    const rarityOdds = SHOP_ODDS[state.level];
    const rarityChance = rarityOdds[state.targetRarity] / 100;
    
    const wildCountsForRarity = totalWildCounts[state.targetRarity];
    const wildUnitsExist = state.targetEvo === 'twoStar' ? wildCountsForRarity.twoStar > 0 : wildCountsForRarity.threeStar > 0;
    
    let maxTargetCopies, targetCopies;
    if (state.targetIsWild) {
      const wildSpeciesCount = state.targetEvo === 'twoStar' ? wildCountsForRarity.twoStar : wildCountsForRarity.threeStar;
      if (wildSpeciesCount > 0) {
        maxTargetCopies = state.targetEvo === 'twoStar' ? POOL_COPIES[state.targetRarity].twoStar : POOL_COPIES[state.targetRarity].threeStar;
        targetCopies = Math.max(0, maxTargetCopies - state.copiesTaken);
      } else {
        maxTargetCopies = 0;
        targetCopies = 0;
      }
    } else {
      maxTargetCopies = state.targetEvo === 'twoStar' ? POOL_COPIES[state.targetRarity].twoStar : POOL_COPIES[state.targetRarity].threeStar;
      targetCopies = Math.max(0, maxTargetCopies - state.copiesTaken);
    }
    
    // Get pool reductions from extraction data
    let visibleTwoStar = 0;
    let visibleThreeStar = 0;
    
    if (lastPoolData && lastPoolData.poolReductions && lastPoolData.poolReductions[state.targetRarity]) {
      visibleTwoStar = lastPoolData.poolReductions[state.targetRarity].twoStar || 0;
      visibleThreeStar = lastPoolData.poolReductions[state.targetRarity].threeStar || 0;
    }
    
    const relevantPoolBeforeVisible = state.targetEvo === 'twoStar' ? pool.twoStarTotal : pool.threeStarTotal;
    const otherPoolPortion = state.targetEvo === 'twoStar' ? pool.threeStarTotal : pool.twoStarTotal;
    
    // Reduce pools by visible units
    const relevantPoolAfterVisible = Math.max(0, relevantPoolBeforeVisible - (state.targetEvo === 'twoStar' ? visibleTwoStar : visibleThreeStar));
    const otherPoolAfterVisible = Math.max(0, otherPoolPortion - (state.targetEvo === 'twoStar' ? visibleThreeStar : visibleTwoStar));
    
    const totalPoolSize = relevantPoolAfterVisible + otherPoolAfterVisible;
    
    const totalWildCopiesBeforeReduction = state.targetEvo === 'twoStar' ?
      wildCountsForRarity.twoStar * POOL_COPIES[state.targetRarity].twoStar :
      wildCountsForRarity.threeStar * POOL_COPIES[state.targetRarity].threeStar;
    const totalWildCopies = Math.max(0, totalWildCopiesBeforeReduction - state.wildUnitsTaken);
    
    const wildBoost = state.pveRoundEnabled ? (0.05 + (state.wildUnitsOwned * 0.01)) : (state.wildUnitsOwned * 0.01);
    const safeWildBoost = isNaN(wildBoost) ? 0 : wildBoost;
    
    let perSlotProbTarget = 0;
    let wildTargetImpossible = false;
    
    if (state.targetIsWild) {
      // WILD TARGET: Only accessible through Wild boost
      if (!wildUnitsExist) {
        perSlotProbTarget = 0;
        wildTargetImpossible = true;
      } else if (totalWildCopies === 0) {
        perSlotProbTarget = 0;
      } else if (safeWildBoost === 0) {
        perSlotProbTarget = 0;
      } else {
        // Wild boost → Wild pool → specific Wild
        perSlotProbTarget = safeWildBoost * rarityChance * (targetCopies / totalWildCopies);
      }
    } else {
      // NON-WILD TARGET: Normal pool with Wild boost penalty
      if (targetCopies > 0 && totalPoolSize > 0) {
        const baseProb = rarityChance * (targetCopies / totalPoolSize);
        
        // Wild boost steals slots from normal pool
        perSlotProbTarget = (1 - safeWildBoost) * baseProb;
      }
    }
    
    const perRefresh = 1 - Math.pow(1 - perSlotProbTarget, 6);  // 6 shop slots
    const perRefreshWithDitto = 1 - Math.pow(1 - perSlotProbTarget, 6);  // Ditto replaces a slot, still 6
    const overNRefreshes = 1 - Math.pow(1 - perRefresh, state.refreshes);
    
    // Dynamic confidence calculation
    const confidenceDecimal = (100 - state.confidencePercent) / 100; // 75% -> 0.25
    const expectedForConfidence = perRefresh > 0 ? Math.log(confidenceDecimal) / Math.log(1 - perRefresh) : Infinity;
    const goldForConfidence = isFinite(expectedForConfidence) ? expectedForConfidence * 2 : Infinity;
    
    return {
      perSlot: perSlotProbTarget * 100,
      perRefresh: perRefresh * 100,
      perRefreshWithDitto: perRefreshWithDitto * 100,
      overNRefreshes: overNRefreshes * 100,
      expectedForConfidence,
      goldForConfidence,
      rarityChance: rarityChance * 100,
      targetCopies,
      maxTargetCopies,
      wildTargetImpossible,
      wildBoost: safeWildBoost
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // POKEMON AUTOCOMPLETE COMPONENT
  // ═══════════════════════════════════════════════════════════════════════════

  function setupAutocomplete() {
    const input = document.getElementById('pacTargetPokemon');
    const dropdown = document.getElementById('pacAutocompleteDropdown');
    const errorMsg = document.getElementById('pacRarityError');
    
    let selectedPokemon = null;
    let debounceTimer; // OPTIMIZATION: Debounce timer
    
    // Filter on input WITH DEBOUNCE
    input.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      
      debounceTimer = setTimeout(() => {
        const query = e.target.value.toUpperCase().trim();
        
        if (query.length < 2) {
          dropdown.classList.add('hidden');
          errorMsg.classList.add('hidden');
          return;
        }
        
        // Filter matches
        const matches = Object.entries(POKEMON_DATA)
          .filter(([name]) => name.includes(query))
          .slice(0, 15); // Limit to 15 results
        
        if (matches.length === 0) {
          dropdown.classList.add('hidden');
          errorMsg.textContent = `No pokemon found matching "${query}"`;
          errorMsg.classList.remove('hidden');
          return;
        }
        
        // Build dropdown
        dropdown.innerHTML = matches
          .map(([name, rarity]) => {
            const info = RARITY_INFO[rarity] || { label: rarity, color: '#666' };
            const baseForm = getBaseForm(name);
            const isEvolved = baseForm !== name;
            const evolutionText = isEvolved ? ` <span style="color: #64b5f6; font-size: 10px;">(← ${baseForm})</span>` : '';
            return `
              <div class="pac-dropdown-item" data-name="${name}" data-rarity="${rarity}" data-baseform="${baseForm}">
                <span class="pac-pokemon-name">${name}${evolutionText}</span>
              <span class="pac-pokemon-rarity" style="background: ${info.color}; color: ${rarity === 'legendary' || rarity === 'uncommon' ? '#000' : '#fff'}">${info.label}</span>
            </div>
          `;
        }).join('');
      
      dropdown.classList.remove('hidden');
      errorMsg.classList.add('hidden');
      
      // Position dropdown to the right of the selector container
      const selectorRect = input.closest('.pac-pokemon-selector').getBoundingClientRect();
      const panelRect = document.getElementById('pac-calc-overlay').getBoundingClientRect();
      dropdown.style.top = `${selectorRect.top}px`;
      dropdown.style.left = `${panelRect.right + 8}px`;
      dropdown.style.maxHeight = `${Math.min(400, window.innerHeight - selectorRect.top - 20)}px`;
      }, 100); // OPTIMIZATION: 100ms delay - imperceptible to user
    });
    
    // Use event delegation for dropdown clicks (outside input handler to avoid duplicates)
    dropdown.addEventListener('click', (e) => {
      const item = e.target.closest('.pac-dropdown-item');
      if (item) {
        selectPokemon(item);
      }
    });
    
    // Selection handler
    function selectPokemon(item) {
      const name = item.dataset.name;
      const rarity = item.dataset.rarity;
      const baseForm = item.dataset.baseform || name;
      
      // Check if rarity is in pool
      if (!POOL_RARITIES.includes(rarity)) {
        errorMsg.textContent = `${name} is ${RARITY_INFO[rarity].label} - not available in shop pools`;
        errorMsg.classList.remove('hidden');
        input.value = '';
        state.targetPokemon = '';
        state.targetPokemonDisplayName = '';
        state.evolutionFamily = [];
        selectedPokemon = null;
        dropdown.classList.add('hidden');
        return;
      }
      
      // Clear previous evolution family display
      const familySection = document.getElementById('pacEvolutionFamily');
      if (familySection) {
        familySection.classList.add('hidden');
      }
      
      // Auto-adjust rarity if different
      if (rarity !== state.targetRarity) {
        state.targetRarity = rarity;
        document.getElementById('pacRarity').value = rarity;
      }
      
      // Auto-adjust evolution stars based on maxStars from EVOLUTION_CHAINS
      const evolutionChain = EVOLUTION_CHAINS[baseForm];
      if (evolutionChain && evolutionChain[0] && evolutionChain[0].maxStars) {
        const targetEvoStars = evolutionChain[0].maxStars;
        // Set the dropdown value to "twoStar" or "threeStar"
        const evoValue = targetEvoStars === 3 ? 'threeStar' : 'twoStar';
        state.targetEvolution = evoValue;
        document.getElementById('pacEvo').value = evoValue;
        if (DEBUG_MODE) console.log(`🌟 Auto-set evolution to ${targetEvoStars}★ (max for ${baseForm})`);
      }
      
      // Valid selection - store base form and evolution family
      input.value = name;
      state.targetPokemon = baseForm;  // Store BASE FORM for tracking
      state.targetPokemonDisplayName = name;  // What user searched
      state.targetPokemonRarity = rarity;
      state.evolutionFamily = getEvolutionFamily(baseForm);  // Cache family
      selectedPokemon = { name, rarity, baseForm };
      
      if (DEBUG_MODE) console.log('🎯 Selected:', { name, baseForm, family: state.evolutionFamily });
      
      dropdown.classList.add('hidden');
      errorMsg.classList.add('hidden');
      updateDisplay();
    }
    
    // Clear selection if rarity changes
    document.getElementById('pacRarity').addEventListener('change', () => {
      if (selectedPokemon && selectedPokemon.rarity !== state.targetRarity) {
        input.value = '';
        state.targetPokemon = '';
        state.targetPokemonRarity = null;
        const rarityLabel = RARITY_INFO[state.targetRarity].label;
        errorMsg.textContent = selectedPokemon ? `${selectedPokemon.name} is not a ${rarityLabel} pokemon` : '';
        if (selectedPokemon) errorMsg.classList.remove('hidden');
        selectedPokemon = null;
      }
    });
    
    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.pac-pokemon-selector')) {
        dropdown.classList.add('hidden');
      }
    });
    
    // Allow clearing with backspace
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && input.value.length === 0) {
        state.targetPokemon = '';
        state.targetPokemonRarity = null;
        selectedPokemon = null;
        errorMsg.classList.add('hidden');
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // UI CREATION
  // ═══════════════════════════════════════════════════════════════════════════

  function createOverlay() {
    // Inject CSS
    const style = document.createElement('style');
    style.textContent = `
      #pac-calc-overlay {
        position: fixed;
        top: 20px;
        right: 20px;
        width: 380px;
        background: rgba(26, 26, 46, 0.96);
        border: 2px solid #0f3460;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #e9e9e9;
        z-index: 999999;
        user-select: none;
        overflow: visible;
      }
      
      #pac-calc-header {
        background: linear-gradient(90deg, #0f3460 0%, #533483 100%);
        padding: 12px 16px;
        border-radius: 10px 10px 0 0;
        cursor: move;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        position: relative;
        z-index: 1;  /* Above side panels */
      }
      
      #pac-calc-title {
        font-weight: 600;
        font-size: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      
      .pac-status-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #666;
        box-shadow: 0 0 8px rgba(255,255,255,0.3);
        transition: all 0.3s ease;
      }
      
      .pac-status-dot.connected {
        background: #4caf50;
        box-shadow: 0 0 12px rgba(76,175,80,0.6);
      }
      
      #pac-calc-controls {
        display: flex;
        gap: 8px;
      }
      
      .pac-ctrl-btn {
        background: rgba(255,255,255,0.1);
        border: none;
        color: #fff;
        width: 28px;
        height: 28px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 18px;
        line-height: 1;
        transition: all 0.2s;
      }
      
      .pac-ctrl-btn:hover {
        background: rgba(255,255,255,0.2);
        transform: scale(1.1);
      }
      
      #pac-calc-body {
        padding: 16px;
        max-height: 70vh;
        overflow-y: auto;
      }
      
      #pac-calc-body.minimized {
        display: none;
      }
      
      /* Hide side panel arrows when minimized */
      #pac-calc-overlay.minimized .pac-team-toggle,
      #pac-calc-overlay.minimized .pac-current-toggle {
        display: none !important;
      }
      
      #pac-calc-overlay.minimized .pac-team-arrow {
        display: none !important;
      }
      
      .pac-section {
        margin-bottom: 16px;
        background: rgba(255,255,255,0.03);
        border-radius: 8px;
        padding: 12px;
        border: 1px solid rgba(255,255,255,0.05);
        position: relative;
        z-index: 1;  /* Above side panels */
      }
      
      .pac-section-title {
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 10px;
        color: #64b5f6;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      
      .pac-row {
        display: flex;
        gap: 8px;
        margin-bottom: 8px;
      }
      
      .pac-row:last-child {
        margin-bottom: 0;
      }
      
      .pac-field {
        flex: 1;
      }
      
      .pac-field label {
        display: block;
        font-size: 11px;
        margin-bottom: 4px;
        color: #aaa;
        font-weight: 500;
      }
      
      .pac-field input,
      .pac-field select {
        width: 100%;
        padding: 8px;
        background: rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 6px;
        color: #fff;
        font-size: 13px;
        transition: all 0.2s;
      }
      
      .pac-field input:focus,
      .pac-field select:focus {
        outline: none;
        border-color: #64b5f6;
        box-shadow: 0 0 8px rgba(100,181,246,0.3);
      }
      
      .pac-toggle-row {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
      }
      
      .pac-toggle {
        display: flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        font-size: 12px;
        padding: 6px 10px;
        background: rgba(255,255,255,0.05);
        border-radius: 6px;
        transition: all 0.2s;
      }
      
      .pac-new-game-btn {
        width: 100%;
        background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
        border: 2px solid #2196f3;
        color: white;
        border-radius: 8px;
        padding: 12px 16px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin-top: 8px;
      }
      
      .pac-new-game-btn:hover {
        background: linear-gradient(135deg, #42a5f5 0%, #2196f3 100%);
        border-color: #42a5f5;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(33, 150, 243, 0.4);
      }
      
      .pac-new-game-btn:active {
        transform: translateY(0);
      }
      
      .pac-toggle:hover {
        background: rgba(255,255,255,0.08);
      }
      
      .pac-toggle input[type="checkbox"] {
        appearance: none !important;
        -webkit-appearance: none !important;
        -moz-appearance: none !important;
        width: 24px !important;
        height: 24px !important;
        min-width: 24px !important;
        min-height: 24px !important;
        background: #000 !important;
        border: 2px solid #4caf50 !important;
        border-radius: 4px !important;
        cursor: pointer !important;
        position: relative !important;
        margin: 0 !important;
        padding: 0 !important;
        transition: all 0.2s !important;
        flex-shrink: 0 !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      
      .pac-toggle input[type="checkbox"]:hover:not(:disabled) {
        border-color: #66bb6a !important;
        box-shadow: 0 0 8px rgba(76, 175, 80, 0.4) !important;
      }
      
      .pac-toggle input[type="checkbox"]:checked {
        background: #000 !important;
        border-color: #4caf50 !important;
      }
      
      .pac-toggle input[type="checkbox"]:checked::after {
        content: '✓' !important;
        color: #4caf50 !important;
        font-size: 18px !important;
        font-weight: bold !important;
        line-height: 1 !important;
      }
      
      .pac-toggle input[type="checkbox"]:disabled {
        opacity: 0.6 !important;
        cursor: not-allowed !important;
      }
      
      .pac-warning-banner {
        padding: 12px;
        background: rgba(251, 191, 36, 0.15);
        border: 1px solid rgba(251, 191, 36, 0.4);
        border-radius: 8px;
        color: #fbbf24;
        font-size: 13px;
        line-height: 1.4;
      }
      
      .pac-results {
        background: linear-gradient(135deg, rgba(100,181,246,0.1) 0%, rgba(156,39,176,0.1) 100%);
        padding: 16px;
        border-radius: 8px;
        margin-bottom: 16px;
        border: 1px solid rgba(100,181,246,0.2);
      }
      
      .pac-result-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        font-size: 13px;
      }
      
      .pac-result-row:last-child {
        margin-bottom: 0;
      }
      
      .pac-result-label {
        color: #bbb;
        font-weight: 500;
      }
      
      .pac-result-value {
        font-weight: 700;
        color: #fff;
        font-size: 14px;
      }
      
      .pac-confidence-control {
        margin: 12px 0;
        padding: 0;
      }
      
      .pac-confidence-control label {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        color: #64b5f6;
        margin-bottom: 8px;
        font-weight: 600;
      }
      
      .pac-confidence-control input[type="range"] {
        width: 100%;
        height: 8px;
        border-radius: 4px;
        background: linear-gradient(90deg, 
          rgba(100,181,246,0.3) 0%, 
          rgba(156,39,176,0.3) 50%, 
          rgba(244,67,54,0.3) 100%);
        outline: none;
        -webkit-appearance: none;
        cursor: pointer;
      }
      
      .pac-confidence-control input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: linear-gradient(135deg, #64b5f6 0%, #9c27b0 100%);
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(100,181,246,0.5);
        border: 2px solid #fff;
        transition: all 0.2s;
      }
      
      .pac-confidence-control input[type="range"]::-webkit-slider-thumb:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(100,181,246,0.7);
      }
      
      .pac-confidence-control input[type="range"]::-moz-range-thumb {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: linear-gradient(135deg, #64b5f6 0%, #9c27b0 100%);
        cursor: pointer;
        border: 2px solid #fff;
        box-shadow: 0 2px 8px rgba(100,181,246,0.5);
        transition: all 0.2s;
      }
      
      .pac-confidence-control input[type="range"]::-moz-range-thumb:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(100,181,246,0.7);
      }
      
      /* Flash animation when target in shop */
      @keyframes targetInShopFlash {
        0%, 100% { 
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
          border-color: #0f3460;
        }
        50% { 
          background: linear-gradient(135deg, #1e3a8a 0%, #fbbf24 100%);
          border-color: #fbbf24;
        }
      }
      
      #pac-calc-overlay.target-in-shop {
        animation: targetInShopFlash 0.25s ease-in-out infinite;
      }
      
      /* Full calculator gold flash overlay - always on top */
      #pac-calc-overlay.target-in-shop::before {
        content: '';
        position: absolute;
        inset: 0;  /* Cover entire calculator */
        background: transparent;
        border-radius: 12px;
        pointer-events: none;
        animation: targetInShopFullFlash 0.25s ease-in-out infinite;
        z-index: 999999999 !important;
      }
      
      @keyframes targetInShopFullFlash {
        0%, 100% { 
          background: transparent;
        }
        50% { 
          background: linear-gradient(135deg, rgba(251, 191, 36, 0.3) 0%, rgba(251, 191, 36, 0.5) 100%);
          box-shadow: inset 0 0 50px rgba(251, 191, 36, 0.6);
        }
      }
      
      /* Flash animation for team panel when any team target in shop */
      @keyframes teamTargetInShopFlash {
        0%, 100% { 
          border-color: rgba(255,255,255,0.1);
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }
        50% { 
          border-color: #FF1493;  /* Hot pink */
          background: linear-gradient(135deg, #FF1493 0%, #FF69B4 100%);  /* Bright hot pink gradient */
          box-shadow: 0 0 30px rgba(255, 20, 147, 0.8);  /* Glow effect */
        }
      }
      
      .pac-team-panel.team-target-in-shop {
        animation: teamTargetInShopFlash 0.25s ease-in-out infinite;
      }
      
      .pac-footer {
        background: rgba(0,0,0,0.2);
        padding: 10px 16px;
        border-radius: 0 0 10px 10px;
        border-top: 1px solid rgba(255,255,255,0.05);
        font-size: 11px;
        color: #888;
        display: flex;
        justify-content: space-between;
        position: relative;
        z-index: 1;  /* Above side panels */
      }
      
      .pac-collapsible {
        margin-bottom: 16px;
      }
      
      .pac-collapse-btn {
        width: 100%;
        background: rgba(100,181,246,0.1);
        border: 1px solid rgba(100,181,246,0.2);
        color: #64b5f6;
        padding: 10px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s;
        text-align: left;
      }
      
      .pac-collapse-btn:hover {
        background: rgba(100,181,246,0.15);
      }
      
      .pac-collapse-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
        background: rgba(255,255,255,0.02);
        border-radius: 0 0 6px 6px;
        padding: 0 12px;
      }
      
      .pac-collapse-content.expanded {
        max-height: 800px;
        padding: 12px;
        border: 1px solid rgba(255,255,255,0.05);
        border-top: none;
      }
      
      .pac-status-msg {
        font-size: 12px;
        padding: 8px;
        border-radius: 6px;
        margin-top: 8px;
        text-align: center;
      }
      
      .pac-status-msg.error {
        background: rgba(244,67,54,0.15);
        color: #ff5252;
        border: 1px solid rgba(244,67,54,0.3);
      }
      
      .pac-status-msg.warning {
        background: rgba(255,152,0,0.15);
        color: #ffab40;
        border: 1px solid rgba(255,152,0,0.3);
      }
      
      .pac-live-indicator {
        display: none;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        color: #4caf50;
        margin-top: 8px;
        padding: 6px 10px;
        background: rgba(76,175,80,0.1);
        border-radius: 6px;
        border: 1px solid rgba(76,175,80,0.2);
      }
      
      .pac-live-controls {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }
      
      .pac-live-toggle {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 6px;
        color: #fff;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
      }
      
      .pac-live-toggle:hover {
        background: rgba(255,255,255,0.08);
        border-color: rgba(255,255,255,0.2);
      }
      
      .pac-live-toggle.active {
        background: rgba(76,175,80,0.2);
        border-color: rgba(76,175,80,0.4);
      }
      
      .pac-live-status {
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 11px;
      }
      
      .pac-live-toggle .pac-live-status {
        background: rgba(244,67,54,0.3);
        color: #ff5252;
      }
      
      .pac-live-toggle.active .pac-live-status {
        background: rgba(76,175,80,0.3);
        color: #4caf50;
      }
      
      .pac-speed-select {
        flex: 1;
        padding: 8px;
        background: rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 6px;
        color: #fff;
        font-size: 12px;
        cursor: pointer;
        transition: all 0.2s;
      }
      
      .pac-speed-select:hover {
        border-color: #64b5f6;
      }
      
      .pac-speed-select:focus {
        outline: none;
        border-color: #64b5f6;
        box-shadow: 0 0 8px rgba(100,181,246,0.3);
      }
      
      /* Pokemon Autocomplete Styles */
      .pac-pokemon-selector {
        position: relative;
        width: 100%;
      }
      
      
      /* Evolution Family Styles (v2.5.0) */
      .pac-evolution-family {
        margin-top: 8px;
        padding: 8px;
        background: rgba(100, 181, 246, 0.1);
        border-radius: 6px;
        border: 1px solid rgba(100, 181, 246, 0.2);
      }
      
      .pac-family-title {
        font-size: 11px;
        font-weight: 600;
        color: #64b5f6;
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      
      .pac-family-breakdown {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 8px 0;
      }
      
      .pac-family-row {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        padding: 4px 6px;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 4px;
      }
      
      .pac-family-name {
        font-weight: 600;
        color: #fff;
      }
      
      .pac-family-calc {
        color: #64b5f6;
        font-family: 'Courier New', monospace;
      }
      
      .pac-family-total {
        font-weight: 700;
        text-align: right;
        color: #fff;
        padding-top: 4px;
        border-top: 1px solid rgba(100, 181, 246, 0.3);
        font-size: 13px;
      }

      .pac-autocomplete-input {
        width: 100%;
        text-transform: uppercase;
      }
      
      #pacAutocompleteDropdown {
        position: fixed;
        width: 300px;
        max-height: 400px;
        overflow-y: auto;
        background: #0a0e27;
        border: 1px solid rgba(100,181,246,0.3);
        border-radius: 6px;
        z-index: 1000000;
        box-shadow: 0 8px 16px rgba(0,0,0,0.4);
      }
      
      #pacAutocompleteDropdown.hidden {
        display: none;
      }
      
      .pac-dropdown-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 12px;
        cursor: pointer;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        transition: all 0.2s;
      }
      
      .pac-dropdown-item:hover {
        background: rgba(100,181,246,0.15);
      }
      
      .pac-dropdown-item:last-child {
        border-bottom: none;
      }
      
      .pac-pokemon-name {
        font-weight: 600;
        color: #fff;
        font-size: 13px;
      }
      
      .pac-pokemon-rarity {
        font-size: 10px;
        padding: 3px 8px;
        border-radius: 4px;
        text-transform: uppercase;
        font-weight: 700;
        letter-spacing: 0.5px;
      }
      
      #pacRarityError {
        color: #ff5252;
        font-size: 11px;
        margin-top: 6px;
        padding: 6px 10px;
        background: rgba(244,67,54,0.15);
        border-radius: 6px;
        border: 1px solid rgba(244,67,54,0.3);
      }
      
      #pacRarityError.hidden {
        display: none;
      }
      
      /* Scrollbar styling */
      #pac-calc-body::-webkit-scrollbar,
      #pacAutocompleteDropdown::-webkit-scrollbar {
        width: 8px;
      }
      
      #pac-calc-body::-webkit-scrollbar-track,
      #pacAutocompleteDropdown::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.2);
        border-radius: 10px;
      }
      
      #pac-calc-body::-webkit-scrollbar-thumb,
      #pacAutocompleteDropdown::-webkit-scrollbar-thumb {
        background: rgba(100,181,246,0.3);
        border-radius: 10px;
      }
      
      #pac-calc-body::-webkit-scrollbar-thumb:hover,
      #pacAutocompleteDropdown::-webkit-scrollbar-thumb:hover {
        background: rgba(100,181,246,0.5);
      }
      
      /* ═══════════════════════════════════════════════════════════════════════════
         TEAM TRACKER SIDE PANEL (v2.9.6)
         ═══════════════════════════════════════════════════════════════════════════ */
      
      .pac-team-panel {
        position: absolute;
        left: 0;
        top: 0;
        width: 380px;
        height: 100%;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 2px solid #0f3460;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: -2147483648 !important;  /* Absolute minimum - below everything for flash visibility */
        display: flex;
        flex-direction: column;
      }
      
      .pac-team-panel.expanded {
        left: 390px;
      }
      
      .pac-team-toggle {
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        width: 40px;
        height: 80px;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 2px solid #0f3460;
        border-left: none;
        border-radius: 0 8px 8px 0;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #64b5f6;
        font-size: 20px;
        z-index: -1 !important;  /* Below main calculator so flash shows */
      }
      
      .pac-team-toggle:hover {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        border-color: #64b5f6;
        transition: background 0.2s, border-color 0.2s;
      }
      
      .pac-team-arrow {
        transition: transform 0.3s;
        display: inline-block;
      }
      
      .pac-team-panel.expanded .pac-team-arrow {
        transform: rotate(180deg);
      }
      
      .pac-team-content {
        display: flex;
        flex-direction: column;
        height: 100%;
        padding: 16px;
        position: relative;
        opacity: 0;
        transition: opacity 0.2s ease-in-out;
        pointer-events: none;
      }
      
      .pac-team-panel.expanded .pac-team-content {
        opacity: 1;
        pointer-events: all;
        transition-delay: 0.3s;
      }
      
      .pac-team-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        padding-bottom: 12px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
      }
      
      .pac-team-header h3 {
        margin: 0;
        font-size: 16px;
        color: #64b5f6;
        font-weight: 600;
      }
      
      .pac-team-close {
        background: none;
        border: none;
        color: #888;
        font-size: 24px;
        cursor: pointer;
        padding: 0;
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: all 0.2s;
      }
      
      .pac-team-close:hover {
        background: rgba(255,255,255,0.1);
        color: #fff;
      }
      
      .pac-team-list {
        flex: 1;
        overflow-y: auto;
        margin-bottom: 16px;
        min-height: 200px;
      }
      
      .pac-team-item {
        background: rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 8px;
        transition: all 0.2s;
        cursor: pointer;
      }
      
      .pac-team-item:hover {
        background: rgba(255,255,255,0.05);
        border-color: rgba(100,181,246,0.3);
      }
      
      .pac-team-item.active {
        border-color: #64b5f6;
        background: rgba(100,181,246,0.1);
      }
      
      .pac-team-item.not-in-pool {
        opacity: 0.6;
        border-style: dashed;
      }
      
      .pac-team-item-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      
      .pac-team-checkbox {
        width: 18px;
        height: 18px;
        cursor: pointer;
      }
      
      .pac-team-name {
        flex: 1;
        font-weight: 600;
        font-size: 14px;
        color: #fff;
      }
      
      .pac-team-remove {
        background: none;
        border: none;
        color: #f44336;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: all 0.2s;
      }
      
      .pac-team-remove:hover {
        background: rgba(244,67,54,0.2);
      }
      
      .pac-team-meta {
        font-size: 11px;
        color: #888;
        margin-bottom: 6px;
      }
      
      .pac-team-stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        font-size: 11px;
      }
      
      .pac-team-stat-mini {
        background: rgba(0,0,0,0.3);
        padding: 4px 8px;
        border-radius: 4px;
        text-align: center;
      }
      
      .pac-team-stat-mini-label {
        color: #888;
        font-size: 10px;
      }
      
      .pac-team-stat-mini-value {
        color: #64b5f6;
        font-weight: 600;
      }
      
      .pac-team-combined {
        background: rgba(100,181,246,0.1);
        border: 1px solid rgba(100,181,246,0.2);
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 12px;
      }
      
      .pac-team-combined-title {
        font-size: 12px;
        color: #64b5f6;
        font-weight: 600;
        margin-bottom: 8px;
        text-align: center;
      }
      
      .pac-team-combined-stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
      }
      
      .pac-team-stat {
        text-align: center;
      }
      
      .pac-team-stat-label {
        display: block;
        font-size: 10px;
        color: #888;
        margin-bottom: 4px;
      }
      
      .pac-team-stat-value {
        display: block;
        font-size: 16px;
        color: #fff;
        font-weight: 700;
      }
      
      .pac-team-add-section {
        display: flex;
        gap: 8px;
        align-items: stretch;
      }
      
      .pac-team-input {
        flex: 1;
        background: rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
        color: #fff;
        padding: 10px;
        border-radius: 6px;
        font-size: 13px;
        transition: all 0.2s;
      }
      
      .pac-team-input:focus {
        outline: none;
        border-color: #64b5f6;
        background: rgba(0,0,0,0.4);
      }
      
      .pac-team-add-btn {
        background: rgba(76,175,80,0.2);
        border: 1px solid rgba(76,175,80,0.4);
        color: #4caf50;
        padding: 10px 20px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s;
        white-space: nowrap;
      }
      
      .pac-team-add-btn:hover {
        background: rgba(76,175,80,0.3);
        border-color: #4caf50;
      }
      
      .pac-team-dropdown {
        position: fixed;
        width: 320px;
        background: rgba(26, 26, 46, 0.98);
        border: 2px solid #64b5f6;
        border-radius: 8px;
        max-height: 400px;
        overflow-y: auto;
        z-index: 999999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.6);
        padding: 8px 0;
      }
      
      .pac-team-dropdown.hidden {
        display: none;
      }
      
      .pac-team-dropdown-item {
        padding: 8px 12px;
        cursor: pointer;
        transition: background 0.1s;
        font-size: 13px;
      }
      
      .pac-team-dropdown-item:hover,
      .pac-team-dropdown-item.selected {
        background: rgba(100,181,246,0.2);
      }
      
      .pac-team-dropdown-name {
        font-weight: 600;
      }
      
      .pac-team-dropdown-meta {
        font-size: 11px;
        color: #888;
        margin-top: 2px;
      }
      
      .pac-team-add {
        width: 100%;
        background: rgba(76,175,80,0.2);
        border: 1px solid rgba(76,175,80,0.4);
        color: #4caf50;
        padding: 10px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s;
      }
      
      .pac-team-add:hover {
        background: rgba(76,175,80,0.3);
        border-color: #4caf50;
      }
      
      .pac-team-empty {
        text-align: center;
        color: #888;
        font-size: 13px;
        padding: 40px 20px;
      }
      
      .pac-team-empty-icon {
        font-size: 48px;
        margin-bottom: 12px;
        opacity: 0.3;
      }
      
      /* Current Team Panel Styles */
      .pac-current-toggle {
        top: calc(50% - 60px) !important;  /* Stacked above team tracker arrow */
      }
      
      .pac-current-sections {
        display: flex;
        flex-direction: column;
        gap: 16px;
        flex: 1;
        overflow-y: auto;
      }
      
      .pac-current-section {
        background: rgba(0,0,0,0.2);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        padding: 12px;
      }
      
      .pac-current-section-title {
        font-size: 12px;
        font-weight: 600;
        color: #64b5f6;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      
      .pac-current-list {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        min-height: 40px;
      }
      
      .pac-current-item {
        background: rgba(100,181,246,0.15);
        border: 1px solid rgba(100,181,246,0.3);
        border-radius: 6px;
        padding: 6px 10px;
        font-size: 11px;
        display: flex;
        align-items: center;
        gap: 4px;
        white-space: nowrap;
      }
      
      .pac-current-item-name {
        font-weight: 600;
      }
      
      .pac-current-item-stars {
        color: #fbbf24;
        font-size: 10px;
      }
      
      .pac-current-empty {
        color: #666;
        font-size: 11px;
        font-style: italic;
        padding: 8px;
      }
      
      /* EULA Modal */
      #pac-eula-overlay {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(0, 0, 0, 0.95) !important;
        z-index: 2147483647 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        backdrop-filter: blur(10px);
      }
      
      #pac-eula-modal {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 2px solid #0f3460;
        border-radius: 12px;
        max-width: 600px;
        max-height: 80vh;
        padding: 24px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.6);
        color: #e9e9e9;
        overflow-y: auto;
        position: relative;
        z-index: 2147483647 !important;
      }
      
      .pac-eula-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 16px;
        color: #64b5f6;
        text-align: center;
      }
      
      .pac-eula-content {
        font-size: 13px;
        line-height: 1.6;
        margin-bottom: 20px;
        color: #ccc;
      }
      
      .pac-eula-section {
        margin-bottom: 16px;
      }
      
      .pac-eula-section-title {
        font-size: 14px;
        font-weight: 600;
        color: #64b5f6;
        margin-bottom: 8px;
      }
      
      .pac-eula-highlight {
        background: rgba(76, 175, 80, 0.2);
        padding: 12px;
        border-left: 3px solid #4caf50;
        border-radius: 4px;
        margin: 12px 0;
      }
      
      .pac-eula-warning {
        background: rgba(255, 152, 0, 0.2);
        padding: 12px;
        border-left: 3px solid #ff9800;
        border-radius: 4px;
        margin: 12px 0;
      }
      
      .pac-eula-checkboxes {
        margin: 20px 0;
      }
      
      .pac-eula-checkbox-row {
        display: flex !important;
        align-items: flex-start !important;
        gap: 12px !important;
        margin-bottom: 12px !important;
        padding: 12px !important;
        background: rgba(255,255,255,0.03) !important;
        border-radius: 6px !important;
        cursor: pointer !important;
      }
      
      .pac-eula-custom-checkbox {
        width: 32px !important;
        height: 32px !important;
        min-width: 32px !important;
        min-height: 32px !important;
        background: #000 !important;
        border: 2px solid #4caf50 !important;
        border-radius: 6px !important;
        cursor: pointer !important;
        position: relative !important;
        transition: all 0.2s !important;
        flex-shrink: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      
      .pac-eula-custom-checkbox:hover {
        border-color: #66bb6a !important;
        box-shadow: 0 0 8px rgba(76, 175, 80, 0.4) !important;
      }
      
      .pac-eula-custom-checkbox.checked {
        background: #000 !important;
        border-color: #4caf50 !important;
      }
      
      .pac-eula-custom-checkbox.checked::after {
        content: '✓' !important;
        color: #4caf50 !important;
        font-size: 24px !important;
        font-weight: bold !important;
        line-height: 1 !important;
      }
      
      .pac-eula-checkbox-row label {
        flex: 1;
        cursor: pointer;
        font-size: 13px;
        line-height: 1.5;
      }
      
      .pac-eula-button {
        width: 100%;
        padding: 14px;
        background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
        border: none;
        border-radius: 8px;
        color: white;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
      }
      
      .pac-eula-button:disabled {
        background: #444;
        cursor: not-allowed;
        opacity: 0.5;
      }
      
      .pac-eula-button:not(:disabled):hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(76, 175, 80, 0.4);
      }
    `;
    document.head.appendChild(style);

    // Create overlay HTML
    const overlay = document.createElement('div');
    overlay.id = 'pac-calc-overlay';
    overlay.innerHTML = `
      <div id="pac-calc-header">
        <div id="pac-calc-title">
          <span class="pac-status-dot" id="pacStatusDot"></span>
          <span>PAC Live Data v2.16.6</span>
        </div>
        <div id="pac-calc-controls">
          <button class="pac-ctrl-btn" id="pacMinBtn" title="Minimize">−</button>
          <button class="pac-ctrl-btn" id="pacCloseBtn" title="Close">×</button>
        </div>
      </div>
      
      <div id="pac-calc-body">
        <div class="pac-section">
          <div class="pac-section-title">🎯 Target</div>
          <div class="pac-row">
            <div class="pac-field">
              <label>Level</label>
              <select id="pacLevel">
                ${[1,2,3,4,5,6,7,8,9].map(l => `<option value="${l}" ${l===7?'selected':''}>Lv ${l}</option>`).join('')}
              </select>
            </div>
            <div class="pac-field">
              <label>Rarity</label>
              <select id="pacRarity">
                <option value="common">Common</option>
                <option value="uncommon">Uncommon</option>
                <option value="rare" selected>Rare</option>
                <option value="epic">Epic</option>
                <option value="ultra">Ultra</option>
              </select>
            </div>
            <div class="pac-field">
              <label>Evo</label>
              <select id="pacEvo">
                <option value="twoStar">2★</option>
                <option value="threeStar" selected>3★</option>
              </select>
            </div>
          </div>
        </div>
        
        <div class="pac-section">
          <div class="pac-section-title">📊 Pool State</div>
          <div class="pac-row">
            <div class="pac-field">
              <label>Owned</label>
              <input type="number" id="pacOwned" value="0" min="0">
            </div>
            <div class="pac-field">
              <label>Scouted</label>
              <input type="number" id="pacScouted" value="0" min="0">
            </div>
          </div>
          <div class="pac-row">
            <div class="pac-field">
              <label>Target Pokemon (Auto-Scout)</label>
              <div class="pac-pokemon-selector">
                <input 
                  type="text" 
                  id="pacTargetPokemon" 
                  class="pac-autocomplete-input" 
                  placeholder="Type to search..."
                  autocomplete="off"
                >
                <div id="pacRarityError" class="hidden"></div>
              
              <!-- Evolution Family Display (v2.5.0) -->
              <div id="pacEvolutionFamily" class="pac-evolution-family hidden">
                <div class="pac-family-title">Evolution Family</div>
                <div id="pacFamilyBreakdown" class="pac-family-breakdown">
                  <!-- Dynamically populated -->
                </div>
                <div class="pac-family-total">
                  Total: <span id="pacFamilyTotal">0</span> copies
                </div>
              </div>
</div>
            </div>
          </div>
          <div class="pac-toggle-row">
            <label class="pac-toggle">
              <input type="checkbox" id="pacDitto" checked disabled>
              <span>Ditto (Always Enabled)</span>
            </label>
            <label class="pac-toggle">
              <input type="checkbox" id="pacAutoScout" checked>
              <span>Auto-Scout</span>
            </label>
          </div>
          
          <!-- Live Tracking Controls -->
          <div class="pac-row">
            <div class="pac-field">
              <label>Your In-Game Name (for flash alerts)</label>
              <input type="text" id="pacPlayerName" placeholder="Enter your name..." autocomplete="off">
            </div>
          </div>
          
          <div class="pac-live-controls">
            <button class="pac-live-toggle" id="pacLiveToggle">
              <span class="pac-live-status" id="pacLiveStatus">OFF</span>
              <span>Live Tracking</span>
            </button>
            <select id="pacPollSpeed" class="pac-speed-select">
              <option value="250">Very Fast (250ms)</option>
              <option value="350">Fast (350ms)</option>
              <option value="500" selected>Normal (500ms)</option>
              <option value="1000">Slow (1s)</option>
              <option value="2000">Slower (2s)</option>
              <option value="5000">Slowest (5s)</option>
            </select>
          </div>
          
          <div class="pac-row">
            <button id="pacNewGame" class="pac-new-game-btn">
              🔄 NEW GAME - Reinject Extractor
            </button>
          </div>
          
          <div class="pac-live-indicator" id="pacLiveIndicator" style="display: none;">
            <span>🟢 Live:</span>
            <span id="pacLiveCount">0</span>
            <span>units tracked</span>
          </div>
        </div>
        
        <!-- Add Picks Section -->
        <div class="pac-collapsible" id="pacAddPicksSection">
          <button class="pac-collapse-btn">🌍 Add Picks</button>
          <div class="pac-collapse-content">
            <div class="pac-warning-banner" style="margin-bottom: 16px;">
              <span style="font-weight: 600;">⚠️ DO NOT PUT WILD UNITS HERE</span>
              <span style="display: block; margin-top: 4px; font-size: 12px;">Use Wild Mechanics section for Wild units</span>
            </div>
            
            <!-- Round 5 -->
            <div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(100,181,246,0.1);">
              <label class="pac-toggle">
                <input type="checkbox" id="pacRound5">
                <span style="font-weight: 600; color: #10b981;">Round 5+ (Uncommon Add Picks)</span>
              </label>
              <div id="pacRound5Input" class="hidden" style="margin-left: 28px; margin-top: 8px;">
                <label style="display: block; font-size: 12px; color: #bbb; margin-bottom: 4px;">Add picks (2★-max)</label>
                <input type="number" id="pacRound5Picks" value="8" min="0" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.3); border: 1px solid rgba(100,181,246,0.2); border-radius: 8px; color: white;">
              </div>
            </div>
            
            <!-- Round 8 -->
            <div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(100,181,246,0.1);">
              <label class="pac-toggle">
                <input type="checkbox" id="pacRound8">
                <span style="font-weight: 600; color: #00d9ff;">Round 8+ (Rare Add Picks)</span>
              </label>
              <div id="pacRound8Input" class="hidden" style="margin-left: 28px; margin-top: 8px;">
                <label style="display: block; font-size: 12px; color: #bbb; margin-bottom: 4px;">Add picks (2★-max)</label>
                <input type="number" id="pacRound8Picks" value="8" min="0" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.3); border: 1px solid rgba(100,181,246,0.2); border-radius: 8px; color: white;">
              </div>
            </div>
            
            <!-- Round 11 -->
            <div>
              <label class="pac-toggle">
                <input type="checkbox" id="pacRound11">
                <span style="font-weight: 600; color: #a855f7;">Round 11+ (Epic Add Picks)</span>
              </label>
              <div id="pacRound11Input" class="hidden" style="margin-left: 28px; margin-top: 8px;">
                <label style="display: block; font-size: 12px; color: #bbb; margin-bottom: 4px;">Add picks (2★-max)</label>
                <input type="number" id="pacRound11Picks" value="8" min="0" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.3); border: 1px solid rgba(100,181,246,0.2); border-radius: 8px; color: white;">
              </div>
            </div>
          </div>
        </div>
        
        <!-- Portal Regionals Section -->
        <div class="pac-collapsible" id="pacPortalSection">
          <button class="pac-collapse-btn">🌀 Portal-Specific Regionals</button>
          <div class="pac-collapse-content">
            <div class="pac-warning-banner" style="margin-bottom: 16px;">
              <span style="font-weight: 600;">⚠️ DO NOT PUT WILD UNITS HERE</span>
              <span style="display: block; margin-top: 4px; font-size: 12px;">Use Wild Mechanics section for Wild units</span>
            </div>
            
            <div style="display: flex; flex-direction: column; gap: 12px;">
              <!-- Common -->
              <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 8px; align-items: center; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 8px;">
                <span style="color: #9ca3af; font-weight: 600;">Common</span>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">2★-max</label>
                  <input type="number" id="pacPortalCommon2" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">3★-max</label>
                  <input type="number" id="pacPortalCommon3" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
              </div>
              
              <!-- Uncommon -->
              <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 8px; align-items: center; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 8px;">
                <span style="color: #10b981; font-weight: 600;">Uncommon</span>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">2★-max</label>
                  <input type="number" id="pacPortalUncommon2" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">3★-max</label>
                  <input type="number" id="pacPortalUncommon3" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
              </div>
              
              <!-- Rare -->
              <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 8px; align-items: center; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 8px;">
                <span style="color: #00d9ff; font-weight: 600;">Rare</span>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">2★-max</label>
                  <input type="number" id="pacPortalRare2" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">3★-max</label>
                  <input type="number" id="pacPortalRare3" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
              </div>
              
              <!-- Epic -->
              <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 8px; align-items: center; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 8px;">
                <span style="color: #a855f7; font-weight: 600;">Epic</span>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">2★-max</label>
                  <input type="number" id="pacPortalEpic2" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">3★-max</label>
                  <input type="number" id="pacPortalEpic3" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
              </div>
              
              <!-- Ultra -->
              <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 8px; align-items: center; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 8px;">
                <span style="color: #ef4444; font-weight: 600;">Ultra</span>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">2★-max</label>
                  <input type="number" id="pacPortalUltra2" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
                <div>
                  <label style="display: block; font-size: 11px; color: #bbb; margin-bottom: 4px;">3★-max</label>
                  <input type="number" id="pacPortalUltra3" value="0" min="0" style="width: 100%; padding: 6px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: white; font-size: 13px;">
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="pac-collapsible" id="pacWildSection">
          <button class="pac-collapse-btn">🌿 Wild Mechanics</button>
          <div class="pac-collapse-content">
            <div class="pac-toggle-row" style="margin-top: 8px;">
              <label class="pac-toggle">
                <input type="checkbox" id="pacTargetWild">
                <span>Target is Wild</span>
              </label>
              <label class="pac-toggle">
                <input type="checkbox" id="pacPVE">
                <span>PvE Round</span>
              </label>
            </div>
            <div class="pac-row" style="margin-top: 8px;">
              <div class="pac-field">
                <label>Wild Owned</label>
                <input type="number" id="pacWildOwned" value="0" min="0">
              </div>
              <div class="pac-field">
                <label>Wild Scouted</label>
                <input type="number" id="pacWildScouted" value="0" min="0">
              </div>
            </div>
          </div>
        </div>
        
        <div class="pac-results">
          <div class="pac-result-row">
            <span class="pac-result-label">Per Refresh:</span>
            <span class="pac-result-value" id="pacPerRefresh">0.00%</span>
          </div>
          <div class="pac-confidence-control">
            <label for="pacConfidenceSlider">
              <span>Confidence</span>
              <span id="pacConfidenceValue">75</span>%
            </label>
            <input type="range" id="pacConfidenceSlider" min="50" max="99" value="75" step="1">
          </div>
          <div class="pac-result-row">
            <span class="pac-result-label" id="pacConfidenceLabel">75% Confidence:</span>
            <span class="pac-result-value" id="pacConfidence">0 rolls</span>
          </div>
          <div class="pac-result-row">
            <span class="pac-result-label" id="pacConfidenceGoldLabel">Gold (75%):</span>
            <span class="pac-result-value" id="pacGoldConfidence">0g</span>
          </div>
        </div>
        
        <div id="pacStatusWild" class="pac-status-msg"></div>
        <div id="pacStatusPool" class="pac-status-msg"></div>
      </div>
      
      <div class="pac-footer">
        <span>Pool: <span id="pacPoolInfo">0/0</span></span>
        <span>Rate: <span id="pacRateInfo">0</span>%</span>
      </div>
      
      <!-- Team Tracker Side Panel -->
      <div id="pac-team-panel" class="pac-team-panel">
        <button id="pacTeamToggle" class="pac-team-toggle" title="Team Tracker">
          <span class="pac-team-arrow">→</span>
        </button>
        <div class="pac-team-content">
          <div class="pac-team-header">
            <h3>🎯 Team Tracker</h3>
            <button id="pacTeamClose" class="pac-team-close">×</button>
          </div>
          <div id="pacTeamList" class="pac-team-list">
            <!-- Team targets will be added here -->
          </div>
          <div class="pac-team-combined">
            <div class="pac-team-combined-title">Combined Probability</div>
            <div class="pac-team-combined-stats">
              <div class="pac-team-stat">
                <span class="pac-team-stat-label">Hit any:</span>
                <span id="pacTeamCombinedProb" class="pac-team-stat-value">0%</span>
              </div>
              <div class="pac-team-stat">
                <span class="pac-team-stat-label">Expected:</span>
                <span id="pacTeamCombinedRolls" class="pac-team-stat-value">0 rolls</span>
              </div>
            </div>
          </div>
          <div class="pac-team-add-section">
            <input type="text" id="pacTeamAddInput" placeholder="Type Pokemon name..." autocomplete="off" class="pac-team-input">
            <button id="pacTeamAddBtn" class="pac-team-add-btn">Add</button>
          </div>
        </div>
      </div>
      
      <!-- Current Team Side Panel -->
      <div id="pac-current-panel" class="pac-team-panel">
        <button id="pacCurrentToggle" class="pac-team-toggle pac-current-toggle" title="Current Team" style="top: calc(50% - 60px);">
          <span class="pac-team-arrow">→</span>
        </button>
        <div class="pac-team-content">
          <div class="pac-team-header">
            <h3>📋 Current Team</h3>
            <button id="pacCurrentClose" class="pac-team-close">×</button>
          </div>
          <div class="pac-current-sections">
            <div class="pac-current-section">
              <div class="pac-current-section-title">Owned Units (<span id="pacCurrentTotalCount">0</span>)</div>
              <div id="pacCurrentUnits" class="pac-current-list">
                <!-- Owned Pokemon will be added here -->
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    
    // Create autocomplete dropdown as separate floating element
    const dropdown = document.createElement('div');
    dropdown.id = 'pacAutocompleteDropdown';
    dropdown.className = 'hidden';
    document.body.appendChild(dropdown);
    
    return overlay;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DRAG FUNCTIONALITY
  // ═══════════════════════════════════════════════════════════════════════════

  function setupDrag(overlay) {
    const header = document.getElementById('pac-calc-header');
    let isDragging = false;
    let startX, startY, initialX, initialY;

    header.addEventListener('mousedown', (e) => {
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = overlay.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;
      header.style.cursor = 'grabbing';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      overlay.style.left = (initialX + dx) + 'px';
      overlay.style.top = (initialY + dy) + 'px';
      overlay.style.right = 'auto';
      
      // Update team dropdown position if it's open
      if (window.updateTeamDropdownPosition) {
        window.updateTeamDropdownPosition();
      }
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        header.style.cursor = 'move';
        savePosition();
      }
    });
  }

  function savePosition() {
    const overlay = document.getElementById('pac-calc-overlay');
    const rect = overlay.getBoundingClientRect();
    localStorage.setItem('pac-calc-position', JSON.stringify({
      left: rect.left,
      top: rect.top
    }));
  }

  function loadPosition() {
    const saved = localStorage.getItem('pac-calc-position');
    if (saved) {
      const pos = JSON.parse(saved);
      const overlay = document.getElementById('pac-calc-overlay');
      overlay.style.left = pos.left + 'px';
      overlay.style.top = pos.top + 'px';
      overlay.style.right = 'auto';
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // COLLAPSIBLE SECTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  function setupCollapsibles() {
    document.querySelectorAll('.pac-collapse-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const content = btn.nextElementSibling;
        content.classList.toggle('expanded');
      });
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // UI BINDINGS
  // ═══════════════════════════════════════════════════════════════════════════

  function bindUI() {
    // Minimize/Close buttons
    document.getElementById('pacMinBtn').addEventListener('click', () => {
      const body = document.getElementById('pac-calc-body');
      const overlay = document.getElementById('pac-calc-overlay');
      isMinimized = !isMinimized;
      body.classList.toggle('minimized');
      overlay.classList.toggle('minimized');
      document.getElementById('pacMinBtn').textContent = isMinimized ? '+' : '−';
    });

    document.getElementById('pacCloseBtn').addEventListener('click', () => {
      document.getElementById('pac-calc-overlay').style.display = 'none';
    });

    // New Game button - reinject extractor for next match
    document.getElementById('pacNewGame').addEventListener('click', () => {
      if (DEBUG_MODE) console.log('🔄 NEW GAME - Reinjecting extractor...');
      injectExtractor();
      showNotification('Extractor reinjected for new game!', 'success');
    });

    // Inputs
    const inputs = {
      'pacLevel': 'level',
      'pacRarity': 'targetRarity',
      'pacEvo': 'targetEvo',
      'pacOwned': 'copiesOwned',
      'pacScouted': 'copiesTaken',
      'pacWildOwned': 'wildUnitsOwned',
      'pacWildScouted': 'wildUnitsTaken'
    };

    Object.entries(inputs).forEach(([id, key]) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', (e) => {
          const value = e.target.type === 'number' ? parseInt(e.target.value) || 0 : e.target.value;
          state[key] = value;
          updateDisplay();
        });
      }
    });

    // Checkboxes
    const checkboxes = {
      'pacDitto': 'dittoEnabled',
      'pacAutoScout': 'autoScout',
      'pacTargetWild': 'targetIsWild',
      'pacPVE': 'pveRoundEnabled'
    };

    Object.entries(checkboxes).forEach(([id, key]) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', (e) => {
          state[key] = e.target.checked;
          updateDisplay();
        });
      }
    });

    // Confidence slider
    const confidenceSlider = document.getElementById('pacConfidenceSlider');
    const confidenceValue = document.getElementById('pacConfidenceValue');
    const confidenceLabel = document.getElementById('pacConfidenceLabel');
    const confidenceGoldLabel = document.getElementById('pacConfidenceGoldLabel');
    
    if (confidenceSlider) {
      confidenceSlider.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        state.confidencePercent = value;
        confidenceValue.textContent = value;
        confidenceLabel.textContent = `${value}% Confidence:`;
        confidenceGoldLabel.textContent = `Gold (${value}%):`;
        updateDisplay();
      });
    }

    // Round Add Picks
    const round5Check = document.getElementById('pacRound5');
    const round5Input = document.getElementById('pacRound5Input');
    const round5Picks = document.getElementById('pacRound5Picks');
    
    if (round5Check) {
      round5Check.addEventListener('change', (e) => {
        state.round5Enabled = e.target.checked;
        round5Input.classList.toggle('hidden', !e.target.checked);
        updateDisplay();
      });
    }
    
    if (round5Picks) {
      round5Picks.addEventListener('change', (e) => {
        state.round5AddPicks = Math.max(0, parseInt(e.target.value) || 0);
        updateDisplay();
      });
    }
    
    const round8Check = document.getElementById('pacRound8');
    const round8Input = document.getElementById('pacRound8Input');
    const round8Picks = document.getElementById('pacRound8Picks');
    
    if (round8Check) {
      round8Check.addEventListener('change', (e) => {
        state.round8Enabled = e.target.checked;
        round8Input.classList.toggle('hidden', !e.target.checked);
        updateDisplay();
      });
    }
    
    if (round8Picks) {
      round8Picks.addEventListener('change', (e) => {
        state.round8AddPicks = Math.max(0, parseInt(e.target.value) || 0);
        updateDisplay();
      });
    }
    
    const round11Check = document.getElementById('pacRound11');
    const round11Input = document.getElementById('pacRound11Input');
    const round11Picks = document.getElementById('pacRound11Picks');
    
    if (round11Check) {
      round11Check.addEventListener('change', (e) => {
        state.round11Enabled = e.target.checked;
        round11Input.classList.toggle('hidden', !e.target.checked);
        updateDisplay();
      });
    }
    
    if (round11Picks) {
      round11Picks.addEventListener('change', (e) => {
        state.round11AddPicks = Math.max(0, parseInt(e.target.value) || 0);
        updateDisplay();
      });
    }

    // Portal Regionals
    const portalInputs = {
      'pacPortalCommon2': ['common', 'twoStar'],
      'pacPortalCommon3': ['common', 'threeStar'],
      'pacPortalUncommon2': ['uncommon', 'twoStar'],
      'pacPortalUncommon3': ['uncommon', 'threeStar'],
      'pacPortalRare2': ['rare', 'twoStar'],
      'pacPortalRare3': ['rare', 'threeStar'],
      'pacPortalEpic2': ['epic', 'twoStar'],
      'pacPortalEpic3': ['epic', 'threeStar'],
      'pacPortalUltra2': ['ultra', 'twoStar'],
      'pacPortalUltra3': ['ultra', 'threeStar']
    };
    
    Object.entries(portalInputs).forEach(([id, [rarity, evo]]) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', (e) => {
          state.portalRegionals[rarity][evo] = Math.max(0, parseInt(e.target.value) || 0);
          updateDisplay();
        });
      }
    });

    // Player name input
    const playerNameInput = document.getElementById('pacPlayerName');
    if (playerNameInput) {
      playerNameInput.addEventListener('input', (e) => {
        state.playerName = e.target.value.trim();
        // Save to localStorage for persistence
        try {
          localStorage.setItem('pac_playerName', state.playerName);
        } catch (err) {
          if (DEBUG_MODE) console.warn('Failed to save playerName to localStorage:', err);
        }
      });
    }

    // Setup autocomplete
    setupAutocomplete();
    
    // Live tracking toggle
    document.getElementById('pacLiveToggle').addEventListener('click', () => {
      liveTrackingActive = !liveTrackingActive;
      const toggleBtn = document.getElementById('pacLiveToggle');
      const statusText = document.getElementById('pacLiveStatus');
      
      if (liveTrackingActive) {
        toggleBtn.classList.add('active');
        statusText.textContent = 'ON';
        startLiveExtraction();
      } else {
        toggleBtn.classList.remove('active');
        statusText.textContent = 'OFF';
        stopLiveExtraction();
      }
    });
    
    // Poll speed selector
    document.getElementById('pacPollSpeed').addEventListener('change', (e) => {
      currentPollSpeed = parseInt(e.target.value);
      // Restart extraction if already active
      if (liveTrackingActive && extractionInterval) {
        stopLiveExtraction();
        startLiveExtraction();
      }
    });
  }
  
  function stopLiveExtraction() {
    if (extractionInterval) {
      clearInterval(extractionInterval);
      extractionInterval = null;
    }
    isConnected = false;
    document.getElementById('pacStatusDot').classList.remove('connected');
    document.getElementById('pacLiveIndicator').style.display = 'none';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DISPLAY UPDATE
  // ═══════════════════════════════════════════════════════════════════════════

  function formatPercent(val, decimals = 2) {
    if (val === 0) return '0.' + '0'.repeat(decimals) + '%';
    if (val < Math.pow(10, -decimals)) return '<0.' + '0'.repeat(decimals - 1) + '1%';
    return val.toFixed(decimals) + '%';
  }

  function formatRolls(val) {
    if (!isFinite(val)) return '∞';
    return Math.ceil(val) + ' rolls';
  }

  function formatGold(val) {
    if (!isFinite(val)) return '∞g';
    return Math.ceil(val) + 'g';
  }

  function updateDisplay() {
    const r = calculate();
    
    // Main results
    document.getElementById('pacPerRefresh').textContent = formatPercent(
      state.dittoEnabled ? r.perRefreshWithDitto : r.perRefresh, 2
    );
    
    // Dynamic confidence
    document.getElementById('pacConfidence').textContent = formatRolls(r.expectedForConfidence);
    document.getElementById('pacGoldConfidence').textContent = formatGold(r.goldForConfidence);
    
    // Footer
    document.getElementById('pacPoolInfo').textContent = `${r.targetCopies}/${r.maxTargetCopies}`;
    document.getElementById('pacRateInfo').textContent = r.rarityChance.toFixed(0);
    
    // Status messages
    const wildStatus = document.getElementById('pacStatusWild');
    const poolStatus = document.getElementById('pacStatusPool');
    wildStatus.className = 'pac-status-msg';
    poolStatus.className = 'pac-status-msg';
    wildStatus.textContent = '';
    poolStatus.textContent = '';
    
    if (r.wildTargetImpossible) {
      wildStatus.textContent = `❌ No Wild ${state.targetRarity} ${state.targetEvo === 'twoStar' ? '2★' : '3★'} exist`;
      wildStatus.className = 'pac-status-msg error';
    } else if (state.targetIsWild && r.wildBoost === 0) {
      wildStatus.textContent = '⚠️ Need PVE or Wild owned';
      wildStatus.className = 'pac-status-msg warning';
    }
    
    if (r.targetCopies === 0) {
      poolStatus.textContent = '❌ Pool depleted!';
      poolStatus.className = 'pac-status-msg error';
    } else if (r.targetCopies <= 3) {
      poolStatus.textContent = `⚠️ Only ${r.targetCopies} copies left`;
      poolStatus.className = 'pac-status-msg warning';
    }
    
    // Update team panel if it exists
    if (state.teamTargets.length > 0) {
      updateTeamDisplay();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LIVE EXTRACTION LOOP
  // ═══════════════════════════════════════════════════════════════════════════

  let isConnected = false;

  function startLiveExtraction() {
    // Inject the extractor script into page context
    injectExtractor();
    
      // ═══════════════════════════════════════════════════════════════════════════
  // EVOLUTION FAMILY UI UPDATE (v2.5.0)
  // ═══════════════════════════════════════════════════════════════════════════

  function updateFamilyBreakdown(breakdown, total) {
    const container = document.getElementById('pacFamilyBreakdown');
    const familySection = document.getElementById('pacEvolutionFamily');
    
    if (!container || !familySection) return;
    
    if (breakdown.length === 0) {
      familySection.classList.add('hidden');
      return;
    }
    
    familySection.classList.remove('hidden');
    
    container.innerHTML = breakdown.map(item => `
      <div class="pac-family-row">
        <span class="pac-family-name">${item.name}</span>
        <span class="pac-family-calc">${item.count} × ${item.cost} = ${item.weighted}</span>
      </div>
    `).join('');
    
    document.getElementById('pacFamilyTotal').textContent = total;
  }

  // Listen for extraction responses via postMessage
    window.addEventListener('message', (event) => {
      if (event.data && event.data.type === 'PAC_EXTRACT_RESPONSE') {
        const data = event.data.data;
        
        if (data && data.totalUnits > 0) {
          if (!isConnected) {
            isConnected = true;
            document.getElementById('pacStatusDot').classList.add('connected');
            if (DEBUG_MODE) console.log('🎮 PAC Calculator: Connected to game!', data);
          }
          
          lastPoolData = data;
          
          // Update live indicator
          document.getElementById('pacLiveIndicator').style.display = 'flex';
          document.getElementById('pacLiveCount').textContent = data.totalUnits;
          
          // Auto-scout if enabled and target pokemon specified
          if (state.autoScout && state.targetPokemon) {
            const targetName = state.targetPokemon.toUpperCase();
            let count = 0;
            
            // Evolution family aggregation (v2.5.0)
            if (state.evolutionFamily && state.evolutionFamily.length > 0) {
              const breakdown = [];
              let totalWeighted = 0;
              
              state.evolutionFamily.forEach(formName => {
                const formCount = data.pokemonCounts[formName] || 0;
                if (formCount > 0) {
                  const cost = getEvolutionCost(formName);
                  const weighted = formCount * cost;
                  totalWeighted += weighted;
                  
                  breakdown.push({
                    name: formName,
                    count: formCount,
                    cost: cost,
                    weighted: weighted
                  });
                }
              });
              
              count = totalWeighted;
              
              // Update visual breakdown
              updateFamilyBreakdown(breakdown, totalWeighted);
            } else {
              // Fallback to old behavior
              Object.entries(data.pokemonCounts).forEach(([name, c]) => {
                if (name.toUpperCase() === targetName) {
                  count += c;
                }
              });
            }
            
            // Update scouted field if changed
            if (count !== state.copiesTaken) {
              state.copiesTaken = count;
              document.getElementById('pacScouted').value = count;
            }
          }
          
          // Check if target is in player's own shop (FLASH ALERT)
          const overlay = document.getElementById('pac-calc-overlay');
          const teamPanel = document.getElementById('pac-team-panel');
          
          // Only check if player name is manually entered
          if (data.playerShops && state.playerName && state.targetPokemon) {
            const playerShop = data.playerShops[state.playerName];
            let targetInShop = false;
            
            if (playerShop && playerShop.length > 0) {
              // Check if Ditto is in shop (Ditto can be ANY Pokemon)
              const dittoInShop = playerShop.includes('DITTO');
              
              // Check if any evolution family member is in shop
              if (state.evolutionFamily && state.evolutionFamily.length > 0) {
                targetInShop = state.evolutionFamily.some(formName => 
                  playerShop.includes(formName)
                );
              } else if (state.targetPokemonDisplayName) {
                targetInShop = playerShop.includes(state.targetPokemonDisplayName.toUpperCase());
              }
              
              // Flash if target OR Ditto in shop
              targetInShop = targetInShop || dittoInShop;
            }
            
            if (targetInShop) {
              overlay.classList.add('target-in-shop');
            } else {
              overlay.classList.remove('target-in-shop');
            }
          } else {
            overlay.classList.remove('target-in-shop');
          }
          
          // Check if ANY team target is in player's shop (TEAM PANEL FLASH)
          if (teamPanel && data.playerShops && state.playerName && state.teamTargets.length > 0) {
            const playerShop = data.playerShops[state.playerName];
            let teamTargetInShop = false;
            
            if (playerShop && playerShop.length > 0) {
              // Check if Ditto is in shop (Ditto can be ANY Pokemon)
              const dittoInShop = playerShop.includes('DITTO');
              
              // Check if any team target or their evolutions are in shop
              teamTargetInShop = state.teamTargets.some(target => {
                const baseForm = getBaseForm(target.pokemon);
                const family = getEvolutionFamily(baseForm);
                return family.some(formName => playerShop.includes(formName));
              });
              
              // Flash if any team target OR Ditto in shop
              teamTargetInShop = teamTargetInShop || dittoInShop;
            }
            
            if (teamTargetInShop) {
              teamPanel.classList.add('team-target-in-shop');
            } else {
              teamPanel.classList.remove('team-target-in-shop');
            }
          } else if (teamPanel) {
            teamPanel.classList.remove('team-target-in-shop');
          }
          
          // Auto-set player level from DOM
          if (data.localPlayerLevel && data.localPlayerLevel !== state.level) {
            state.level = data.localPlayerLevel;
            document.getElementById('pacLevel').value = data.localPlayerLevel;
          }
          
          // Update current team panel with board/bench data (lookup by playerName)
          if (state.playerName && (data.playerBoards || data.playerBenches)) {
            const board = data.playerBoards?.[state.playerName] || [];
            const bench = data.playerBenches?.[state.playerName] || [];
            
            if (DEBUG_MODE) console.log(`📦 Board/Bench for ${state.playerName}:`, {
              boardCount: board.length,
              benchCount: bench.length
            });
            
            updateCurrentDisplay({
              board: board,
              bench: bench
            });
          } else {
            if (DEBUG_MODE) console.log('ℹ️ No playerName set or no board/bench data');
          }
          
          // Always recalculate
          updateDisplay();
        } else {
          if (isConnected) {
            isConnected = false;
            document.getElementById('pacStatusDot').classList.remove('connected');
            document.getElementById('pacLiveIndicator').style.display = 'none';
            if (DEBUG_MODE) console.log('🎮 PAC Calculator: Disconnected');
          }
        }
      }
    });

    // Wait for extractor to load, then start polling
    setTimeout(() => {
      // Request extraction at selected speed
      extractionInterval = setInterval(() => {
        window.postMessage({ type: 'PAC_EXTRACT_REQUEST' }, '*');
      }, currentPollSpeed);
      
      // Initial request
      window.postMessage({ type: 'PAC_EXTRACT_REQUEST' }, '*');
    }, 1000);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // KEYBOARD SHORTCUT
  // ═══════════════════════════════════════════════════════════════════════════

  function setupKeyboardShortcut() {
    document.addEventListener('keydown', (e) => {
      // Shift+Alt+P to toggle overlay
      if (e.shiftKey && e.altKey && e.key === 'P') {
        e.preventDefault();
        const overlay = document.getElementById('pac-calc-overlay');
        if (overlay) {
          overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none';
        }
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // TEAM TRACKER PANEL (v2.8.0)
  // ═══════════════════════════════════════════════════════════════════════════
  
  function setupTeamPanel() {
    const panel = document.getElementById('pac-team-panel');
    const toggleBtn = document.getElementById('pacTeamToggle');
    const closeBtn = document.getElementById('pacTeamClose');
    const addInput = document.getElementById('pacTeamAddInput');
    const addBtn = document.getElementById('pacTeamAddBtn');
    
    // Toggle panel
    toggleBtn.addEventListener('click', () => {
      // Close current panel if open
      if (state.currentPanelExpanded) {
        const currentPanel = document.getElementById('pac-current-panel');
        state.currentPanelExpanded = false;
        currentPanel.classList.remove('expanded');
      }
      
      state.teamPanelExpanded = !state.teamPanelExpanded;
      panel.classList.toggle('expanded', state.teamPanelExpanded);
    });
    
    closeBtn.addEventListener('click', () => {
      state.teamPanelExpanded = false;
      panel.classList.remove('expanded');
      // Hide dropdown if open
      const dropdown = document.getElementById('pacTeamDropdown');
      if (dropdown) {
        dropdown.classList.add('hidden');
      }
    });
    
    // Setup autocomplete for team add input
    setupTeamAutocomplete(addInput);
    
    // Add Pokemon via button
    addBtn.addEventListener('click', () => {
      const pokemon = addInput.value.trim();
      if (pokemon) {
        addTeamTarget(pokemon);
        addInput.value = '';
      }
    });
    
    // Add Pokemon via Enter key
    addInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const pokemon = addInput.value.trim();
        if (pokemon) {
          addTeamTarget(pokemon);
          addInput.value = '';
        }
      }
    });
    
    // Initial render
    updateTeamDisplay();
  }
  
  function setupCurrentPanel() {
    const panel = document.getElementById('pac-current-panel');
    const toggleBtn = document.getElementById('pacCurrentToggle');
    const closeBtn = document.getElementById('pacCurrentClose');
    
    if (!panel || !toggleBtn || !closeBtn) {
      console.error('Current panel elements not found');
      return;
    }
    
    // Toggle panel
    toggleBtn.addEventListener('click', () => {
      // Close team panel if open
      if (state.teamPanelExpanded) {
        const teamPanel = document.getElementById('pac-team-panel');
        state.teamPanelExpanded = false;
        teamPanel.classList.remove('expanded');
      }
      
      state.currentPanelExpanded = !state.currentPanelExpanded;
      panel.classList.toggle('expanded', state.currentPanelExpanded);
    });
    
    closeBtn.addEventListener('click', () => {
      state.currentPanelExpanded = false;
      panel.classList.remove('expanded');
    });
    
    // Initial render
    updateCurrentDisplay();
  }
  
  function updateCurrentDisplay(data) {
    const unitsEl = document.getElementById('pacCurrentUnits');
    const totalCountEl = document.getElementById('pacCurrentTotalCount');
    
    if (DEBUG_MODE) console.log('📋 updateCurrentDisplay called:', data);
    
    if (!unitsEl || !totalCountEl) {
      if (DEBUG_MODE) console.warn('⚠️ Current panel elements not found');
      return;
    }
    
    // OPTIMIZATION: Dirty check - only render if board/bench changed
    if (data?.board && data?.bench) {
      const currentHash = JSON.stringify({
        board: data.board.map(p => `${p.name}:${p.stars}`).sort(),
        bench: data.bench.map(p => `${p.name}:${p.stars}`).sort()
      });
      
      // Exit early if nothing changed
      if (currentHash === lastCurrentHash) {
        if (DEBUG_MODE) console.log('⚡ SKIP: Current panel unchanged');
        return;
      }
      lastCurrentHash = currentHash;
    }
    
    // Clear previous
    unitsEl.innerHTML = '';
    
    // If no data, show empty state
    if (!data || !data.board || !data.bench) {
      unitsEl.innerHTML = '<div class="pac-current-empty">No data</div>';
      totalCountEl.textContent = '0';
      if (DEBUG_MODE) console.log('ℹ️ No board/bench data provided');
      return;
    }
    
    // Combine board + bench
    const allUnits = [...data.board, ...data.bench];
    totalCountEl.textContent = allUnits.length.toString();
    
    if (DEBUG_MODE) console.log(`✅ Rendering ${allUnits.length} owned units (${data.board.length} board + ${data.bench.length} bench)`);
    
    // Populate all units
    if (allUnits.length === 0) {
      unitsEl.innerHTML = '<div class="pac-current-empty">Empty</div>';
    } else {
      allUnits.forEach(unit => {
        const stars = '★'.repeat(unit.stars || 1);
        const div = document.createElement('div');
        div.className = 'pac-current-item';
        div.innerHTML = `
          <span class="pac-current-item-name">${unit.name}</span>
          <span class="pac-current-item-stars">${stars}</span>
        `;
        unitsEl.appendChild(div);
      });
    }
  }
  
  function setupTeamAutocomplete(input) {
    // Create dropdown - append to body so it can float outside
    const dropdown = document.createElement('div');
    dropdown.className = 'pac-team-dropdown hidden';
    dropdown.id = 'pacTeamDropdown';
    document.body.appendChild(dropdown);
    
    let selectedIndex = -1;
    let filteredPokemon = [];
    
    // Update dropdown position based on panel position
    function updateDropdownPosition() {
      const panel = document.getElementById('pac-team-panel');
      const inputRect = input.getBoundingClientRect();
      
      if (panel && state.teamPanelExpanded && !dropdown.classList.contains('hidden')) {
        const panelRect = panel.getBoundingClientRect();
        // Position to the right of the panel
        const leftPos = panelRect.right + 20;
        const topPos = inputRect.top;
        
        dropdown.style.left = leftPos + 'px';
        dropdown.style.top = topPos + 'px';
      }
    }
    
    // Store globally so drag handler can access
    window.updateTeamDropdownPosition = updateDropdownPosition;
    
    input.addEventListener('input', (e) => {
      const query = e.target.value.trim().toLowerCase();
      selectedIndex = -1;
      
      // Only show dropdown if panel is expanded
      if (!state.teamPanelExpanded || query.length === 0) {
        dropdown.classList.add('hidden');
        return;
      }
      
      // Filter Pokemon
      filteredPokemon = Object.entries(POKEMON_DATA)
        .filter(([name, data]) => name.toLowerCase().includes(query))
        .slice(0, 8);
      
      if (filteredPokemon.length === 0) {
        dropdown.classList.add('hidden');
        return;
      }
      
      // Update position before showing
      updateDropdownPosition();
      
      // Render dropdown
      dropdown.innerHTML = filteredPokemon.map(([name, rarity], idx) => {
        const rarityColors = {
          common: '#9ca3af',
          uncommon: '#10b981',
          rare: '#00d9ff',
          epic: '#a855f7',
          ultra: '#ef4444',
          unique: '#ff6b6b',
          legendary: '#ffd700',
          special: '#e91e63',
          hatch: '#00bcd4'
        };
        
        // rarity is now just a string
        const color = rarityColors[rarity] || rarityColors['common'];
        const displayRarity = rarity.charAt(0).toUpperCase() + rarity.slice(1);
        
        return `
          <div class="pac-team-dropdown-item" data-index="${idx}" data-pokemon="${name}">
            <div class="pac-team-dropdown-name" style="color: ${color}">${name}</div>
            <div class="pac-team-dropdown-meta">
              ${displayRarity}
            </div>
          </div>
        `;
      }).join('');
      
      dropdown.classList.remove('hidden');
    });
    
    // Use event delegation for clicks instead of adding handlers every input
    dropdown.addEventListener('click', (e) => {
      const item = e.target.closest('.pac-team-dropdown-item');
      if (!item) return;
      
      const pokemonName = item.dataset.pokemon;
      if (pokemonName) {
        // Hide dropdown immediately
        dropdown.classList.add('hidden');
        addTeamTarget(pokemonName);
        // Clear input after a tick to prevent input event from re-showing dropdown
        setTimeout(() => {
          input.value = '';
        }, 0);
      }
    });
    
    dropdown.addEventListener('mouseenter', (e) => {
      const item = e.target.closest('.pac-team-dropdown-item');
      if (!item) return;
      
      const idx = parseInt(item.dataset.index);
      if (idx >= 0 && idx < filteredPokemon.length) {
        selectedIndex = idx;
        updateDropdownSelection();
      }
    }, true);
    
    input.addEventListener('keydown', (e) => {
      if (dropdown.classList.contains('hidden') || filteredPokemon.length === 0) {
        return;
      }
      
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        selectedIndex = Math.min(selectedIndex + 1, filteredPokemon.length - 1);
        updateDropdownSelection();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        selectedIndex = Math.max(selectedIndex - 1, -1);
        updateDropdownSelection();
      } else if (e.key === 'Enter' && selectedIndex >= 0) {
        e.preventDefault();
        input.value = filteredPokemon[selectedIndex][0];
        dropdown.classList.add('hidden');
        addTeamTarget(filteredPokemon[selectedIndex][0]);
        input.value = '';
      } else if (e.key === 'Escape') {
        dropdown.classList.add('hidden');
      }
    });
    
    input.addEventListener('blur', () => {
      setTimeout(() => dropdown.classList.add('hidden'), 200);
    });
    
    function updateDropdownSelection() {
      dropdown.querySelectorAll('.pac-team-dropdown-item').forEach((item, idx) => {
        item.classList.toggle('selected', idx === selectedIndex);
      });
    }
  }
  
  
  function showNotification(message, type = 'info') {
    // Create notification element
    const notif = document.createElement('div');
    notif.className = `pac-notification pac-notification-${type}`;
    notif.textContent = message;
    
    // Add to body
    document.body.appendChild(notif);
    
    // Position in top-right
    notif.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      background: ${type === 'success' ? 'rgba(16, 185, 129, 0.95)' : type === 'warning' ? 'rgba(245, 158, 11, 0.95)' : 'rgba(239, 68, 68, 0.95)'};
      color: white;
      border-radius: 8px;
      font-family: 'Segoe UI', sans-serif;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 9999999;
      animation: slideIn 0.3s ease-out;
    `;
    
    // Add CSS animation if not already present
    if (!document.getElementById('pac-notif-styles')) {
      const style = document.createElement('style');
      style.id = 'pac-notif-styles';
      style.textContent = `
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `;
      document.head.appendChild(style);
    }
    
    // Auto-remove after 2 seconds
    setTimeout(() => {
      notif.style.transition = 'all 0.3s ease-out';
      notif.style.transform = 'translateX(400px)';
      notif.style.opacity = '0';
      setTimeout(() => notif.remove(), 300);
    }, 2000);
  }
  
  function addTeamTarget(pokemonName) {
    const normalizedName = pokemonName.toUpperCase();
    
    // Check if already in team
    if (state.teamTargets.some(t => t.pokemon === normalizedName)) {
      // Show non-blocking notification
      showNotification('This Pokemon is already in your team!', 'warning');
      return;
    }
    
    // Get rarity - POKEMON_DATA is now just strings
    const rarity = POKEMON_DATA[normalizedName];
    if (!rarity) {
      showNotification('Pokemon not found!', 'error');
      return;
    }
    
    // Get evolution cap from EVOLUTION_CHAINS
    const baseForm = getBaseForm(normalizedName);
    const evolutionChain = EVOLUTION_CHAINS[baseForm];
    
    let evo = 'twoStar'; // Default
    
    if (evolutionChain && evolutionChain[0] && evolutionChain[0].maxStars !== undefined) {
      // maxStars: 3 → threeStar, maxStars: 1 or 2 → twoStar
      evo = evolutionChain[0].maxStars === 3 ? 'threeStar' : 'twoStar';
    }
    
    // Add to team
    const target = {
      id: Date.now() + Math.random(),
      pokemon: normalizedName,
      displayName: pokemonName,
      rarity: rarity,
      evo: evo,
      isWild: false, // TODO: detect wild Pokemon if needed
      enabled: true,
      copiesTaken: 0
    };
    
    state.teamTargets.push(target);
    saveTeamTargets();
    if (DEBUG_MODE) console.log('Added to team:', target, 'Total targets:', state.teamTargets.length);
    updateTeamDisplay();
    showNotification(`${pokemonName} added to team!`, 'success');
  }
  
  function removeTeamTarget(id) {
    state.teamTargets = state.teamTargets.filter(t => t.id !== id);
    saveTeamTargets();
    updateTeamDisplay();
  }
  
  function toggleTeamTarget(id) {
    const target = state.teamTargets.find(t => t.id === id);
    if (target) {
      target.enabled = !target.enabled;
      saveTeamTargets();
      updateTeamDisplay();
    }
  }
  
  function saveTeamTargets() {
    try {
      localStorage.setItem('pac_teamTargets', JSON.stringify(state.teamTargets));
    } catch (err) {
      if (DEBUG_MODE) console.warn('Failed to save teamTargets to localStorage:', err);
    }
  }
  
  function setActiveTeamTarget(id) {
    const target = state.teamTargets.find(t => t.id === id);
    if (!target) return;
    
    // Set as main target
    state.targetPokemon = target.pokemon;
    state.targetPokemonDisplayName = target.displayName;
    state.targetRarity = target.rarity;
    state.targetEvo = target.evo;
    state.targetIsWild = target.isWild;
    state.copiesTaken = target.copiesTaken;
    
    // Update main panel
    document.getElementById('pacTarget').value = target.displayName;
    document.getElementById('pacRarity').value = target.rarity;
    document.getElementById('pacEvo').value = target.evo;
    document.getElementById('pacTargetWild').checked = target.isWild;
    document.getElementById('pacScouted').value = target.copiesTaken;
    
    // Recalculate
    updateDisplay();
    updateTeamDisplay();
  }
  
  function calculateTeamStats() {
    const results = [];
    let combinedMissProb = 1.0;
    
    state.teamTargets.forEach(target => {
      if (!target.enabled) return;
      
      // Skip non-pool rarities (legendary, unique, hatch, special)
      if (!POOL_RARITIES.includes(target.rarity)) {
        results.push({
          target: target,
          perRefresh: 0,
          expected: Infinity,
          notInPool: true
        });
        return;
      }
      
      // Calculate for this target
      const totalPool = calculateTotalPool();
      const totalWildCounts = calculateWildCounts();
      const pool = totalPool[target.rarity];
      const rarityOdds = SHOP_ODDS[state.level];
      const rarityChance = rarityOdds[target.rarity] / 100;
      
      const wildCountsForRarity = totalWildCounts[target.rarity];
      const maxTargetCopies = target.evo === 'twoStar' ? POOL_COPIES[target.rarity].twoStar : POOL_COPIES[target.rarity].threeStar;
      const targetCopies = Math.max(0, maxTargetCopies - target.copiesTaken);
      
      // Get pool reductions from extraction data
      let visibleTwoStar = 0;
      let visibleThreeStar = 0;
      
      if (lastPoolData && lastPoolData.poolReductions && lastPoolData.poolReductions[target.rarity]) {
        visibleTwoStar = lastPoolData.poolReductions[target.rarity].twoStar || 0;
        visibleThreeStar = lastPoolData.poolReductions[target.rarity].threeStar || 0;
      }
      
      const relevantPoolBeforeVisible = target.evo === 'twoStar' ? pool.twoStarTotal : pool.threeStarTotal;
      const otherPoolPortion = target.evo === 'twoStar' ? pool.threeStarTotal : pool.twoStarTotal;
      
      // Reduce pools by visible units
      const relevantPoolAfterVisible = Math.max(0, relevantPoolBeforeVisible - (target.evo === 'twoStar' ? visibleTwoStar : visibleThreeStar));
      const otherPoolAfterVisible = Math.max(0, otherPoolPortion - (target.evo === 'twoStar' ? visibleThreeStar : visibleTwoStar));
      
      const totalPoolSize = relevantPoolAfterVisible + otherPoolAfterVisible;
      
      const totalWildCopiesBeforeReduction = target.evo === 'twoStar' ?
        wildCountsForRarity.twoStar * POOL_COPIES[target.rarity].twoStar :
        wildCountsForRarity.threeStar * POOL_COPIES[target.rarity].threeStar;
      const totalWildCopies = Math.max(0, totalWildCopiesBeforeReduction - state.wildUnitsTaken);
      
      const wildBoost = state.pveRoundEnabled ? (0.05 + (state.wildUnitsOwned * 0.01)) : (state.wildUnitsOwned * 0.01);
      const safeWildBoost = isNaN(wildBoost) ? 0 : wildBoost;
      
      let perSlotProbTarget = 0;
      
      if (target.isWild) {
        const wildUnitsExist = target.evo === 'twoStar' ? wildCountsForRarity.twoStar > 0 : wildCountsForRarity.threeStar > 0;
        if (wildUnitsExist && totalWildCopies > 0 && safeWildBoost > 0) {
          perSlotProbTarget = safeWildBoost * rarityChance * (targetCopies / totalWildCopies);
        }
      } else {
        if (targetCopies > 0 && totalPoolSize > 0) {
          const baseProb = rarityChance * (targetCopies / totalPoolSize);
          perSlotProbTarget = (1 - safeWildBoost) * baseProb;
        }
      }
      
      const perRefresh = 1 - Math.pow(1 - perSlotProbTarget, 6);  // 6 shop slots
      const confidenceDecimal = (100 - state.confidencePercent) / 100;
      const expectedForConfidence = perRefresh > 0 ? Math.log(confidenceDecimal) / Math.log(1 - perRefresh) : Infinity;
      
      results.push({
        target: target,
        perRefresh: perRefresh,
        expected: expectedForConfidence
      });
      
      // For combined calculation
      if (perRefresh > 0) {
        combinedMissProb *= (1 - perRefresh);
      }
    });
    
    const combinedHitProb = 1 - combinedMissProb;
    const combinedExpected = combinedHitProb > 0 ? 1 / combinedHitProb : Infinity;
    
    return {
      individual: results,
      combined: {
        prob: combinedHitProb,
        expected: combinedExpected
      }
    };
  }
  
  // OPTIMIZATION: Create fingerprint of team state for dirty checking
  function createTeamFingerprint() {
    // Capture exact pool state for each target
    const targetStates = state.teamTargets.map(target => {
      const baseForm = getBaseForm(target.pokemon);
      const rarity = POKEMON_DATA[baseForm];
      
      // Get exact pool reductions - no rounding
      const poolRed = lastPoolData?.poolReductions?.[rarity] || { twoStar: 0, threeStar: 0 };
      
      return [
        target.pokemon,
        target.copiesTaken || 0,
        state.level,
        poolRed.twoStar,
        poolRed.threeStar
      ].join(':');
    }).join('|');
    
    // Global state that affects all calculations
    const globalState = [
      state.round5Enabled ? '1' : '0',
      state.round8Enabled ? '1' : '0',
      state.round11Enabled ? '1' : '0',
      state.targetEvo,
      lastPoolData?.playerCount || 0
    ].join(':');
    
    return `${targetStates}||${globalState}`;
  }

  function updateTeamDisplay() {
    const list = document.getElementById('pacTeamList');
    const combinedProbEl = document.getElementById('pacTeamCombinedProb');
    const combinedRollsEl = document.getElementById('pacTeamCombinedRolls');
    
    // OPTIMIZATION: Dirty check - only render if pool state changed
    const fingerprint = createTeamFingerprint();
    if (fingerprint === lastTeamFingerprint) {
      if (DEBUG_MODE) console.log('⚡ SKIP: Team panel unchanged');
      return;
    }
    lastTeamFingerprint = fingerprint;
    
    if (DEBUG_MODE) {
      if (DEBUG_MODE) console.log('updateTeamDisplay called', {
        listExists: !!list,
        targetsCount: state.teamTargets.length,
        targets: state.teamTargets
      });
    }
    
    if (!list) {
      if (DEBUG_MODE) console.error('Team list element not found!');
      return;
    }
    
    if (state.teamTargets.length === 0) {
      list.innerHTML = `
        <div class="pac-team-empty">
          <div class="pac-team-empty-icon">🎯</div>
          <div>No Pokemon in team tracker</div>
          <div style="font-size: 11px; margin-top: 8px;">Click + Add Pokemon to start</div>
        </div>
      `;
      combinedProbEl.textContent = '0%';
      combinedRollsEl.textContent = '0 rolls';
      return;
    }
    
    const stats = calculateTeamStats();
    
    // Render team list
    list.innerHTML = state.teamTargets.map(target => {
      const result = stats.individual.find(r => r.target.id === target.id);
      const isActive = state.targetPokemon === target.pokemon;
      const notInPool = result && result.notInPool;
      
      let probText = '0%';
      let rollsText = '∞';
      
      if (result && !notInPool) {
        probText = (result.perRefresh * 100).toFixed(1) + '%';
        rollsText = isFinite(result.expected) ? Math.ceil(result.expected).toString() : '∞';
      }
      
      const rarityColors = {
        common: '#9ca3af',
        uncommon: '#10b981',
        rare: '#00d9ff',
        epic: '#a855f7',
        ultra: '#ef4444',
        unique: '#ff6b6b',
        legendary: '#ffd700',
        special: '#e91e63',
        hatch: '#00bcd4'
      };
      
      return `
        <div class="pac-team-item ${isActive ? 'active' : ''} ${notInPool ? 'not-in-pool' : ''}" data-id="${target.id}">
          <div class="pac-team-item-header">
            <input type="checkbox" class="pac-team-checkbox" ${target.enabled ? 'checked' : ''} data-id="${target.id}">
            <span class="pac-team-name" style="color: ${rarityColors[target.rarity]}" data-id="${target.id}">${target.displayName}</span>
            <button class="pac-team-remove" data-id="${target.id}">×</button>
          </div>
          <div class="pac-team-meta">
            <span style="color: ${rarityColors[target.rarity]}">${target.rarity.charAt(0).toUpperCase() + target.rarity.slice(1)}</span>
            <span style="margin: 0 8px;">•</span>
            <span>${target.evo === 'twoStar' ? '2★' : '3★'}</span>
            ${target.isWild ? '<span style="margin: 0 8px;">•</span><span style="color: #fbbf24;">Wild</span>' : ''}
            ${notInPool ? '<span style="margin: 0 8px;">•</span><span style="color: #64b5f6; font-size: 10px;">Not in pool</span>' : ''}
          </div>
          ${target.enabled && !notInPool ? `
            <div class="pac-team-stats">
              <div class="pac-team-stat-mini">
                <div class="pac-team-stat-mini-label">Per Refresh</div>
                <div class="pac-team-stat-mini-value">${probText}</div>
              </div>
              <div class="pac-team-stat-mini">
                <div class="pac-team-stat-mini-label">Expected</div>
                <div class="pac-team-stat-mini-value">${rollsText} rolls</div>
              </div>
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
    
    // Combined stats
    const enabledCount = state.teamTargets.filter(t => t.enabled).length;
    if (enabledCount > 0) {
      combinedProbEl.textContent = (stats.combined.prob * 100).toFixed(1) + '%';
      combinedRollsEl.textContent = isFinite(stats.combined.expected) ? Math.ceil(stats.combined.expected) + ' rolls' : '∞';
    } else {
      combinedProbEl.textContent = '0%';
      combinedRollsEl.textContent = '0 rolls';
    }
    
    // Attach event listeners
    list.querySelectorAll('.pac-team-checkbox').forEach(cb => {
      cb.addEventListener('change', (e) => {
        e.stopPropagation();
        toggleTeamTarget(parseFloat(e.target.dataset.id));
      });
    });
    
    list.querySelectorAll('.pac-team-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeTeamTarget(parseFloat(e.target.dataset.id));
      });
    });
    
    list.querySelectorAll('.pac-team-name').forEach(name => {
      name.addEventListener('click', (e) => {
        e.stopPropagation();
        setActiveTeamTarget(parseFloat(e.target.dataset.id));
      });
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // INIT
  // ═══════════════════════════════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════════════════════════════
  // EULA / PRIVACY NOTICE
  // ═══════════════════════════════════════════════════════════════════════════
  
  function showEULA() {
    return new Promise((resolve) => {
      const eulaOverlay = document.createElement('div');
      eulaOverlay.id = 'pac-eula-overlay';
      eulaOverlay.innerHTML = `
        <div id="pac-eula-modal">
          <div class="pac-eula-title">🎮 Pokemon Auto Chess Live Data Calculator - Terms & Privacy Notice</div>
          
          <div class="pac-eula-content">
            <div class="pac-eula-section">
              <div class="pac-eula-section-title">Welcome!</div>
              <p>Thank you for using Pokemon Auto Chess Live Data Calculator. Before you begin, please review and accept the following terms:</p>
            </div>
            
            <div class="pac-eula-highlight">
              <strong>✅ 100% Safe & TOS Compliant</strong>
              <p style="margin: 8px 0 0 0;">This extension is a <strong>read-only calculator tool</strong>. It does NOT:</p>
              <ul style="margin: 8px 0 0 20px; padding: 0;">
                <li>Modify game files or memory</li>
                <li>Automate gameplay or provide unfair advantages</li>
                <li>Violate Pokemon Auto Chess Terms of Service</li>
                <li>Interact with game servers in any way</li>
              </ul>
              <p style="margin: 8px 0 0 0;"><strong>This is purely a probability calculator</strong> - similar to using a calculator app while playing poker.</p>
            </div>
            
            <div class="pac-eula-section">
              <div class="pac-eula-section-title">🔒 Your Privacy & Data</div>
              <p><strong>Zero data collection. Zero tracking. Zero transmission.</strong></p>
              <ul style="margin: 8px 0 0 20px; padding: 0;">
                <li><strong>All data stays on YOUR device</strong> - nothing is sent to any server</li>
                <li><strong>No personal information collected</strong> - no emails, no IPs, no tracking</li>
                <li><strong>No analytics, no telemetry, no third parties</strong></li>
                <li><strong>Local storage only</strong> - your settings (player name, team targets) are saved in your browser's localStorage for convenience</li>
              </ul>
            </div>
            
            <div class="pac-eula-section">
              <div class="pac-eula-section-title">📊 What This Tool Does</div>
              <ul style="margin: 8px 0 0 20px; padding: 0;">
                <li>Reads public game state (Pokemon counts in the current match)</li>
                <li>Calculates probability of finding specific Pokemon</li>
                <li>Tracks your board/bench when you provide your in-game name</li>
                <li>Saves your preferences locally for convenience</li>
              </ul>
            </div>
            
            <div class="pac-eula-warning">
              <strong>⚠️ Use Responsibly</strong>
              <p style="margin: 8px 0 0 0;">While this tool is safe and compliant, I recommend:</p>
              <ul style="margin: 8px 0 0 20px; padding: 0;">
                <li>Don't rely solely on calculations - use game knowledge too</li>
                <li>Be respectful to other players</li>
                <li><strong>Calculator bug/issue?</strong> Contact me: <strong>@Deuce222X</strong> in the official Discord (DMs/pings welcome!)</li>
                <li><strong>Game issue?</strong> Contact moderators in the official Pokemon Auto Chess Discord</li>
              </ul>
            </div>
            
            <div class="pac-eula-section">
              <div class="pac-eula-section-title">⚖️ Disclaimer</div>
              <p style="font-size: 12px; color: #999;">
                This is an independent, open-source tool created by a solo developer (@Deuce222X) for educational and strategic purposes. 
                Not affiliated with or endorsed by Pokemon Auto Chess developers. 
                Use at your own discretion. The developer of this tool is not responsible for any consequences of its use.
              </p>
            </div>
            
            <div class="pac-eula-section">
              <div class="pac-eula-section-title">📞 Contact</div>
              <p style="font-size: 12px; color: #64b5f6;">
                Find me in the official Pokemon Auto Chess Discord: <strong>@Deuce222X</strong><br>
                Open to DMs and pings for calculator-related questions, bugs, or suggestions!
              </p>
            </div>
          </div>
          
          <div class="pac-eula-checkboxes">
            <div class="pac-eula-checkbox-row" data-checkbox="1">
              <div class="pac-eula-custom-checkbox" id="pac-eula-understand"></div>
              <label>I understand this tool is safe, read-only, and does not violate Terms of Service</label>
            </div>
            <div class="pac-eula-checkbox-row" data-checkbox="2">
              <div class="pac-eula-custom-checkbox" id="pac-eula-privacy"></div>
              <label>I understand no personal data is collected or transmitted - all data stays on my device</label>
            </div>
            <div class="pac-eula-checkbox-row" data-checkbox="3">
              <div class="pac-eula-custom-checkbox" id="pac-eula-agree"></div>
              <label>I agree to use this tool responsibly and at my own discretion</label>
            </div>
          </div>
          
          <button id="pac-eula-accept" class="pac-eula-button" disabled>I Understand and Agree - Start Using PAC Live Data Calculator</button>
        </div>
      `;
      
      document.body.appendChild(eulaOverlay);
      if (DEBUG_MODE) console.log('✅ EULA overlay appended to body');
      if (DEBUG_MODE) console.log('📋 EULA overlay element:', eulaOverlay);
      if (DEBUG_MODE) console.log('📐 EULA overlay computed style:', window.getComputedStyle(eulaOverlay).display);
      
      const checkbox1 = document.getElementById('pac-eula-understand');
      const checkbox2 = document.getElementById('pac-eula-privacy');
      const checkbox3 = document.getElementById('pac-eula-agree');
      const acceptBtn = document.getElementById('pac-eula-accept');
      
      if (DEBUG_MODE) console.log('✅ Found checkboxes and button:', {
        checkbox1: !!checkbox1,
        checkbox2: !!checkbox2,
        checkbox3: !!checkbox3,
        acceptBtn: !!acceptBtn
      });
      
      function checkAll() {
        if (checkbox1.classList.contains('checked') && 
            checkbox2.classList.contains('checked') && 
            checkbox3.classList.contains('checked')) {
          acceptBtn.disabled = false;
        } else {
          acceptBtn.disabled = true;
        }
      }
      
      checkbox1.addEventListener('click', () => {
        checkbox1.classList.toggle('checked');
        checkAll();
      });
      checkbox2.addEventListener('click', () => {
        checkbox2.classList.toggle('checked');
        checkAll();
      });
      checkbox3.addEventListener('click', () => {
        checkbox3.classList.toggle('checked');
        checkAll();
      });
      
      acceptBtn.addEventListener('click', () => {
        localStorage.setItem('pac_eulaAccepted', 'true');
        eulaOverlay.remove();
        resolve();
      });
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // INITIALIZATION
  // ═══════════════════════════════════════════════════════════════════════════

  function init() {
    const overlay = createOverlay();
    setupDrag(overlay);
    loadPosition();
    setupCollapsibles();
    setupTeamPanel();
    setupCurrentPanel();
    bindUI();
    setupKeyboardShortcut();
    
    // Load saved data from localStorage
    try {
      const savedPlayerName = localStorage.getItem('pac_playerName');
      if (savedPlayerName) {
        state.playerName = savedPlayerName;
        const playerNameInput = document.getElementById('pacPlayerName');
        if (playerNameInput) {
          playerNameInput.value = savedPlayerName;
        }
        if (DEBUG_MODE) console.log('✅ Loaded playerName from localStorage:', savedPlayerName);
      }
      
      const savedTeamTargets = localStorage.getItem('pac_teamTargets');
      if (savedTeamTargets) {
        state.teamTargets = JSON.parse(savedTeamTargets);
        updateTeamDisplay();
        if (DEBUG_MODE) console.log('✅ Loaded', state.teamTargets.length, 'team targets from localStorage');
      }
    } catch (err) {
      if (DEBUG_MODE) console.warn('Failed to load from localStorage:', err);
    }
    
    updateDisplay();
    
    if (DEBUG_MODE) console.log('🎮 PAC Calculator v2.16.6: Overlay ready');
    if (DEBUG_MODE) console.log('   • 1060 pokemon database loaded');
    if (DEBUG_MODE) console.log('   • Autocomplete selector active');
    if (DEBUG_MODE) console.log('   • Drag header to move');
    if (DEBUG_MODE) console.log('   • Shift+Alt+P to toggle');
    if (DEBUG_MODE) console.log('   • Click "Live Tracking" to start polling');
  }

  // Wait for page to be ready
  async function start() {
    if (DEBUG_MODE) console.log('🚀 PAC Calculator starting...');
    
    // Inject CSS FIRST (before EULA so it's styled properly)
    if (!document.getElementById('pac-calc-styles')) {
      const style = document.createElement('style');
      style.id = 'pac-calc-styles';
      style.textContent = `
        /* Copy all CSS from createOverlay here - just the EULA part for now */
        #pac-eula-overlay {
          position: fixed !important;
          top: 0 !important;
          left: 0 !important;
          width: 100% !important;
          height: 100% !important;
          background: rgba(0, 0, 0, 0.95) !important;
          z-index: 2147483647 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          backdrop-filter: blur(10px);
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #pac-eula-modal {
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
          border: 2px solid #0f3460;
          border-radius: 12px;
          max-width: 600px;
          max-height: 80vh;
          padding: 24px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.6);
          color: #e9e9e9;
          overflow-y: auto;
          position: relative;
          z-index: 2147483647 !important;
        }
        
        .pac-eula-title {
          font-size: 20px;
          font-weight: 600;
          margin-bottom: 16px;
          color: #64b5f6;
          text-align: center;
        }
        
        .pac-eula-content {
          font-size: 13px;
          line-height: 1.6;
          margin-bottom: 20px;
          color: #ccc;
        }
        
        .pac-eula-section {
          margin-bottom: 16px;
        }
        
        .pac-eula-section-title {
          font-size: 14px;
          font-weight: 600;
          color: #64b5f6;
          margin-bottom: 8px;
        }
        
        .pac-eula-highlight {
          background: rgba(76, 175, 80, 0.2);
          padding: 12px;
          border-left: 3px solid #4caf50;
          border-radius: 4px;
          margin: 12px 0;
        }
        
        .pac-eula-warning {
          background: rgba(255, 152, 0, 0.2);
          padding: 12px;
          border-left: 3px solid #ff9800;
          border-radius: 4px;
          margin: 12px 0;
        }
        
        .pac-eula-checkboxes {
          margin: 20px 0;
        }
        
        .pac-eula-checkbox-row {
          display: flex !important;
          align-items: flex-start !important;
          gap: 12px !important;
          margin-bottom: 12px !important;
          padding: 12px !important;
          background: rgba(255,255,255,0.03) !important;
          border-radius: 6px !important;
          cursor: pointer !important;
        }
        
        .pac-eula-custom-checkbox {
          width: 32px !important;
          height: 32px !important;
          min-width: 32px !important;
          min-height: 32px !important;
          background: #000 !important;
          border: 2px solid #4caf50 !important;
          border-radius: 6px !important;
          cursor: pointer !important;
          position: relative !important;
          transition: all 0.2s !important;
          flex-shrink: 0 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .pac-eula-custom-checkbox:hover {
          border-color: #66bb6a !important;
          box-shadow: 0 0 8px rgba(76, 175, 80, 0.4) !important;
        }
        
        .pac-eula-custom-checkbox.checked {
          background: #000 !important;
          border-color: #4caf50 !important;
        }
        
        .pac-eula-custom-checkbox.checked::after {
          content: '✓' !important;
          color: #4caf50 !important;
          font-size: 24px !important;
          font-weight: bold !important;
          line-height: 1 !important;
        }
        
        .pac-eula-checkbox-row label {
          flex: 1;
          cursor: pointer;
          font-size: 13px;
          line-height: 1.5;
        }
        
        .pac-eula-button {
          width: 100%;
          padding: 14px;
          background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
          border: none;
          border-radius: 8px;
          color: white;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .pac-eula-button:disabled {
          background: #444;
          cursor: not-allowed;
          opacity: 0.5;
        }
        
        .pac-eula-button:not(:disabled):hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(76, 175, 80, 0.4);
        }
      `;
      document.head.appendChild(style);
      if (DEBUG_MODE) console.log('✅ Injected EULA styles');
    }
    
    // Check if EULA has been accepted
    const eulaAccepted = localStorage.getItem('pac_eulaAccepted');
    if (DEBUG_MODE) console.log('📜 EULA acceptance status:', eulaAccepted);
    
    if (!eulaAccepted) {
      if (DEBUG_MODE) console.log('⏳ Showing EULA modal...');
      await showEULA();
      if (DEBUG_MODE) console.log('✅ EULA accepted!');
    } else {
      if (DEBUG_MODE) console.log('✅ EULA already accepted, skipping');
    }
    
    // Now initialize the calculator
    if (DEBUG_MODE) console.log('🎮 Initializing calculator...');
    init();
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    setTimeout(start, 500);
  }

  // Expose for debugging
  window.__PACCalc = {
    isConnected: () => isConnected,
    getState: () => state,
    getPoolData: () => lastPoolData,
    getPokemonData: () => POKEMON_DATA,
    recalculate: updateDisplay,
    requestExtraction: () => window.postMessage({ type: 'PAC_EXTRACT_REQUEST' }, '*'),
    reinject: injectExtractor,
    resetEULA: () => {
      localStorage.removeItem('pac_eulaAccepted');
      if (DEBUG_MODE) console.log('✅ EULA reset! Refresh the page to see it again.');
    }
  };
})();
